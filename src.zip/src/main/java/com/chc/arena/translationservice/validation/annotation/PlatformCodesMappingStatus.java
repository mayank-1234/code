package com.chc.arena.translationservice.validation.annotation;

/**
 * The Enum PlatformCodesMappingStatus.
 */
public enum PlatformCodesMappingStatus {
	
	/** The enabled. */
	ENABLED("ENABLED"),
	
	/** The disabled. */
	DISABLED("DISABLED"),
	
	/** The unmapped. */
	UNMAPPED("UNMAPPED");
	
	/** The status. */
	private String status;
	

	/**
	 * Instantiates a new platform codes mapping status.
	 *
	 * @param status the status
	 */
	private PlatformCodesMappingStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
}
