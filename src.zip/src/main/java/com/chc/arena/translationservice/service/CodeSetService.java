package com.chc.arena.translationservice.service;

import java.util.List;

/**
 * The Interface CodeSetService.
 */
public interface CodeSetService {

	/**
	 * Gets the all supported code sets.
	 *
	 * @return the all supported code sets
	 */
	List<String> getAllSupportedCodeSets();

}
