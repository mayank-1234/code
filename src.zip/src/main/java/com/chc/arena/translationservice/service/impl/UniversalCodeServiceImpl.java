package com.chc.arena.translationservice.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.dao.CodeSetSolrDao;
import com.chc.arena.translationservice.dao.PlatformCodeSetSQLDao;
import com.chc.arena.translationservice.dao.UniversalCodeSetSQLDao;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.UniversalCodeService;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.util.MessageSourceUtil;

/**
 * The Class UniversalCodeServiceImpl.
 *
 * @author narendra.dubey
 */
@Service
public class UniversalCodeServiceImpl implements UniversalCodeService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(UniversalCodeServiceImpl.class);

	/** The universal code set SQL dao. */
	@Autowired
	private UniversalCodeSetSQLDao universalCodeSetSQLDao;

	/** The platform code set SQL dao. */
	@Autowired
	private PlatformCodeSetSQLDao platformCodeSetSQLDao;

	/** The code set meta data util. */
	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Autowired
	private MessageSourceUtil messageSourceUtil;

	/** The code set solr dao. */
	@Autowired
	private CodeSetSolrDao codeSetSolrDao;

	/** The Constant ROW_COUNT_ONE. */
	private static final int ROW_COUNT_ONE = 1;

	/**
	 * Gets the all universal codes.
	 *
	 * @param codeSet   the code set
	 * @param page the page
	 * @param count     the count
	 * @param status    the status
	 * @param orderBy   the order by
	 * @param direction the direction
	 * @return the all universal codes
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<List<Map<String, String>>> getAllUniversalCodes(String codeSet, Integer page, Integer count,
			StatusEnum status, String orderBy, Direction direction) throws ServiceException {

		logger.info("Processing request to get all Universal Codes for the given CodeSet={}", codeSet);

		List<Map<String, String>> universalCodes = new ArrayList<>();

		try {
			List<Map<String, Object>> repoUniversalCodes = universalCodeSetSQLDao.getAll(codeSet, page, count, status,
					orderBy, direction);

			ListIterator<Map<String, Object>> universalCodesIterator = repoUniversalCodes.listIterator();

			while (universalCodesIterator.hasNext()) {
				Map<String, Object> nextUniversalCodeData = universalCodesIterator.next();

				Map<String, String> collectedUniversalCodeData = new HashMap<>();

				nextUniversalCodeData.entrySet().forEach(entry -> collectedUniversalCodeData.put(entry.getKey(),
						(entry.getValue() != null ? entry.getValue().toString() : null)));

				universalCodes.add(collectedUniversalCodeData);
			}
		} catch (DaoException daoException) {

			String message = daoException.getMessage();

			CtsErrorCode errorCode = daoException.getErrorCode();

			logger.error(
					"Data access exception occured while trying to fetch all Universal Codes for the given CodeSet={}, Error={}",
					codeSet, errorCode + ":" + message);

			throw new ServiceException(message, errorCode, null);
		}

		if (universalCodes.isEmpty()) {
			logger.warn("No Universal Codes found in repository for the given CodeSet={}", codeSet);
		} else {
			logger.info("Found {} Universal Code(s) for the given CodeSet={}", universalCodes.size(), codeSet);
		} 

		return new ServiceResponse<>(
				(universalCodes.isEmpty() ? messageSourceUtil.getMessage("NO_UNIVERSAL_CODES_IN_DATABASE")
						: messageSourceUtil.getMessage("UNIVERSAL_CODES_IN_DATABASE")),
				universalCodes);
	}

	/**
	 * Gets single Universal Code and Data by given universal-code identifier.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return the by code
	 * @throws ServiceException the service exception
	 */
	public ServiceResponse<Map<String, String>> getByCode(String codeSet, String universalCode) throws ServiceException {
		logger.info("Processing to get Universal Code identified by UniversalCode={} for the given CodeSet={}",
				universalCode, codeSet);
		Map<String, Object> universalCodeObject;
		try {
			universalCodeObject = universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode);
		} catch (DaoException daoException) {
			logger.error("No Universal Codes found in repository for the given CodeSet={} and UniversalCode={}",
					codeSet, universalCode);
			Map<String, String> rejectedValue = new HashMap<>();
			rejectedValue.put(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD, universalCode);
			throw new ServiceException(daoException.getMessage(), rejectedValue, daoException.getErrorCode());
		}
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeObject.entrySet().stream()
				.filter(entry -> !TranslationServiceStringConstant.ID.equals(entry.getKey()))
				.forEach(entry -> universalCodeData.put(entry.getKey(),
						(entry.getValue() != null ? entry.getValue().toString() : null)));
		logger.info("Found Universal Code for the given CodeSet={} and UniversalCode={}", codeSet, universalCode);
		return new ServiceResponse<>(
				messageSourceUtil.getMessage("UNIVERSAL_CODE_IN_DATABASE"),
				universalCodeData);
	}

	/**
	 * Gets the mapped universal code.
	 *
	 * @param codeSet the code set
	 * @param platformCodeObject the platform code object
	 * @return the mapped universal code
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<Map<String, String>> getMappedUniversalCode(String codeSet,
			Map<String, String> platformCodeObject) throws ServiceException {
		try {
			logger.info("Processing Get Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}", codeSet,
					platformCodeObject);
			Map<String, Object> dbObject = universalCodeSetSQLDao.getMappedUniversalCode(codeSet, platformCodeObject);
			String status = (String) dbObject.get(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN);
			Integer universalCodeId = (Integer) dbObject.get(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN);
			if (universalCodeId == null) {
				logger.warn( 
						"Get Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}, Found Platform Object but is unmapped",
						codeSet, platformCodeObject);
				return new ServiceResponse<>(messageSourceUtil.getMessage("PLATFORM_CODE_UNMAPPED"), null);
			} else if (!StatusEnum.ENABLED.getStatus().equalsIgnoreCase(status)) {
				logger.warn(
						"Get Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}, Found Platform Object but mapping is disabled",
						codeSet, platformCodeObject);
				return new ServiceResponse<>(messageSourceUtil.getMessage("PLATFORM_CODE_DISABLED_MAPPING"), null);
			}

			logger.info(
					"Get Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}, Returning Universal-Code: {}",
					codeSet, platformCodeObject, dbObject.get(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN));
			return new ServiceResponse<>(messageSourceUtil.getMessage("MAPPED_UNIVERSAL_CODES_FOUND"),
					codeSetMetaDataUtil.getUniversalCodeFields(codeSet).stream().collect(HashMap::new,
							(map, column) -> map.put(column,
									dbObject.get(column) != null ? dbObject.get(column).toString() : null),
							HashMap::putAll));
		} catch (DaoException daoException) {
			logger.error(
					"Get Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}, Platform Object not found in database",
					codeSet, platformCodeObject);
			throw new ServiceException(daoException.getMessage(), platformCodeObject, daoException.getErrorCode());
		}
	}

	/**
	 * Gets the universal codes by code set.
	 *
	 * @return the universal codes by code set
	 * @throws ServiceException the service exception
	 */
	@Override
	public List<Map<String, String>> getUniversalCodesByCodeSet() throws ServiceException {
		return new ArrayList<>();
	}

	/**
	 * Search.
	 *
	 * @param codeSet the code set
	 * @param platformCodeData the platform code data
	 * @param from the from
	 * @param count the count
	 * @return the service response
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<List<Map<String, String>>> search(String codeSet, Map<String, String> platformCodeData,
			Integer from, Integer count) throws ServiceException {
		logger.info(
				"Processing Search Universal Code Request for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}",
				codeSet, platformCodeData, from, count);
		try {
			List<Map<String, String>> list = codeSetSolrDao.search(codeSet, platformCodeData, from, count);
			if (list.isEmpty()) {
				logger.warn(
						"Search Universal Code Request for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, found no matching Universal Code Record",
						codeSet, platformCodeData, from, count);
			} else {
				logger.info(
						"Search Universal Code Request for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, is returning {} Universal Code Record(s)",
						codeSet, platformCodeData, from, count, list.size());
			}
			return new ServiceResponse<>(list.isEmpty() ? messageSourceUtil.getMessage("NO_MATCHING_RECORD_FOUND")
					: messageSourceUtil.getMessage("MATCHING_RECORDS_FOUND"), list);
		} catch (DaoException daoException) {
			String message = daoException.getMessage();
			logger.error(
					"Search Universal Code Request for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, has encountered an Error={}",
					codeSet, platformCodeData, from, count, message);
			throw new ServiceException(message, platformCodeData, daoException.getErrorCode());
		}
	}

	/**
	 * Insert a new Universal Code and Data.
	 *
	 * @param codeSet           the code set
	 * @param universalCodeData the universal code data
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	@Override
	@Transactional
	public String insert(String codeSet, Map<String, String> universalCodeData) throws ServiceException {
		logger.info("insert [START]: CodeSet: {}, Universal Code Data: {}", codeSet, universalCodeData);
		Date currentDateTimeStamp = new Date();
		try {
			if (universalCodeSetSQLDao.insert(codeSet, universalCodeData, currentDateTimeStamp) == ROW_COUNT_ONE) {
				if (codeSetMetaDataUtil.isAdvancedSearchEnabledCodeSet(codeSet)) {
					insertCorrespondingSolrDocument(codeSet, universalCodeData, currentDateTimeStamp);
				} 
				logger.info(
						"Successfully inserted a new Universal Code for the given CodeSet={} and UniversalCodeData={}",
						codeSet, universalCodeData);
			}
		} catch (DaoException daoException) {
			Map<String, String> rejectedUniversalCode = new HashMap<>();
			rejectedUniversalCode.put(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD,
					universalCodeData.get(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD));
			logger.error("Exception occured while inserting : CodeSet: {}, Universal Code data: {} ", codeSet,
					universalCodeData);
			throw new ServiceException(daoException.getMessage(), rejectedUniversalCode, daoException.getErrorCode());
		}
		return messageSourceUtil.getMessage("UNIVERSAL_CODE_INSERTED_SUCCESSFULLY");
	}

	/**
	 * Insert corresponding solr document.
	 *
	 * @param codeSet the code set
	 * @param universalCodeData the universal code data
	 * @param currentDateTimeStamp the current date time stamp
	 * @throws ServiceException the service exception
	 */
	private void insertCorrespondingSolrDocument(String codeSet, Map<String, String> universalCodeData,
			Date currentDateTimeStamp) throws ServiceException {
		logger.info("Inserting new Solr document for the given  CodeSet={}  and  UniversalCodeData= {}", codeSet,
				universalCodeData);
		try {
			Map<String, Object> codeSetObject = new HashMap<>(universalCodeData);
			codeSetObject.put(TranslationServiceStringConstant.CREATION_DATE, currentDateTimeStamp);
			codeSetSolrDao.insert(codeSet, codeSetObject);
			logger.info("Insertion end for new Solr document for the given  CodeSet={} and  UniversalCodeData= {}",
					codeSet, universalCodeData);
		} catch (DaoException daoException) {
			logger.error(
					"Exception occurred inserting a new Solr  document for the given  CodeSet={} and  UniversalCodeData={} ",
					codeSet, universalCodeData);
			throw new ServiceException(daoException.getMessage(), universalCodeData, daoException.getErrorCode());
		}
	}

	/**
	 * Update a Universal Code Data.
	 *
	 * @param codeSet           the code set
	 * @param universalCode     the universal code
	 * @param universalCodeData the universal code data
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	@Override
	@Transactional
	public String update(String codeSet, String universalCode, Map<String, String> universalCodeData)
			throws ServiceException {
		logger.info(
				"Processing Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}",
				codeSet, universalCodeData, universalCode);
		try {
			Map<String, Object> dbObject = universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode);
			logger.info(
					"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}, Found Universal Code in database with id={}",
					codeSet, universalCodeData, universalCode, dbObject.get("id"));

			Date timeNow = new Date();

			universalCodeSetSQLDao.update(codeSet, universalCodeData, universalCode, timeNow);
			logger.info(
					"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}, Updated Universal Code in database",
					codeSet, universalCodeData, universalCode);

			if (codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets().contains(codeSet)) {
				updateCorrespondingSolrDocument(codeSet, universalCodeData, dbObject, timeNow);
			} else if (isUserTryingToUpdateStatus(universalCodeData, dbObject)) {
				logger.info(
						"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}, request is trying to update status",
						codeSet, universalCodeData, universalCode);
				int count = platformCodeSetSQLDao.disableEnablePlatformCodesMappedToUniversalCode(codeSet,
						universalCodeData.get(TranslationServiceStringConstant.STATUS), (int) dbObject.get("id"),
						timeNow);
				logger.info(
						"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}, updated status for {} platform codes associated",
						codeSet, universalCodeData, universalCode, count);
				return String.format(messageSourceUtil.getMessage("UNIVERSAL_CODE_UPDATED_ALONG_WITH_PLATFORM_CODES"),
						universalCodeData.get(TranslationServiceStringConstant.STATUS),
						universalCodeData.get(TranslationServiceStringConstant.STATUS), count);
			}
			logger.info(
					"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}, updated universal code & no associated platform codes",
					codeSet, universalCodeData, universalCode);
			return messageSourceUtil.getMessage("UNIVERSAL_CODE_UPDATED_SUCCESSFULLY");
		} catch (DaoException daoException) {
			Map<String, String> rejectedUniversalCode = new HashMap<>();
			rejectedUniversalCode.put(messageSourceUtil.getMessage("UNIVERSAL_CODE_IN_URL"), universalCode);
			logger.error(
					"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, Universal Code={}, Universal Code Not Found in database",
					codeSet, universalCodeData, universalCode);
			throw new ServiceException(daoException.getMessage(), rejectedUniversalCode, daoException.getErrorCode());
		}
	}

	/**
	 * Update corresponding solr document.
	 *
	 * @param codeSet the code set
	 * @param universalCodeData the universal code data
	 * @param dbObject the db object
	 * @param updatedTime the updated time
	 * @throws ServiceException the service exception
	 */
	private void updateCorrespondingSolrDocument(String codeSet, Map<String, String> universalCodeData,
			Map<String, Object> dbObject, Date updatedTime) throws ServiceException {
		logger.info(
				"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, DbObject={}, Time={}, is Updating Universal Code Solr Document",
				codeSet, universalCodeData, dbObject, updatedTime);

		try {
			dbObject.putAll(universalCodeData);
			codeSetSolrDao.update(codeSet, dbObject, updatedTime);
		} catch (DaoException daoException) {
			logger.error(
					"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, DbObject={}, Time={}, Error occured while updating Universal Code Solr Document",
					codeSet, universalCodeData, dbObject, updatedTime);
			throw new ServiceException(daoException.getMessage(), universalCodeData, daoException.getErrorCode());
		}
		logger.info(
				"Update Universal Code Request for the given CodeSet={}, Universal Code Data={}, DbObject={}, Time={}, successfully Updated Universal Code Solr Document",
				codeSet, universalCodeData, dbObject, updatedTime);
	}

	/**
	 * Checks if is user trying to update status.
	 *
	 * @param universalCodeData the universal code data
	 * @param dbObject the db object
	 * @return true, if is user trying to update status
	 */
	private boolean isUserTryingToUpdateStatus(Map<String, String> universalCodeData, Map<String, Object> dbObject) {
		return universalCodeData.get(TranslationServiceStringConstant.STATUS) != null
				&& !dbObject.get(TranslationServiceStringConstant.STATUS)
						.equals(universalCodeData.get(TranslationServiceStringConstant.STATUS));
	}

	/**
	 * Delete a Universal Code and Data.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	@Override
	@Transactional
	public ServiceResponse<Boolean> delete(String codeSet, String universalCode) throws ServiceException {
		logger.info("Processing delete operation of Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
		Map<String, Object> universalCodeObject;
		try {
			universalCodeObject=universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode);
		}catch(DaoException de) {
			Map<String, String> rejectedUniversalCode = new HashMap<>();
			rejectedUniversalCode.put(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN, universalCode);
			throw new ServiceException(messageSourceUtil.getMessage("UNIVERSAL_CODE_NOT_FOUND"), rejectedUniversalCode, CtsErrorCode.ENTITY_NOT_FOUND);
		}
		
		Date timeNow = new Date();
		
		Integer universalCodeId=new Integer(universalCodeObject.get(TranslationServiceStringConstant.ID).toString());
		int updatedPlatformCodesCount = 0;
		boolean isSearchableCodeSet = codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets().contains(codeSet);
		if (!isSearchableCodeSet) {
			logger.info("UniversalCode={} does not belong to searchable CodeSet category CodeSet={}. Checking and removing associated Platform Code mappings..", universalCode, codeSet);
			updatedPlatformCodesCount = platformCodeSetSQLDao.removePlatformCodeMappingForUniversalCodeId(codeSet, universalCodeId, timeNow);
		}
		
		int deletedRecordCount = 0;
		
		try {
			deletedRecordCount = universalCodeSetSQLDao.delete(codeSet, universalCode);
		} catch (DaoException daoException) {
			logger.error(
					"Exception occurred while deleting UniversalCode for the given  CodeSet={} and  UniversalCode={} ",
					codeSet, universalCode);
			Map<String, String> rejectedUniversalCode = new HashMap<>();
			rejectedUniversalCode.put(messageSourceUtil.getMessage("UNIVERSAL_CODE_IN_URL"), universalCode);
			throw new ServiceException(daoException.getMessage(), rejectedUniversalCode, daoException.getErrorCode());
		}
		if(deletedRecordCount > 0) {
			if(isSearchableCodeSet)
				logger.info("Successfully deleted Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
			else
				logger.info("Successfully deleted Universal Code identified by UniversalCode={} for the given CodeSet={}, {} Platform Code mappings also removed during this process", universalCode, codeSet, updatedPlatformCodesCount);
		}
		if (isSearchableCodeSet) {
			logger.info("Deleted UniversalCode={} for the given CodeSet={} belongs to serchable Code Set category. Removing the Solr document", universalCode, codeSet);
			try {
				codeSetSolrDao.deleteCodeSetsDocumentByUniversalCode(codeSet, universalCode);
			} catch(DaoException daoException) {
				logger.error(
						"Exception occurred while deleting Solr document UniversalCode for the given CodeSet={} and  UniversalCode={} ",
						codeSet, universalCode);
				Map<String, String> rejectedUniversalCode = new HashMap<>();
				rejectedUniversalCode.put("Universal code in URL", universalCode);
				throw new ServiceException(daoException.getMessage(), rejectedUniversalCode, daoException.getErrorCode());
			}
		}
		
		return new ServiceResponse<>(updatedPlatformCodesCount > 0?String.format(messageSourceUtil.getMessage("UNIVERSAL_CODE_DELETED_SUCCESSFULLY_ALONG_WITH_PLATFORM_CODES"),
				updatedPlatformCodesCount):messageSourceUtil.getMessage("UNIVERSAL_CODE_DELETED_SUCCESSFULLY"), true);
	}

	/**
	 * Gets the universal codes record count.
	 *
	 * @param codeSet the code set
	 * @param status  the status
	 * @return the universal codes record count
	 */
	@Override
	public int getUniversalCodesRecordCount(String codeSet, StatusEnum status) {
		logger.info("Finding total Universal Codes count for the given CodeSet={} and Status={}", codeSet, status);
		int universalCodesRecordCount = universalCodeSetSQLDao.getUniversalCodesRecordCount(codeSet, status);
		logger.info("Found Count={} Universal Codes for the given CodeSet={} and Status={}", universalCodesRecordCount,
				codeSet, status);
		return universalCodesRecordCount;
	}

}
