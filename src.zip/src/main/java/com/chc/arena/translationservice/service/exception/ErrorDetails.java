package com.chc.arena.translationservice.service.exception;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * The Class ValidationErrors.
 */
public class ErrorDetails implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6978877679906542082L;

	/** The issues. */
	private Map<String, Map<String, String>> issues;

	/**
	 * Instantiates a new validation errors.
	 */
	public ErrorDetails() {
		this.issues = new HashMap<>();
	}

	/**
	 * Gets the issues.
	 *
	 * @return the issues
	 */
	public Map<String, Map<String, String>> getIssues() {
		return issues;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "ErrorDetails [issues=" + issues + "]";
	}

}
