package com.chc.arena.translationservice.dao.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.dao.UniversalCodeSetSQLDao;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.querybuilder.SQLQueryBuilder;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Class UniversalCodeSetSQLDaoImpl.
 */
@Repository
public class UniversalCodeSetSQLDaoImpl implements UniversalCodeSetSQLDao {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(UniversalCodeSetSQLDaoImpl.class);

	/** The jdbc template. */
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/** The sql query builder. */
	@Autowired
	private SQLQueryBuilder sqlQueryBuilder;
	
	@Autowired
	private MessageSourceUtil messageSourceUtil;
	
	/**
	 * Get all Universal Codes.
	 *
	 * @param codeSet the code set
	 * @param from the from
	 * @param count the count
	 * @param status the status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the all
	 * @throws DaoException the dao exception
	 */
	@Override
	public List<Map<String, Object>> getAll(String codeSet, Integer page,
			Integer count, StatusEnum status, String orderBy, Direction direction) throws DaoException {
		
		List<Map<String, Object>> repoUniversalCodes = null;
		
		try {
			logger.info("Building query to get all Universal Codes for the given CodeSet={}", codeSet);
		
			String getAllUniversalCodesQuery = sqlQueryBuilder.buildUniversalRetrieveAllQuery(codeSet, page, count, status,
					orderBy, direction);
			
			MapSqlParameterSource getAllUniversalCodesParams = sqlQueryBuilder.setUniversalRetrieveAllParameters(status);
			
			logger.debug("To fetch all Universal Codes for the given CodeSet={}, built GetAllUniversalCodeQuery='{}'", codeSet, getAllUniversalCodesQuery);
			
			repoUniversalCodes = namedParameterJdbcTemplate.queryForList(getAllUniversalCodesQuery, getAllUniversalCodesParams);
			
			logger.debug("Found UniversalCodesCount={} records for the given CodeSet={}", repoUniversalCodes.size(), codeSet);
			
		} catch (DataAccessException dataAccessException) {
			
			logger.error("Error occured while trying to fetch Universal Codes for the given CodeSet={}. DaoException={}", codeSet, dataAccessException.getMessage());
			
			throw new DaoException(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR"),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
		
		return repoUniversalCodes;
	}

	/**
	 * Gets the by id.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @return the by id
	 */
	@Override
	public Map<String, Object> getById(String codeSet, String universalIdInPlatform) {
		Map<String, Object> dbObject=null;
		logger.info("Building query to get Universal Code data for the given [code-set] {} and [universal-code-id] {}", codeSet, universalIdInPlatform);
		try {
			String query = sqlQueryBuilder.buildUniversalRetrieveQueryById(codeSet);
			MapSqlParameterSource params = sqlQueryBuilder.setUniversalRetrieveParametersById(universalIdInPlatform);
			dbObject = namedParameterJdbcTemplate.queryForMap(query, params);
			logger.debug("For the given [code-set] {} and [universal-code-id] {}, Universal Code Data found in db {}", codeSet, universalIdInPlatform, dbObject);
		} catch (EmptyResultDataAccessException emptyResultDataAccessException) {
			return null;
		}
		return dbObject;
	}

	/**
	 * Gets the by universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @return the by universal code
	 * @throws DaoException the dao exception
	 */
	@Override
	public Map<String, Object> getByUniversalCode(String codeSet, String universalCode) throws DaoException {
		try {
			logger.info("Building query to get Universal Code for the given CodeSet={} and UniversalCode={}", codeSet, universalCode);
			String query = sqlQueryBuilder.buildUniversalRetrieveQuery(codeSet);
			MapSqlParameterSource params = sqlQueryBuilder.setUniversalRetrieveParameters(universalCode);
			
			logger.debug("To fetch Universal Code for the given CodeSet={} and UniversalCode={}, built UniversalRetrieveQuery='{}'", codeSet, universalCode, query);
			
			Map<String, Object> dbObject = namedParameterJdbcTemplate.queryForMap(query, params);
			logger.debug("For the given CodeSet={} and UniversalCode={}, Universal Code Data found in db {}", codeSet, universalCode, dbObject);
			return dbObject;
		} catch(EmptyResultDataAccessException emptyResultDataAccessException) {
			logger.error("No Universal Code data found in repository for the given CodeSet={} and UniversalCode={}", codeSet, universalCode);
			throw new DaoException(messageSourceUtil.getMessage("UNIVERSAL_CODE_NOT_FOUND"), CtsErrorCode.ENTITY_NOT_FOUND);
		}
	}

	/**
	 * Gets the mapped universal code.
	 *
	 * @param codeSet the code set
	 * @param platformCodeObject the platform code object
	 * @return the mapped universal code
	 * @throws DaoException the dao exception
	 */
	@Override
	public Map<String, Object> getMappedUniversalCode(String codeSet, Map<String, String> platformCodeObject) throws DaoException {
		logger.info("Fetching Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}", codeSet, platformCodeObject);
		try { 
			String query = sqlQueryBuilder.buildUniversalMappedPlatformQuery(codeSet);
			MapSqlParameterSource params = sqlQueryBuilder.setUniversalAndPlatformMappingParameters(codeSet, platformCodeObject);			
			logger.debug("Fetching Mapped Universal Code for the given CodeSet={}, Platfrom Code Data={}, Query={}, Params={}", codeSet, platformCodeObject, query, params);
			
			Map<String, Object> dbObject = namedParameterJdbcTemplate.queryForMap(query, params);
			logger.info("getMappedUniversalCode [END]: CodeSet: {}, Platform Object: {}, Found Universal Code: {}", codeSet, platformCodeObject, dbObject.get(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN));
			return dbObject;
		} catch(EmptyResultDataAccessException emptyResultDataAccessException) {
			logger.error("getMappedUniversalCode [END]: CodeSet: {}, Platform Object: {}, Platform Object not found", codeSet, platformCodeObject);
			throw new DaoException(messageSourceUtil.getMessage("PLATFORM_CODE_IDENTIFIER_NOT_FOUND"), CtsErrorCode.ENTITY_NOT_FOUND);
		}
	}

	/**
	 * Insert.
	 *
	 * @param codeSet the code set
	 * @param codeObject the code object
	 * @param currentDateTimeStamp the current date time stamp
	 * @return the int
	 * @throws DaoException the dao exception
	 */
	@Override
	public int insert(String codeSet, Map<String, String> codeObject,Date currentDateTimeStamp) throws DaoException {
		logger.info("insert [START]: CodeSet: {}, Universal Code Object: {}", codeSet, codeObject);
		int rowCount=0;
		try {
			String query = sqlQueryBuilder.buildUniversalInsertQuery(codeSet,codeObject);
			MapSqlParameterSource params = sqlQueryBuilder.setUniversalInsertParameters(codeObject,currentDateTimeStamp);
			rowCount=namedParameterJdbcTemplate.update(query, params);
			logger.info("insert [END]: CodeSet: {}, Universal Code Object: {}", codeSet, codeObject);
		}catch(DuplicateKeyException duplicateKeyException) {
			throw new DaoException(messageSourceUtil.getMessage("UNIVERSAL_CODE_ALREADY_EXIST"), CtsErrorCode.UNIVERSAL_CODE_ALREADY_EXIST);
		}
		return rowCount;
	}

	@Override
	public void update(String codeSet, Map<String, String> universalCodeData, String universalCode, Date updatedTime) {
		logger.info("Updating Universal Code for the given CodeSet={}, Universal Code Data={}, Time={}", codeSet, universalCodeData, updatedTime);
		
		String query = sqlQueryBuilder.buildUniversalUpdateQuery(codeSet, universalCodeData);
		MapSqlParameterSource params = sqlQueryBuilder.setUniversalUpdateParameters(codeSet, universalCodeData, universalCode, updatedTime);
		logger.debug("Updating Universal Code for the given CodeSet={}, Universal Code Data={}, Time={}, Query={}, Params={}", codeSet, universalCodeData, updatedTime, query, params);

		int count = namedParameterJdbcTemplate.update(query, params);
		logger.info("Updating Universal Code for the given CodeSet={}, Universal Code Data={}, Time={}, Updated {} records", codeSet, universalCodeData, updatedTime, count);
	}

	/**
	 * Delete.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 */
	@Override
	public int delete(String codeSet, String universalCode) throws DaoException {
		logger.info("Deleting Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
		String query = sqlQueryBuilder.buildUniversalDeleteQuery(codeSet);
		MapSqlParameterSource params = sqlQueryBuilder.setUniversalDeleteParameters(universalCode);
		int deletedRecordCount = 0;
		try{
			deletedRecordCount = namedParameterJdbcTemplate.update(query, params);
		}catch(DataAccessException dataAccessException) {
			logger.error("Error occured while trying to delete Universal Codes for the given CodeSet={} and UniversalCode={}. DaoException={}", codeSet, universalCode, dataAccessException.getMessage());
			
			throw new DaoException(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR"),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
		
		logger.info("Deleted {} Universal Code for the given CodeSet={} and UniversalCode={}", deletedRecordCount, codeSet, universalCode);
		return deletedRecordCount;
	}

	@Override
	public Map<String, Object> getUniversalCodeRecordsToVerifyStatus(String codeSet, Map<String, String> platformCodeData) {
		logger.info("Start retrieving universal data based on mapped object : {}",  platformCodeData);
		Map<String, Object> dbObject=null;
		try {
			dbObject=getByUniversalCode(codeSet, platformCodeData.get(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD));
		}catch (DaoException daoException) {
			logger.info("No universal codes data found for given mapped object {}=", platformCodeData);
			return null;
		}
		logger.info("End retrieving universal data based on mapped object : {}",  platformCodeData);
		return dbObject;
	}

	/**
	 * Gets the universal codes record count.
	 *
	 * @param codeSet the code set
	 * @param status the status
	 * @return the universal codes record count
	 */
	@Override
	public int getUniversalCodesRecordCount(String codeSet, StatusEnum status) {
		
		String query = sqlQueryBuilder.buildUniversalRecordCountQuery(codeSet, status);
		MapSqlParameterSource universalCodesRecordsCountParams = sqlQueryBuilder.setUniversalRetrieveAllParameters(status);
		return namedParameterJdbcTemplate.queryForObject(query, universalCodesRecordsCountParams, Integer.class);
	}

	@Override
	public boolean isUniversalCodeExist(String codeSet, String universalCode) {
		logger.info("Checking if the Universal Code identified by UniversalCode={} exist for the given CodeSet={}", universalCode, codeSet);
		try {
			this.getByUniversalCode(codeSet, universalCode);
		}catch(DaoException de) {
			return false;
		}
		logger.info("Universal Code identified by UniversalCode={} exist for the given CodeSet={}", universalCode, codeSet);
		return true;
	}

	@Override
	public boolean isUniversalCodeDisabled(String codeSet, String universalCode) {
		return false;
	}


}
