/**
 * 
 */
package com.chc.arena.translationservice.model;

/**
 * The Enum Direction.
 *
 * @author narendra.dubey
 */
public enum Direction {

	/** The asc. */
	ASC,
	
	/** The desc. */
	DESC;
}
