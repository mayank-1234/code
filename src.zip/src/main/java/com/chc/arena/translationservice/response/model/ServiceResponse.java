package com.chc.arena.translationservice.response.model;

import com.chc.arena.translationservice.service.exception.ErrorDetails;

/**
 * The Class ServiceResponse.
 *
 * @param <T> the generic type
 */
public class ServiceResponse<T> {

	/** The message. */
	private String message;
	
	/** The body. */
	private T body;
	
	/** The error details. */
	private ErrorDetails errorDetails;

	/**
	 * Instantiates a new service response.
	 *
	 * @param message the message
	 * @param body the body
	 */
	public ServiceResponse(String message, T body) {
		this.message = message;
		this.body = body;
	}
	
	/**
	 * Instantiates a new service response.
	 *
	 * @param message the message
	 * @param errorDetails the error details
	 * @param body the body
	 */
	public ServiceResponse(String message, ErrorDetails errorDetails , T body) {
		this.message = message;
		this.errorDetails = errorDetails;
		this.body=body;
	}
	
	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	
	/**
	 * Gets the body.
	 *
	 * @return the body
	 */
	public T getBody() {
		return body;
	}
	
	/**
	 * Gets the error details.
	 *
	 * @return the error details
	 */
	public ErrorDetails getErrorDetails() {
		return errorDetails;
	}
}
