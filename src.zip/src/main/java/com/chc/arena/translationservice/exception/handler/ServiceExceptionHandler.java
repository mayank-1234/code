package com.chc.arena.translationservice.exception.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.chc.arena.translationservice.response.model.ApiError;
import com.chc.arena.translationservice.response.model.ApiResponse;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.response.model.SubError;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.InvalidRequestException;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.util.MessageSourceUtil;

/**
 * The Class ServiceExceptionHandler.
 */
@ControllerAdvice
public class ServiceExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger loger = LoggerFactory.getLogger(ServiceExceptionHandler.class);

	private static final String LOG_MESSAGE = "Preparing Api response for exception: {}";
	
	private static final String GENERIC_ERROR_MESSAGE="GENERIC_ERROR_MESSAGE";
	
	@Autowired
	private MessageSourceUtil messageSourceUtil;

	/**
	 * Handle all exception.
	 *
	 * @param exception the exception
	 * @param request   the request
	 * @return the response entity
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiResponse> handleAllException(Exception exception, WebRequest request) {
		loger.info(LOG_MESSAGE, exception.getMessage());
		String apiResponseMessage = messageSourceUtil.getMessage(GENERIC_ERROR_MESSAGE)
				+ ((ServletWebRequest) request).getRequest().getRequestURI();

		ApiResponse apiResponse = new ApiResponse(ApiStatus.ERROR, null, apiResponseMessage);
		ApiError apiError = new ApiError();
		apiError.setErrorCode(CtsErrorCode.INTERNAL_SERVER_ERROR);
		apiResponse.setApiError(apiError);
		apiResponse.setStatus(ApiStatus.ERROR);
		apiError.setMessage(exception.getCause().getMessage());
		return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handle service exception.
	 *
	 * @param exception the exception
	 * @param request   the request
	 * @return the response entity
	 */
	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<ApiResponse> handleServiceException(ServiceException exception, WebRequest request) {
		loger.info(LOG_MESSAGE, exception.getMessage());
		String apiResponseMessage = messageSourceUtil.getMessage(GENERIC_ERROR_MESSAGE)
				+ ((ServletWebRequest) request).getRequest().getRequestURI();

		ApiResponse apiResponse = new ApiResponse(ApiStatus.ERROR, null, apiResponseMessage);
		ApiError apiError = new ApiError();
		apiError.setErrorCode(exception.getErrorCode());
		apiResponse.setApiError(apiError);
		apiError.setMessage(exception.getMessage());
		List<SubError> subErrors = exception.getErrorDetails() != null
				? exception.getErrorDetails().getIssues().entrySet().stream()
						.map(entry -> new SubError(entry.getValue(), entry.getKey())).collect(Collectors.toList())
				: null;
		apiError.setSubErrors(subErrors);

		return new ResponseEntity<>(apiResponse, exception.getErrorCode().getHttpStatus());
	}

	/**
	 * Handle invalid request exception.
	 *
	 * @param exception the exception
	 * @param request   the request
	 * @return the response entity
	 */
	@ExceptionHandler(InvalidRequestException.class)

	public ResponseEntity<ApiResponse> handleInvalidRequestException(InvalidRequestException exception,
			WebRequest request) {
		loger.info(LOG_MESSAGE, exception.getMessage());
		String apiResponseMessage = messageSourceUtil.getMessage(GENERIC_ERROR_MESSAGE)
				+ ((ServletWebRequest) request).getRequest().getRequestURI();
		ApiResponse apiResponse = new ApiResponse(ApiStatus.ERROR, null, apiResponseMessage);
		ApiError apiError = new ApiError();
		apiError.setErrorCode(exception.getErrorCode());
		apiResponse.setApiError(apiError);
		apiError.setMessage(exception.getMessage());
		List<SubError> subErrors = exception.getErrorDetails().getIssues().entrySet().stream()
				.map(entry -> new SubError(entry.getValue(), entry.getKey())).collect(Collectors.toList());
		apiError.setSubErrors(subErrors);
		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handle method argument type mismatch exception.
	 *
	 * @param exception the exception
	 * @return the response entity
	 */
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ApiResponse> handleMethodArgumentTypeMismatchException(
			MethodArgumentTypeMismatchException exception) {
		String message = "Invalid Value for parameter: " + exception.getName();
		ApiResponse apiResponse = new ApiResponse();
		ApiError apiError = new ApiError();
		apiError.setErrorCode(CtsErrorCode.BAD_REQUEST);
		apiResponse.setApiError(apiError);
		apiResponse.setStatus(ApiStatus.ERROR);
		apiError.setMessage("Invalid Request Parameter/Body");
		SubError subError = new SubError(null, message);
		List<SubError> subErrors = new ArrayList<>();
		subErrors.add(subError);
		apiError.setSubErrors(subErrors);

		return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
	}

}
