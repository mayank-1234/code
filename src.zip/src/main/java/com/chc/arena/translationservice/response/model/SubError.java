package com.chc.arena.translationservice.response.model;

import java.util.Map;

/**
 * The Class SubError.
 */
public class SubError {
	
	/** The rejected value. */
	private Map<String, String> rejectedValue;
	
	/** The message. */
	private String message;
	
	
	/**
	 * Instantiates a new sub error.
	 *
	 * @param rejectedValue the rejected value
	 * @param message the message
	 */
	public SubError(Map<String, String> rejectedValue, String message) {
		super();
		this.rejectedValue = rejectedValue;
		this.message = message;
	}
	
	public SubError() {
		super();
	}
		
	/**
	 * Gets the rejected value.
	 *
	 * @return the rejected value
	 */
	public Map<String, String> getRejectedValue() {
		return rejectedValue;
	}
	
	/**
	 * Sets the rejected value.
	 *
	 * @param rejectedValue the rejected value
	 */
	public void setRejectedValue(Map<String, String> rejectedValue) {
		this.rejectedValue = rejectedValue;
	}
	
	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	
	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}			
}
