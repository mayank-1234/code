package com.chc.arena.translationservice.dao;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.UpdateResponse;

import com.chc.arena.translationservice.service.exception.DaoException;

/**
 * The Interface CodeSetSolrDao.
 */
public interface CodeSetSolrDao {

	/**
	 * Search.
	 * @param codeSet
	 * @param platformObject
	 * @param from
	 * @param count
	 * @return
	 * @throws DaoException
	 */
	public List<Map<String, String>> search(String codeSet, Map<String, String> platformObject, Integer from, Integer count)
			throws DaoException;
	
	/**
	 * Update code sets document.
	 *
	 * @param codeSet    the code set
	 * @param codeObject the code object
	 * @param updatedTime
	 * @return the update response
	 * @throws DaoException if there is an error solr server or error while
	 *                      communicating with Solr
	 */
	public UpdateResponse update(String codeSet, Map<String, Object> codeObject, Date updatedTime) throws DaoException;

	/**
	 * Insert.
	 *
	 * @param codeSet the code set
	 * @param universalCodeData the universal code data
	 * @return the update response
	 * @throws DaoException the dao exception if there is an error solr server or error while
	 * 										  communicating with Solr
	 */										  
	public UpdateResponse insert(String codeSet, Map<String, Object> universalCodeData) throws DaoException;

	/**
	 * Delete code sets document.
	 *
	 * @param codeSet       the code set
	 * @param universalCode
	 */
	public UpdateResponse deleteCodeSetsDocumentByUniversalCode(String codeSet, String universalCode)
			throws DaoException;

	/**
	 * Check solr health status.
	 *
	 * @return the string
	 * @throws SolrServerException the solr server exception
	 * @throws IOException         Signals that an I/O exception has occurred.
	 */
	public String checkSolrHealthStatus(String codeSet) throws SolrServerException, IOException;

}
