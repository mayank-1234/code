package com.chc.arena.translationservice.validation.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.service.RequestValidationService;
import com.chc.arena.translationservice.validation.util.ValidationUtil;

/**
 * The Class RequestValidationServiceImpl.
 */
@Service
public class RequestValidationServiceImpl implements RequestValidationService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(RequestValidationServiceImpl.class);

	/** The code set meta data util. */
	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Autowired
	private MessageSourceUtil messageSourceUtil;

	/**
	 * Checks if is valid code set.
	 *
	 * @param codeSet          the code set
	 * @param validationErrors the validation errors
	 * @return true, if is valid code set
	 */
	@Override
	public boolean isValidCodeSet(String codeSet, ErrorDetails validationErrors) {
		logger.info("RequestValidationServiceImpl.isValidCodeSet");
		boolean isValid = codeSetMetaDataUtil.getCodeSets().contains(codeSet);
		if (!isValid) {
			ValidationUtil.rejectInvalidCodeSet(validationErrors, codeSet);
		}
		return isValid;
	}

	/**
	 * Checks if is valid universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param validationErrors the validation errors
	 * @return true, if is valid universal code
	 */
	@Override
	public boolean isValidUniversalCode(String codeSet, String universalCode, ErrorDetails validationErrors) {
		String universalCodeFieldValueRegex = codeSetMetaDataUtil.getUniversalCodeFieldValueRegex(codeSet, "universal_code");
		boolean isValid = universalCode.matches(universalCodeFieldValueRegex);
		if (!isValid) {
			ValidationUtil.rejectInvalidFieldValue(validationErrors, "universal-code", universalCode,
					universalCodeFieldValueRegex);
		}
		return isValid;
	}

	/**
	 * Checks if is valid universal code create request.
	 *
	 * @param codeSet          the code set
	 * @param requestObject    the request object
	 * @param validationErrors the validation errors
	 * @return true, if is valid universal code create request
	 */
	@Override
	public boolean isValidUniversalCodeCreateRequest(String codeSet, Map<String, String> requestObject,
			ErrorDetails validationErrors) {
		List<String> validFields = codeSetMetaDataUtil.getUniversalCodeFields(codeSet);
		List<String> requiredFields = codeSetMetaDataUtil.getUniversalCodeRequiredFields(codeSet);
		requiredFields.stream().filter(field -> !requestObject.containsKey(field)).forEach(
				missingRequiredField -> ValidationUtil.missingRequiredField(validationErrors, missingRequiredField));
		requestObject.keySet().stream().forEach(field -> {
			String fieldValue = requestObject.get(field);
			if (!validFields.contains(field)) {
				ValidationUtil.rejectInvalidField(validationErrors, field, fieldValue);
			} else {
				validateValidFields(codeSet, validationErrors, requiredFields, field, fieldValue);
				
			}
		});
		return ValidationUtil.isEmpty(validationErrors);
	}


	private void validateValidFields(String codeSet, ErrorDetails validationErrors, List<String> requiredFields, String field,
			String fieldValue) {
		String regex = codeSetMetaDataUtil.getUniversalCodeFieldValueRegex(codeSet, field);
		if(regex!=null && !regex.isEmpty()) {
			if (requiredFields.contains(field)) {
				validateRequiredFields(validationErrors, field, fieldValue, regex);
			} else {
				if (fieldValue != null &&  !Pattern.matches(regex, fieldValue)) {
					ValidationUtil.rejectInvalidFieldValue(validationErrors, field, fieldValue, regex);
				}
			}
		}else {
			ValidationUtil.rejectField(validationErrors, field, fieldValue);
		}
	}

	private void validateRequiredFields(ErrorDetails validationErrors, String field, String fieldValue, String regex) {
		if (fieldValue != null) {
			if (!Pattern.matches(regex, fieldValue)) {
				ValidationUtil.rejectInvalidFieldValue(validationErrors, field, fieldValue, regex);
			}
		} else {
			ValidationUtil.rejectNullFieldValue(validationErrors, field, fieldValue, regex);
		}
	}

	/**
	 * Checks if is valid universal code update request.
	 *
	 * @param codeSet the code set
	 * @param requestObject the request object
	 * @param universalCode the universal code
	 * @param validationErrors the validation errors
	 * @return true, if is valid universal code update request
	 */
	@Override
	public boolean isValidUniversalCodeUpdateRequest(String codeSet, Map<String, String> requestObject, String universalCode, ErrorDetails validationErrors) {
		List<String> validFields = codeSetMetaDataUtil.getUniversalCodeFields(codeSet);
		List<String> requiredFields = codeSetMetaDataUtil.getUniversalCodeRequiredFields(codeSet);
		String regexForUniversalCode = codeSetMetaDataUtil.getUniversalCodeFieldValueRegex(codeSet, TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN);
		if (!Pattern.matches(regexForUniversalCode, universalCode)) {
			ValidationUtil.rejectInvalidFieldValue(validationErrors, TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN, universalCode, regexForUniversalCode);
		}
		requestObject.keySet().stream().forEach(field -> {
			String fieldValue = requestObject.get(field);
			if(field.equalsIgnoreCase(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN)) {
				ValidationUtil.rejectField(validationErrors, field, fieldValue);
			}
			else if (!validFields.contains(field)) {
				ValidationUtil.rejectInvalidField(validationErrors, field, fieldValue);
			} else {
				String regex = codeSetMetaDataUtil.getUniversalCodeFieldValueRegex(codeSet, field);
				if(regex == null) {
					ValidationUtil.rejectField(validationErrors, field, fieldValue);
				}
				else if (fieldValue == null) {
					if(requiredFields.contains(field)) {
						ValidationUtil.missingRequiredField(validationErrors, field);
					}
				}
				else if (!Pattern.matches(regex, fieldValue)) {
					ValidationUtil.rejectInvalidFieldValue(validationErrors, field, fieldValue, regex);
				}
			}
		});

		return ValidationUtil.isEmpty(validationErrors);
	}
	
	/**
	 * Checks if is valid request for get mapped universal code.
	 *
	 * @param codeSet the code set
	 * @param requestObject the request object
	 * @param validationErrors the validation errors
	 * @return true, if is valid request for get mapped universal code
	 */
	@Override
	public boolean isValidRequestForGetMappedUniversalCode(String codeSet, Map<String, String> requestObject,
			ErrorDetails validationErrors) {
		List<String> validFields = codeSetMetaDataUtil.getPlatformCodeFields(codeSet);
		List<String> requiredFields = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		requestObject.keySet().stream().forEach(field -> {
			String fieldValue = requestObject.get(field);
			if (!validFields.contains(field)) {
				ValidationUtil.rejectInvalidField(validationErrors, field, fieldValue);
			} else if(!requiredFields.contains(field)) {
				ValidationUtil.rejectNonKeyField(validationErrors, field, fieldValue);
			} else {
				String regex = codeSetMetaDataUtil.getPlatformCodeFieldValueRegex(codeSet, field);
				if (!Pattern.matches(regex, fieldValue)) {
					ValidationUtil.rejectInvalidFieldValue(validationErrors, field, fieldValue, regex);
				}
			}
		});
		requiredFields.stream().filter(field -> !requestObject.containsKey(field)).forEach(
				missingRequiredField -> ValidationUtil.missingRequiredField(validationErrors, missingRequiredField));

		return ValidationUtil.isEmpty(validationErrors);
	}

	/**
	 * Checks if is valid code set for search or mapping request.
	 *
	 * @param codeSet the code set
	 * @param validationErrors the validation errors
	 * @param isMappingRequest the is mapping request
	 * @return true, if is valid code set for search or mapping request
	 */
	@Override
	public boolean isValidCodeSetForSearchOrMappingRequest(String codeSet, ErrorDetails validationErrors, boolean isMappingRequest) {
		boolean isAdvancedSearchEnabledCodeSet = codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets().contains(codeSet);
		boolean isValid = isMappingRequest ? !isAdvancedSearchEnabledCodeSet : isAdvancedSearchEnabledCodeSet;
		if(!isValid) {
			ValidationUtil.rejectInvalidCodeSetForSerachOrMappingRequest(validationErrors, codeSet, isMappingRequest);
		}
		return isValid;
	}
	
	/**
	 * Checks if is valid search request.
	 *
	 * @param codeSet the code set
	 * @param platformCodeData the platform code data
	 * @param validationErrors the validation errors
	 * @return true, if is valid search request
	 */
	@Override
	public boolean isValidSearchRequest(String codeSet, Map<String, String> platformCodeData, ErrorDetails validationErrors) {
		List<String> validFields = codeSetMetaDataUtil.getUniversalCodeFields(codeSet);
		List<String> advancedSearchRequiredFields = codeSetMetaDataUtil.getAdvancedSearchRequiredFields(codeSet);
		
		platformCodeData.keySet().stream().forEach(field -> {
			String fieldValue = platformCodeData.get(field);
			if (!validFields.contains(field)) {
				ValidationUtil.rejectInvalidField(validationErrors, field, fieldValue);
			}
		});
		
		advancedSearchRequiredFields.stream().filter(field -> !platformCodeData.containsKey(field)).forEach(
				missingRequiredField -> ValidationUtil.missingRequiredField(validationErrors, missingRequiredField));
		return ValidationUtil.isEmpty(validationErrors);
	}

	@Override
	public boolean isValidUpdateMappingRequest(String codeSet,  List<Map<String, String>> platformCodeObject, ErrorDetails validationErrors) {
		logger.info("Start Validating update mapping request for the given CodeSet={} ",codeSet);
		List<String> validFields = codeSetMetaDataUtil.getPlatformCodeFields(codeSet);
		List<String> requiredFields = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		Set<String> validMappings = new HashSet<>();
		platformCodeObject.forEach(entry -> {
			requiredFields.stream().filter(field -> !entry.containsKey(field)).forEach(
					missingRequiredField -> ValidationUtil.rejectInvalidCombination(validationErrors, missingRequiredField, entry.get(missingRequiredField)));
			entry.keySet().stream().forEach(field -> {
				String fieldValue = entry.get(field);
				if (!validFields.contains(field)) {
					ValidationUtil.rejectInvalidField(validationErrors, field, fieldValue);
				}else{
					String regex = codeSetMetaDataUtil.getPlatformCodeFieldValueRegex(codeSet, field);
					if (regex == null) {
						ValidationUtil.rejectField(validationErrors, field, fieldValue);
					} else {
						updateMappingValidation(validationErrors, entry, field, fieldValue, regex);
					}
				}
			});
			if(ValidationUtil.isEmpty(validationErrors) && !entry.containsKey(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD) 
					&&  !entry.containsKey(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN)) {
				ValidationUtil.missingUniversalCodeFieldOrMappingStatus(validationErrors,entry,requiredFields);
			}
			validateRepetativeMappings(codeSet, validationErrors, validMappings, entry);
		});
		return ValidationUtil.isEmpty(validationErrors);
	}

	private void updateMappingValidation(ErrorDetails validationErrors, Map<String, String> entry, String field,
			String fieldValue, String regex) {
		if(!(field.equalsIgnoreCase(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD) && fieldValue==null)) {
			validateRequiredFields(validationErrors, field, fieldValue, regex);
		}else {
			if(entry.containsKey(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN)) {
				ValidationUtil.invalidDeleteMappingRequest(validationErrors, entry);
			}
		}
	} 

	private void validateMultipleUniversalCodeMapping(String codeSet, ErrorDetails validationErrors, Set<String> validMappings,
			Map<String, String> entry) {
		logger.info("Start Validating multiple mapping of universal code with respect to platform codes for mapped platform data {}  ",entry);
		List<String> requiredFields = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		String key= requiredFields.stream().map(entry::get).map(String::trim).collect(Collectors.joining());
		if(!validMappings.add(key)) {
			logger.info("Repeated mapping rejected values in input request={} ",entry);
			ValidationUtil.rejectMulitipleUniversalCodeMapping(validationErrors, entry,requiredFields);
		}
		logger.info("End Validating multiple mapping of universal code with respect to platform codes for mapped platform data {}  ",entry);
	}
	
	/**
	 * Check validations in query parameters.
	 *
	 * @param validationErrors the validation errors
	 * @param page the page
	 * @param count the count
	 * @return true, if successful
	 */
	public boolean checkValidationsInQueryParameters(ErrorDetails validationErrors, Integer page, Integer count,String platformIdentifier,String codeSet) {
		boolean isValid = true;
		if(page != null && page <= 0) {
			HashMap<String, String> rejectedValues = new HashMap<>();
			rejectedValues.put("page", String.valueOf(page));
			validationErrors.getIssues().put(messageSourceUtil.getMessage("INVALID_PAGE_IN_REQUEST"), rejectedValues);	
			isValid = false;
		}
		if(count != null && count <= 0) {
			HashMap<String, String> rejectedValues = new HashMap<>();
			rejectedValues.put("count", String.valueOf(count));
			validationErrors.getIssues().put(messageSourceUtil.getMessage("INVALID_COUNT_IN_REQUEST"), rejectedValues);
			isValid = false;
		}
		if(platformIdentifier!=null && !platformIdentifier.isEmpty()) {
			String regex = codeSetMetaDataUtil.getPlatformCodeFieldValueRegex(codeSet, TranslationServiceStringConstant.PLATFORM_IDENTIFIER_COLUMN);
			if (!Pattern.matches(regex, platformIdentifier)) {
				ValidationUtil.rejectInvalidFieldValue(validationErrors, platformIdentifier, TranslationServiceStringConstant.PLATFORM_IDENTIFIER_COLUMN, regex);
			}
		}
		
		return isValid;
	}

	@Override
	public boolean isValidRequestForPlatformCodesInsertion(String codeSet, List<Map<String, String>> platformCodes,
			ErrorDetails validationErrors) {
		Set<String> validMappings = new HashSet<>();
		platformCodes.forEach(platformCodeData ->{
			logger.info("Validating insert Platform Code request for the given Platform");
			List<String> requiredKeyFields = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
			List<String> validFields = codeSetMetaDataUtil.getPlatformCodeFields(codeSet);
			platformCodeData.keySet().stream().forEach(field -> {
				String fieldValue = platformCodeData.get(field);
				if (!validFields.contains(field)) {
					ValidationUtil.rejectInvalidField(validationErrors, field, fieldValue);
				} else if(!requiredKeyFields.contains(field) && !field.equalsIgnoreCase(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN)) {
					ValidationUtil.rejectNonKeyField(validationErrors, field, fieldValue);
				} else {
					String regex = codeSetMetaDataUtil.getPlatformCodeFieldValueRegex(codeSet, field);
					if (!Pattern.matches(regex, fieldValue)) {
						ValidationUtil.rejectInvalidFieldValue(validationErrors, field, fieldValue, regex);
					}
				}
			});
			
			validateRepetativeMappings(codeSet, validationErrors, validMappings, platformCodeData);
			if(platformCodeData.containsKey(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN)) {
				String regexForUniversalCode = codeSetMetaDataUtil.getUniversalCodeFieldValueRegex(codeSet, TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN);
				String universalCode = platformCodeData.get(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN);
				if (!Pattern.matches(regexForUniversalCode, universalCode )) {
					ValidationUtil.rejectInvalidFieldValue(validationErrors, TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN, universalCode, regexForUniversalCode);
				}
			}
			   
		});
		
		return ValidationUtil.isEmpty(validationErrors);
	}

	private void validateRepetativeMappings(String codeSet, ErrorDetails validationErrors, Set<String> validMappings,
			Map<String, String> platformCodeData) {
		if(ValidationUtil.isEmpty(validationErrors)){
			validateMultipleUniversalCodeMapping(codeSet, validationErrors, validMappings, platformCodeData);
		}
	} 

	@Override
	public boolean isValidGetRequestForPlatFormCodes(String codeSet, Map<String, String> platformCodeObject,ErrorDetails validationErrors) {
		logger.info(" Validating get paltform code request for given request object={}",platformCodeObject);
		List<String> requiredFields = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		platformCodeObject.keySet().stream().forEach(field -> {
			String fieldValue = platformCodeObject.get(field);
			if(!requiredFields.contains(field)) { 
				ValidationUtil.rejectNonKeyField(validationErrors, field, fieldValue);
			} else {
				String regex = codeSetMetaDataUtil.getPlatformCodeFieldValueRegex(codeSet, field);
				validateRequiredFields(validationErrors, field, fieldValue, regex);
			}
		});
		requiredFields.stream().filter(field -> !platformCodeObject.containsKey(field)).forEach(
				missingRequiredField -> ValidationUtil.missingRequiredField(validationErrors, missingRequiredField));
		logger.info(" Validation error ={}, to get paltform code request for given request object={}",validationErrors,platformCodeObject);
		return ValidationUtil.isEmpty(validationErrors);
	}
	
}
