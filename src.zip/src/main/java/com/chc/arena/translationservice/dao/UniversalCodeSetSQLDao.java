package com.chc.arena.translationservice.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Interface UniversalCodeSetSQLDao.
 */
public interface UniversalCodeSetSQLDao {

	/**
	 * Gets the all.
	 *
	 * @param codeSet the code set
	 * @param from the from
	 * @param count the count
	 * @param status the status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the all
	 * @throws DaoException the dao exception
	 */
	public List<Map<String, Object>> getAll(String codeSet, Integer page,
			Integer count, StatusEnum status, String orderBy, Direction direction) throws DaoException;

	/**
	 * Gets the by id.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return the by id
	 */
	public Map<String, Object> getById(String codeSet, String universalCode);

	/**
	 * Gets the by universal code.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return the by universal code
	 * @throws DaoException if universal code is not present in db.
	 */
	public Map<String, Object> getByUniversalCode(String codeSet, String universalCode) throws DaoException;

	/**
	 * Gets the mapped universal code.
	 *
	 * @param codeSet            the code set
	 * @param platformCodeObject the code object
	 * @return the mapped universal code
	 * @throws DaoException the dao exception
	 */
	public Map<String, Object> getMappedUniversalCode(String codeSet, Map<String, String> platformCodeObject)
			throws DaoException;

	/**
	 * Insert.
	 *
	 * @param codeSet    the code set
	 * @param codeObject the code object
	 * @param currentDateTimeStamp the current date time stamp
	 * @return the int
	 * @throws DaoException the dao exception
	 */
	public int insert(String codeSet, Map<String, String> codeObject,Date currentDateTimeStamp) throws DaoException;

	/**
	 * Update.
	 *
	 * @param codeSet       the code set
	 * @param universalCodeData the universal code data
	 * @param universalCode the universal code
	 * @param updatedTime
	 */
	public void update(String codeSet, Map<String, String> universalCodeData, String universalCode, Date updatedTime);

	
	/**
	 * Delete Universal Code for the given UniversalCode and CodeSet..
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @return the int
	 * @throws DaoException the dao exception
	 */
	public int delete(String codeSet, String universalCode) throws DaoException;

	/**
	 * Gets the universal code records to verify status.
	 *
	 * @param codeSet the code set
	 * @param platformCodeData the platform code data
	 * @return the universal code records to verify status
	 */
	public Map<String, Object> getUniversalCodeRecordsToVerifyStatus(String codeSet, Map<String, String> platformCodeData);

	/**
	 * Gets the universal codes record count.
	 *
	 * @param codeSet the code set
	 * @param status the status
	 * @return the universal codes record count
	 */
	public int getUniversalCodesRecordCount(String codeSet, StatusEnum status);
	
	/**
	 * Checks if is universal code exist.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return true, if is universal code exist
	 */
	public boolean isUniversalCodeExist(String codeSet, String universalCode);

	/**
	 * Checks if is universal code disabled.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return true, if is universal code disabled
	 */
	public boolean isUniversalCodeDisabled(String codeSet, String universalCode);
}
