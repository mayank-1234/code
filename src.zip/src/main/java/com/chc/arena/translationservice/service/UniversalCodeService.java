package com.chc.arena.translationservice.service;

import java.util.List;
import java.util.Map;

import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;


/**
 * The Interface UniversalCodeService.
 *
 * @author narendra.dubey
 */
public interface UniversalCodeService {

	
	/**
	 * Gets the all universal codes.
	 *
	 * @param codeSet the code set
	 * @param from the from
	 * @param count the count
	 * @param status the filter
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the all universal codes
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<List<Map<String,String>>> getAllUniversalCodes(String codeSet, Integer page,
			Integer count, StatusEnum status, String orderBy, Direction direction) throws ServiceException;

	
	/**
	 * Gets the universal codes by code set.
	 *
	 * @return the universal codes by code set
	 * @throws ServiceException the service exception
	 */
	List<Map<String, String>> getUniversalCodesByCodeSet() throws ServiceException;
	
	/**
	 * Gets single Universal Code and Data by given universal-code identifier.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @return the by code
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<Map<String, String>> getByCode(String codeSet, String universalCode) throws ServiceException;
	
	/**
	 * Search one or mode Universal Code and Data for the given Platform Code Data.
	 * @param codeSet
	 * @param platformCodeData
	 * @param from
	 * @param count
	 * @return ServiceResponse<List<Map<String, String>>>
	 * @throws ServiceException
	 */
	ServiceResponse<List<Map<String, String>>> search(String codeSet, Map<String, String> platformCodeData, Integer from, Integer count) throws ServiceException;
	
	/**
	 * Insert a new Universal Code and Data.
	 *
	 * @param codeSet the code set
	 * @param universalCodeData the universal code data
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	String insert(String codeSet, Map<String, String> universalCodeData) throws ServiceException;
	
	/**
	 * Update a Universal Code Data.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param universalCodeData the universal code data
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	String update(String codeSet, String universalCode, Map<String, String> universalCodeData) throws ServiceException;
	

	/**
	 * Delete a Universal Code and Data.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @return the service response
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<Boolean> delete(String codeSet, String universalCode) throws ServiceException;

	/**
	 * Get universal code mapped to  platform code .
	 *
	 * @param codeSet the code set
	 * @param platformCodeObject the platform code object
	 * @return Universal Code object
	 * @throws ServiceException the service exception
	 */
	public ServiceResponse<Map<String,String>> getMappedUniversalCode(String codeSet, Map<String, String> platformCodeObject) throws ServiceException;
	
	/**
	 * Gets the universal codes record count.
	 *
	 * @param codeSet the code set
	 * @param filter the filter
	 * @return the universal codes record count
	 */
	public int getUniversalCodesRecordCount(String codeSet, StatusEnum filter);
}
