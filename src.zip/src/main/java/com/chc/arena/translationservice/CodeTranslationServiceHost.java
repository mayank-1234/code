package com.chc.arena.translationservice;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import microsoft.servicefabric.services.runtime.ServiceRuntime;

/**
 * The Class CodeTranslationServiceHost.
 */
@SpringBootApplication
public class CodeTranslationServiceHost {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(CodeTranslationServiceHost.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception {
		if (System.getProperty("spring.profiles.active") != null
				&& !"Local".equalsIgnoreCase(System.getProperty("spring.profiles.active"))) {
			ServiceRuntime.registerStatelessServiceAsync("CodeTranslationAPIType",
					context -> new CodeTranslationService(), Duration.ofSeconds(10));
			logger.debug("Registered stateless service of type CodeTranslationAPIType. ");
		}
		SpringApplication.run(CodeTranslationServiceHost.class, args);
		logger.debug("Started Spring Boot Application -> CodeTranslationAPI ");
		Thread.sleep(Long.MAX_VALUE);
	}
}
