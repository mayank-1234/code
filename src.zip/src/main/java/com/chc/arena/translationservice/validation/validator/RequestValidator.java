package com.chc.arena.translationservice.validation.validator;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.service.exception.InvalidRequestException;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.validation.annotation.ValidRequest;
import com.chc.arena.translationservice.validation.service.RequestValidationService;

/**
 * The Class RequestValidator.
 */
@Aspect
@Component
public class RequestValidator {
	
	private static final Logger logger=LoggerFactory.getLogger(RequestValidator.class);

	/** The request validation service. */
	@Autowired
	private RequestValidationService requestValidationService;

	/**
	 * Validate.
	 *
	 * @param joinPoint the join point
	 * @throws ServiceException 
	 * @throws Throwable the throwable
	 */
	@SuppressWarnings("unchecked")
	@Before("@annotation(com.chc.arena.translationservice.validation.annotation.ValidRequest)")
	public void validate(JoinPoint joinPoint) {
		
		MethodSignature signature = (MethodSignature) joinPoint.getSignature();
		Method method = signature.getMethod();
		logger.info("Validating the request parameters and body passed to controller method {}", method.getName());
		ValidRequest validRequest = method.getAnnotation(ValidRequest.class);

		String codeSet = (String) joinPoint.getArgs()[0];
		ErrorDetails validationErrors = new ErrorDetails();
		boolean isValid = true;
		String universalCode = null;
		Map<String, String> platformCodeObject = null;
		Integer page = 0;
		Integer count = 0;
		String platformIdentifier=null;
		logger.debug("Validating the CodeSet={} passed in method {}", codeSet, method.getName());
		
		isValid = requestValidationService.isValidCodeSet(codeSet, validationErrors);
		if (!isValid) {
			logger.error("Invalid CodeSet={} in the method {}, Error={}", codeSet, method.getName(), validationErrors);
			throwInvalidRequestException(validationErrors);
		}

		switch (validRequest.requestType()) {
		
		case GET_UNIVERSAL_BY_UNIVERSAL_CODE:
			universalCode = (String) joinPoint.getArgs()[1];
			isValid = requestValidationService.isValidUniversalCode(codeSet, universalCode, validationErrors);
						
			break;
		case GET_PLATFORM_CODES_BY_UNIVERSAL_CODE:
			universalCode = (String) joinPoint.getArgs()[1];
			page = (Integer) joinPoint.getArgs()[2];
			count = (Integer) joinPoint.getArgs()[3];
			requestValidationService.isValidUniversalCode(codeSet, universalCode, validationErrors);
			requestValidationService.checkValidationsInQueryParameters(validationErrors, page, count,platformIdentifier,codeSet);
			
			isValid = requestValidationService.isValidCodeSetForSearchOrMappingRequest(codeSet, validationErrors, true);
			
			break;
		case GET_ALL_PLATFORM_CODES:
			page = (Integer) joinPoint.getArgs()[1];
			count = (Integer) joinPoint.getArgs()[2];
			platformIdentifier= (String) joinPoint.getArgs()[6];
			requestValidationService.checkValidationsInQueryParameters(validationErrors, page, count,platformIdentifier,codeSet);
			isValid = requestValidationService.isValidCodeSetForSearchOrMappingRequest(codeSet, validationErrors, true);
			break;
		case GET_ALL_UNIVERSAL_CODES:
			page = (Integer) joinPoint.getArgs()[1];
			count = (Integer) joinPoint.getArgs()[2];
			isValid = requestValidationService.checkValidationsInQueryParameters(validationErrors, page, count,platformIdentifier,codeSet);
			break;
		case CREATE_UNIVERSAL_CODE:
			Map<String, String> requestObject = (Map<String, String>) joinPoint.getArgs()[1];
			isValid = requestValidationService.isValidUniversalCodeCreateRequest(codeSet, requestObject,
					validationErrors);
			break;
		case SEARCH_UNIVERSAL_CODE:
			platformCodeObject = (Map<String, String>) joinPoint.getArgs()[1];
			isValid = requestValidationService.isValidCodeSetForSearchOrMappingRequest(codeSet, validationErrors, false);
			if (!isValid) {
				throwInvalidRequestException(validationErrors);
			}
			isValid = requestValidationService.isValidSearchRequest(codeSet, platformCodeObject, validationErrors);
			break;
		case GET_MAPPED_UNIVERSAL_CODE:
			platformCodeObject = (Map<String, String>) joinPoint.getArgs()[1];
			isValid = requestValidationService.isValidCodeSetForSearchOrMappingRequest(codeSet, validationErrors, true);
			if (!isValid) {
				throwInvalidRequestException(validationErrors);
			}
			isValid = requestValidationService.isValidRequestForGetMappedUniversalCode(codeSet, platformCodeObject, validationErrors);
			break;
		case UPDATE_UNIVERSAL_CODE:
			Map<String, String> universalCodeObject = (Map<String, String>) joinPoint.getArgs()[1];
			universalCode = (String) joinPoint.getArgs()[2];
			isValid = requestValidationService.isValidUniversalCodeUpdateRequest(codeSet, universalCodeObject, universalCode, validationErrors);
			break;
		case CREATE_PLATFORM_CODES:
			List<Map<String, String>> platformCodesForInsertion=(List<Map<String, String>>) joinPoint.getArgs()[1];
			isValid = requestValidationService.isValidRequestForPlatformCodesInsertion(codeSet,  platformCodesForInsertion, validationErrors);
			break;
		case UPDATE_PLATFORM_CODES:  
			List<Map<String, String>> platformCodeMapping=(List<Map<String, String>>) joinPoint.getArgs()[1];
			isValid = requestValidationService.isValidUpdateMappingRequest(codeSet,  platformCodeMapping, validationErrors);
			break;
		case GET_PLATFORM_CODE:
			platformCodeObject = (Map<String, String>) joinPoint.getArgs()[1];  
			isValid = requestValidationService.isValidGetRequestForPlatFormCodes(codeSet,  platformCodeObject, validationErrors);
			break;
			
		default:  
			break;
		}
		if (!isValid || validationErrors.getIssues().size() > 0) {
			logger.error("Error occured while validating arguments for method={}, Error={}", method.getName(), validationErrors);
			throwInvalidRequestException(validationErrors);
		}
	}

	/**
	 * Throw invalid request exception.
	 *
	 * @param validationErrors the validation errors
	 * @throws ServiceException 
	 * @throws InvalidRequestException the invalid request exception
	 */
	public void throwInvalidRequestException(ErrorDetails validationErrors) {
		
		throw new InvalidRequestException("Invalid Request Parameter/Body", CtsErrorCode.BAD_REQUEST, validationErrors);
	}
}
