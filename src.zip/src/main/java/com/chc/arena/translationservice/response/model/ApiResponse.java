package com.chc.arena.translationservice.response.model;

/**
 * The Class ApiResponse.
 */
public class ApiResponse {

	/** The status. */
	private ApiStatus status;

	/** The body. */
	private Object body;

	/** The api error. */
	private ApiError apiError;

	private String message;
	
	/**
	 * @return the status
	 */
	public ApiStatus getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(ApiStatus status) {
		this.status = status;
	}

	/**
	 * @return the body
	 */
	public Object getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(Object body) {
		this.body = body;
	}

	/**
	 * @return the apiError
	 */
	public ApiError getApiError() {
		return apiError;
	}

	/**
	 * @param apiError the apiError to set
	 */
	public void setApiError(ApiError apiError) {
		this.apiError = apiError;
	}

	public String getMessage() {
		return message;
	}

	public ApiResponse() {
		super();
	}
	
	public ApiResponse(ApiStatus status, Object body) {
		super();
		this.status = status;
		this.body = body;
	}
	
	public ApiResponse(ApiStatus status, Object body, String message) {
		super();
		this.status = status;
		this.body = body;
		this.message = message;
	}
	
	public ApiResponse(ApiStatus status, ApiError apiError) {
		super();
		this.status = status;
		this.apiError = apiError;
	}
}
