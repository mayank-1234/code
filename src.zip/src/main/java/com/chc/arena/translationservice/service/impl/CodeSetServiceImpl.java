package com.chc.arena.translationservice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chc.arena.translationservice.service.CodeSetService;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;

/**
 * The Class CodeSetServiceImpl.
 */
@Service
public class CodeSetServiceImpl implements CodeSetService{
	
	/** The code set meta data util. */
	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	/**
	 * Gets the all supported code sets.
	 *
	 * @return the all supported code sets
	 */
	@Override
	public List<String> getAllSupportedCodeSets() {		
		return codeSetMetaDataUtil.getCodeSets();
	}

}
