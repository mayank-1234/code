package com.chc.arena.translationservice.config;

import java.util.Arrays;
import java.util.Optional;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The Class SolrConfig.
 */
@Configuration
public class SolrConfig {
	
	private static final Logger logger=LoggerFactory.getLogger(SolrConfig.class);

	/** The solr URL. */
	@Value("${spring.solr.host}")
	private String solrURL;

	/** The connection time out. */
	@Value("${spring.solr.connectionTimeOut}")
	private Integer connectionTimeOut;

	/** The socket time out. */
	@Value("${spring.solr.socketTimeOut}")
	private Integer socketTimeOut;

	/**
	 * Creates the solr client.Solr cloud client used in distributed environment
	 * 
	 * @return the solr client
	 */
	@Bean
	public SolrClient createSolrClient() {
		logger.info("SolrConfig.createSolrClient [START]");
		return new CloudSolrClient.Builder(Arrays.asList(solrURL), Optional.empty())
				.withConnectionTimeout(connectionTimeOut).withSocketTimeout(socketTimeOut).build();
	}
}
