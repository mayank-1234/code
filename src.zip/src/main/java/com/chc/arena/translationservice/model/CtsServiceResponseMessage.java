/**
 * 
 */
package com.chc.arena.translationservice.model;

import java.io.Serializable;

/**
 * @author narendra.dubey
 *
 */
public class CtsServiceResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9223078294343797025L;

}
