package com.chc.arena.translationservice.model;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * The Class CodeSetsMetaData.
 */
@ConfigurationProperties(prefix = "code-sets-meta-data")
public class CodeSetsMetaData {
	
	/** The supported code sets. */
	private List<String> supportedCodeSets;
	
	/** The universal code fields. */
	private Map<String, List<String>> universalCodeFields;
	
	/** The universal code field value regex. */
	private Map<String, Map<String, String>> universalCodeFieldValueRegex;
	
	/** The universal code required fields. */
	private Map<String, List<String>> universalCodeRequiredFields;
	
	/** The universal code db table names. */
	private Map<String, String> universalCodeDbTableNames;	
	
	/** The platform code fields. */
	private Map<String, List<String>> platformCodeFields;
	
	/** The platform code field value regex. */
	private Map<String, Map<String, String>> platformCodeFieldValueRegex;
	
	/** The platform code required fields. */
	private Map<String, List<String>> platformCodeCompositeKeyFields;
	
	/** The platform code db table names. */
	private Map<String, String> platformCodeDbTableNames;
	
	/** The advanced search enabled code sets. */
	private List<String> advancedSearchEnabledCodeSets;
	
	/** The advanced search collection names. */
	private Map<String, String> advancedSearchCollectionNames;
	
	private Map<String, List<String>> advancedSearchRequiredFields;
	
	private Map<String, Map<String, String>> advancedSearchQueryFields;
	
	private Map<String, Map<String, String>> advancedSearchFilterQueryFields;

	private int advancedSearchDefaultResultCount;
	
	
	/**
	 * Gets the supported code sets.
	 *
	 * @return the supported code sets
	 */
	public List<String> getSupportedCodeSets() {
		return supportedCodeSets;
	}

	/**
	 * Sets the supported code sets.
	 *
	 * @param supportedCodeSets the new supported code sets
	 */
	public void setSupportedCodeSets(List<String> supportedCodeSets) {
		this.supportedCodeSets = supportedCodeSets;
	}

	/**
	 * Gets the universal code fields.
	 *
	 * @return the universal code fields
	 */
	public Map<String, List<String>> getUniversalCodeFields() {
		return universalCodeFields;
	}

	/**
	 * Sets the universal code fields.
	 *
	 * @param universalCodeFields the universal code fields
	 */
	public void setUniversalCodeFields(Map<String, List<String>> universalCodeFields) {
		this.universalCodeFields = universalCodeFields;
	}

	/**
	 * Get Platform Code Composite Key fields
	 * @return
	 */
	public Map<String, List<String>> getPlatformCodeCompositeKeyFields() {
		return platformCodeCompositeKeyFields;
	}

	/**
	 * Set Platform Code Composite Key fields
	 * @param platformCodeCompositeKeyFields
	 */
	public void setPlatformCodeCompositeKeyFields(Map<String, List<String>> platformCodeCompositeKeyFields) {
		this.platformCodeCompositeKeyFields = platformCodeCompositeKeyFields;
	}

	/**
	 * Gets the universal code field value regex.
	 *
	 * @return the universal code field value regex
	 */
	public Map<String, Map<String, String>> getUniversalCodeFieldValueRegex() {
		return universalCodeFieldValueRegex;
	}

	/**
	 * Sets the universal code field value regex.
	 *
	 * @param universalCodeFieldValueRegex the universal code field value regex
	 */
	public void setUniversalCodeFieldValueRegex(Map<String, Map<String, String>> universalCodeFieldValueRegex) {
		this.universalCodeFieldValueRegex = universalCodeFieldValueRegex;
	}

	/**
	 * Gets the universal code required fields.
	 *
	 * @return the universal code required fields
	 */
	public Map<String, List<String>> getUniversalCodeRequiredFields() {
		return universalCodeRequiredFields;
	}

	/**
	 * Sets the universal code required fields.
	 *
	 * @param universalCodeRequiredFields the universal code required fields
	 */
	public void setUniversalCodeRequiredFields(Map<String, List<String>> universalCodeRequiredFields) {
		this.universalCodeRequiredFields = universalCodeRequiredFields;
	}

	/**
	 * Gets the universal code db table names.
	 *
	 * @return the universal code db table names
	 */
	public Map<String, String> getUniversalCodeDbTableNames() {
		return universalCodeDbTableNames;
	}

	/**
	 * Sets the universal code db table names.
	 *
	 * @param universalCodeDbTableNames the universal code db table names
	 */
	public void setUniversalCodeDbTableNames(Map<String, String> universalCodeDbTableNames) {
		this.universalCodeDbTableNames = universalCodeDbTableNames;
	}

	/**
	 * Gets the platform code fields.
	 *
	 * @return the platform code fields
	 */
	public Map<String, List<String>> getPlatformCodeFields() {
		return platformCodeFields;
	}

	/**
	 * Sets the platform code fields.
	 *
	 * @param platformCodeFields the platform code fields
	 */
	public void setPlatformCodeFields(Map<String, List<String>> platformCodeFields) {
		this.platformCodeFields = platformCodeFields;
	}

	/**
	 * Gets the platform code field value regex.
	 *
	 * @return the platform code field value regex
	 */
	public Map<String, Map<String, String>> getPlatformCodeFieldValueRegex() {
		return platformCodeFieldValueRegex;
	}

	/**
	 * Sets the platform code field value regex.
	 *
	 * @param platformCodeFieldValueRegex the platform code field value regex
	 */
	public void setPlatformCodeFieldValueRegex(Map<String, Map<String, String>> platformCodeFieldValueRegex) {
		this.platformCodeFieldValueRegex = platformCodeFieldValueRegex;
	}

	/**
	 * Gets the platform code db table names.
	 *
	 * @return the platform code db table names
	 */
	public Map<String, String> getPlatformCodeDbTableNames() {
		return platformCodeDbTableNames;
	}

	/**
	 * Sets the platform code db table names.
	 *
	 * @param platformCodeDbTableNames the platform code db table names
	 */
	public void setPlatformCodeDbTableNames(Map<String, String> platformCodeDbTableNames) {
		this.platformCodeDbTableNames = platformCodeDbTableNames;
	}

	/**
	 * Gets the advanced search enabled code sets.
	 *
	 * @return the advanced search enabled code sets
	 */
	public List<String> getAdvancedSearchEnabledCodeSets() {
		return advancedSearchEnabledCodeSets;
	}

	/**
	 * Sets the advanced search enabled code sets.
	 *
	 * @param advancedSearchEnabledCodeSets the new advanced search enabled code sets
	 */
	public void setAdvancedSearchEnabledCodeSets(List<String> advancedSearchEnabledCodeSets) {
		this.advancedSearchEnabledCodeSets = advancedSearchEnabledCodeSets;
	}

	/**
	 * Gets the advanced search collection names.
	 *
	 * @return the advanced search collection names
	 */
	public Map<String, String> getAdvancedSearchCollectionNames() {
		return advancedSearchCollectionNames;
	}

	/**
	 * Sets the advanced search collection names.
	 *
	 * @param advancedSearchCollectionNames the advanced search collection names
	 */
	public void setAdvancedSearchCollectionNames(Map<String, String> advancedSearchCollectionNames) {
		this.advancedSearchCollectionNames = advancedSearchCollectionNames;
	}

	/**
	 * @return the advancedSearchRequiredFields
	 */
	public Map<String, List<String>> getAdvancedSearchRequiredFields() {
		return advancedSearchRequiredFields;
	}

	/**
	 * @param advancedSearchRequiredFields the advancedSearchRequiredFields to set
	 */
	public void setAdvancedSearchRequiredFields(Map<String, List<String>> advancedSearchRequiredFields) {
		this.advancedSearchRequiredFields = advancedSearchRequiredFields;
	}

	/**
	 * @return the advancedSearchQueryFields
	 */
	public Map<String, Map<String, String>> getAdvancedSearchQueryFields() {
		return advancedSearchQueryFields;
	}

	/**
	 * @param advancedSearchQueryFields the advancedSearchQueryFields to set
	 */
	public void setAdvancedSearchQueryFields(Map<String, Map<String, String>> advancedSearchQueryFields) {
		this.advancedSearchQueryFields = advancedSearchQueryFields;
	}

	/**
	 * @return the advancedSearchFilterQueryFields
	 */
	public Map<String, Map<String, String>> getAdvancedSearchFilterQueryFields() {
		return advancedSearchFilterQueryFields;
	}

	/**
	 * @param advancedSearchFilterQueryFields the advancedSearchFilterQueryFields to set
	 */
	public void setAdvancedSearchFilterQueryFields(Map<String, Map<String, String>> advancedSearchFilterQueryFields) {
		this.advancedSearchFilterQueryFields = advancedSearchFilterQueryFields;
	}

	/**
	 * @return the advancedSearchDefaultResultCount
	 */
	public int getAdvancedSearchDefaultResultCount() {
		return advancedSearchDefaultResultCount;
	}

	/**
	 * @param advancedSearchDefaultResultCount the advancedSearchDefaultResultCount to set
	 */
	public void setAdvancedSearchDefaultResultCount(int advancedSearchDefaultResultCount) {
		this.advancedSearchDefaultResultCount = advancedSearchDefaultResultCount;
	}	
	
	
}
