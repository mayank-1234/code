package com.chc.arena.translationservice.validation.annotation;

/**
 * The Enum RequestType.
 */
public enum RequestType {

	/** The any request. */
	ANY_REQUEST,

	/** The get universal by universal code. */
	GET_UNIVERSAL_BY_UNIVERSAL_CODE,

	/** The create universal code. */
	CREATE_UNIVERSAL_CODE,

	/** The create platform codes. */
	CREATE_PLATFORM_CODES,

	/** The search universal code. */
	SEARCH_UNIVERSAL_CODE,

	/** The get mapped universal code. */
	GET_MAPPED_UNIVERSAL_CODE,

	/** The update universal code. */
	UPDATE_UNIVERSAL_CODE,

	/** The get platform codes by universal code. */
	GET_PLATFORM_CODES_BY_UNIVERSAL_CODE,

	/** The update platform codes. */
	UPDATE_PLATFORM_CODES,
	
	/** The get all universal codes. */
	GET_ALL_UNIVERSAL_CODES,
	
	/** The get all platform codes. */
	GET_ALL_PLATFORM_CODES,
	
	/** The get platform codes. */
	GET_PLATFORM_CODE;
	
	
}
