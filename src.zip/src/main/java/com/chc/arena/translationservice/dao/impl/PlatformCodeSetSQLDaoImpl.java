package com.chc.arena.translationservice.dao.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.chc.arena.translationservice.dao.PlatformCodeSetSQLDao;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.querybuilder.SQLQueryBuilder;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Class PlatformCodeSetSQLDaoImpl.
 */
@Repository
public class PlatformCodeSetSQLDaoImpl implements PlatformCodeSetSQLDao {

	private static final Logger logger = LoggerFactory.getLogger(PlatformCodeSetSQLDaoImpl.class);

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Autowired
	private MessageSourceUtil messageSourceUtil;

	@Autowired
	private SQLQueryBuilder sqlQueryBuilder;
	
	/**
	 * Gets the platform codes by universal code.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @param from          the from
	 * @param count         the count
	 * @param mappingStatus the mapping status
	 * @param orderBy       the order by
	 * @param direction     the direction
	 * @return the platform codes by universal code
	 * @throws DaoException the dao exception
	 */
	@Override
	public List<Map<String, Object>> getPlatformCodesByUniversalCode(String codeSet, String universalCode, Integer page,
			Integer count, StatusEnum mappingStatus, String orderBy, Direction direction) throws DaoException {
		logger.info("Building query to get all mapped Platform Codes for the given CodeSet={} and UniversalCode={}", codeSet, universalCode);

		List<Map<String, Object>> platformCodes = null;

		String platformCodesByUniversalCodeIdQuery = sqlQueryBuilder
				.buildPlatformRetrieveByUniversalCodeIdQuery(codeSet, page, count, mappingStatus, orderBy, direction);
		
		logger.debug("To fetch mapped Platform Codes for the given CodeSet={} and UniversalCode={}, built query PlatformCodesByUniversalCodeIdQuery={}", codeSet, universalCode, platformCodesByUniversalCodeIdQuery);

		MapSqlParameterSource platformByUniversalCodeIdParameters = sqlQueryBuilder
				.setPlatformRetrieveByUniversalCodeIdParameters(universalCode, mappingStatus);

		try {

			platformCodes = namedParameterJdbcTemplate.queryForList(platformCodesByUniversalCodeIdQuery,
					platformByUniversalCodeIdParameters);

		} catch (DataAccessException dataAccessException) {
			
			logger.error("Error occured while trying to fetch mapped Platform Code(s) for the given CodeSet={} and UniversalCode={}. Error={}", codeSet, universalCode, dataAccessException.getMessage());
			
			throw new DaoException(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR"),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
		
		logger.info("Returning {} Platform Code record(s) for the given CodeSet={} and UniversalCode={}", platformCodes.size(), codeSet, universalCode);

		return platformCodes;
	}

	/**
	 * Insert.
	 *
	 * @param codeSet     the code set
	 * @param codeObjects the code objects
	 */
	@Override
	public void insert(String codeSet, Map<String, String> codeObject) throws DaoException{
		logger.info("Inserting new Platfrom Code for the given CodSet={} , PlatformCodeData={}",codeSet,codeObject);
		List<String> requiredFields=codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		String platformDataInRequest=requiredFields.stream().map(codeObject::get).map(String::trim).collect(Collectors.joining(" , "));
		String sql=sqlQueryBuilder.buildPlatformInsertQuery(codeSet);
		logger.debug("To insert Platform Code for the given CodSet={} PlatformCodeData={}, built InsertPlatformCodeQuery={}", codeSet, codeObject, sql);
		MapSqlParameterSource paramSource=sqlQueryBuilder.setPlatFormInsertParameters(codeSet, codeObject);
		try {
			namedParameterJdbcTemplate.update(sql, paramSource);
		}catch(DuplicateKeyException e) {
			
			logger.error("Error inserting new Platform Code, provided Platform data={} already exist.", platformDataInRequest);
			throw new DaoException(messageSourceUtil.getMessage("DUPLICATE_PLATFORM_CODE_INSERT_ERROR_MESSAGE"),
					CtsErrorCode.PLATFORM_CODE_ALREADY_EXIST);
		}
		logger.info("Successfully inserted new Platform Code identified by Platform data={} for the given CodeSet={}", platformDataInRequest,codeSet);
	}

	/**
	 * Update.
	 *
	 * @param codeSet     the code set
	 * @param codeObjects the code objects
	 */
	@Override
	public void update(String codeSet, Map<String, String> codeObject,Integer universalCodeId) {
		logger.info("Start updating platform codes mapping with universal code for code set {}, mapped object {}", codeSet, codeObject);
		String query = sqlQueryBuilder.buildPlatformUpdateQuery(codeSet);
		MapSqlParameterSource params = sqlQueryBuilder.setPlatformUpdateParameters(codeSet, codeObject, universalCodeId);
		int count = namedParameterJdbcTemplate.update(query, params);
		logger.info("End updating platform codes mapping with universal code for code set, rows updated {}", count);
	}


	
	@Override
	public int disableEnablePlatformCodesMappedToUniversalCode(String codeSet, String status, int universalCodeId, Date updatedTime) {
		logger.info("{} platform codes mapping with universal code for CodeSet={}, UniversalCodeId={}, Time={}", status, codeSet, universalCodeId, updatedTime);
		String query = sqlQueryBuilder.buildPlatformEnableDisableByUniversalCodeQuery(codeSet);
		MapSqlParameterSource params = sqlQueryBuilder.setPlatformEnableDisableByUniversalCodeParameters(status, universalCodeId, updatedTime);
		logger.debug("{} platform codes mapping with universal code for CodeSet={}, UniversalCodeId={}, Time={}, Query={}, Params={}", status, codeSet, universalCodeId, updatedTime, query, params);

		
		int count = namedParameterJdbcTemplate.update(query, params);
		logger.info("{} platform codes mapping with universal code for CodeSet={}, UniversalCodeId={}, Time={}, updated {} platform codes", status, codeSet, universalCodeId, updatedTime, count);
		return count;
	}

	/**
	 * Gets the platform codes count by code set and universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param mappingStatus the mapping status
	 * @return the platform codes count by code set and universal code
	 */
	@Override
	public int getPlatformCodesCountByCodeSetAndUniversalCode(String codeSet, String universalCode, StatusEnum mappingStatus) {
		logger.info("Building and executing query to find the mapped platform codes for the given CodeSet={} and UniversalCode={}", codeSet, universalCode);
		String query = sqlQueryBuilder.buildPlatformCodeRecordCountByCodeSetAndUniversalCodeQuery(codeSet, universalCode, mappingStatus);
		MapSqlParameterSource platformCodesRecordsByUniversalCodeIdCountParams = sqlQueryBuilder.setPlatformRetrieveByUniversalCodeIdParameters(universalCode, mappingStatus);
		logger.debug("To fetch count of Platform Codes for the given CodeSet={} and UniversalCode={}, built GetPlatformCodesCountByCodeSetAndUniversalCodeQuery='{}'", codeSet, universalCode, query);
		return namedParameterJdbcTemplate.queryForObject(query, platformCodesRecordsByUniversalCodeIdCountParams, Integer.class);
	}

	/**
	 * Gets the all platform codes.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count the count
	 * @param mappingStatus the mapping status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the all platform codes
	 * @throws DaoException the dao exception
	 */
	@Override
	public List<Map<String, Object>> getAllPlatformCodes(String codeSet, Integer page, Integer count, PlatformCodesMappingStatus mappingStatus,
			String orderBy, Direction direction,String platformIdentifier) throws DaoException {
		List<Map<String, Object>> repoPlatformCodes = null;
		
		try {
			logger.info("Building query to get all Platform Codes for the given CodeSet={}", codeSet);
		
			String getAllPlatformCodesQuery = sqlQueryBuilder.buildPlatformRetrieveAllQuery(codeSet, page, count, mappingStatus,
					orderBy, direction,platformIdentifier);
			
			MapSqlParameterSource getAllPlatformCodesParams = sqlQueryBuilder.setPlatformRetrieveAllParameters(mappingStatus,platformIdentifier);
			
			logger.debug("To fetch all Platform Codes for the given CodeSet={}, built GetAllPlatformCodeQuery='{}'", codeSet, getAllPlatformCodesQuery);
			
			repoPlatformCodes = namedParameterJdbcTemplate.queryForList(getAllPlatformCodesQuery, getAllPlatformCodesParams);
			
			logger.debug("Found PlatformCodesCount={} records for the given CodeSet={}", repoPlatformCodes.size(), codeSet);
			
		} catch (DataAccessException dataAccessException) {
			
			logger.error("Error occured while trying to fetch Platform Codes for the given CodeSet={}. DaoException={}", codeSet, dataAccessException.getMessage());
			
			throw new DaoException(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR"),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
		
		return repoPlatformCodes;
	}

	/**
	 * Gets the platform codes record count.
	 *
	 * @param codeSet the code set
	 * @param mappingStatus the mapping status
	 * @return the platform codes record count
	 */
	@Override
	public int getPlatformCodesRecordCount(String codeSet, PlatformCodesMappingStatus mappingStatus,String platformIdentifier) {
		String query = sqlQueryBuilder.buildPlatformRecordCountQuery(codeSet, mappingStatus,platformIdentifier);
		MapSqlParameterSource platformCodesRecordsCountParams = sqlQueryBuilder.setPlatformRetrieveAllParameters(mappingStatus,platformIdentifier);
		return namedParameterJdbcTemplate.queryForObject(query, platformCodesRecordsCountParams, Integer.class);
	}

	@Override
	public int removePlatformCodeMappingForUniversalCodeId(String codeSet, Integer universalCodeId, Date updatedTime) {
		logger.info(
				"Removing Platform Codes mappings and setting mapping status to null where CodeSet={} UniversalCodeId={} at UpdatedTime={}",
				codeSet, universalCodeId, updatedTime);

		String query = sqlQueryBuilder.buildUpdatePlatformCodeDetachUniversalCodeMappingQuery(codeSet);
		MapSqlParameterSource params = sqlQueryBuilder
				.setUpdatePlatformCodeDetachUniversalCodeMappingQueryParameters(universalCodeId, updatedTime);
		int updatePlatformCodeRecords = namedParameterJdbcTemplate.update(query, params);
		logger.info(
				"Removed Platform Codes mappings of {} Platform Codes and setting mapping status to null where CodeSet={} UniversalCodeId={} at UpdatedTime={}",
				updatePlatformCodeRecords, codeSet, universalCodeId, updatedTime);
		return updatePlatformCodeRecords; 
	}

	public List<Map<String, Map<String, Object>>> getPlatFormCodeDataWithUniversalCodeDataSet(String codeSet,
			List<Map<String, String>> mappingList) { 
		logger.info("Fetching platform_code mapping details with mapped universal code for given set of objects, mappedObjectCount={}",mappingList.size());
		List<String> compositKeysList = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		List<Map<String, Object>> dbObjectList = null;
		List<Map<String, Map<String, Object>>> mapdataList = new ArrayList<>();
		try {
			String query = sqlQueryBuilder.buildQueryToGetMappedPlatformCodeAndUniversalCode(codeSet, mappingList);
			dbObjectList = jdbcTemplate.queryForList(query);
			dbObjectList.forEach(data -> createKeysForMappeData(compositKeysList, mapdataList, data));
		} catch (EmptyResultDataAccessException emptyResultDataAccessException) {
			logger.error("No platform_code mapping details found with mapped universal code for given set of objects, dbRecords={}",dbObjectList);
			return Collections.emptyList();
		}
		logger.info("Total records for platform_code mapping details with mapped universal code for given set of objects ={}, count= {}",mappingList,mappingList.size());
		return mapdataList;
	} 

	private void createKeysForMappeData(List<String> compositKeysList,
			List<Map<String, Map<String, Object>>> mapdataList, Map<String, Object> data) {
		logger.info(" Building keys from composit key items from the configuration compositKeysCount={}",compositKeysList.size());
		Map<String, Map<String, Object>> mapData = new HashMap<>();
		StringBuilder key = new StringBuilder();
		for (String item : compositKeysList) {
			key.append(data.get(item));
		}
		mapData.put(key.toString(), data);
		mapdataList.add(mapData);
		logger.info(" Keys building completed from composit key items from the configuration ");
	}

	@Override
	public Map<String, Object> getPlatformCodeDataByCode(String codeSet, Map<String, String> platformCodes) throws DaoException {
		try {
			logger.info("Building query to get Platfrom Code Data for the given CodeSet={} and input request={}", codeSet, platformCodes);
			String query = sqlQueryBuilder.buildPlatformDataRetrieveQuery(codeSet,platformCodes);
			MapSqlParameterSource params = sqlQueryBuilder.setPlatformDataRetrieveParameters(platformCodes);
			
			Map<String, Object> dbObject = namedParameterJdbcTemplate.queryForMap(query, params);
			logger.debug("For the given CodeSet={} and input request={}, Platform Code Data found in db {}", codeSet, platformCodes, dbObject);
			return dbObject;
		} catch(EmptyResultDataAccessException emptyResultDataAccessException) {
			logger.error("No Platform Code data found in repository for the given CodeSet={} and input request={}", codeSet, platformCodes);
			throw new DaoException(messageSourceUtil.getMessage("NO_PLATFORM_CODES_IN_DATABASE"), CtsErrorCode.ENTITY_NOT_FOUND);
		}
	}

}
