package com.chc.arena.translationservice.service.exception;

public class DaoException extends Exception {

	private static final long serialVersionUID = -6198419655982569102L;

	private final CtsErrorCode errorCode;
	
	public DaoException(String message, CtsErrorCode errorCode) {
		super(message);
		this.errorCode = errorCode;
	}

	public CtsErrorCode getErrorCode() {
		return errorCode;
	}
}
