package com.chc.arena.translationservice.response.model;

import java.util.Date;
import java.util.List;

import com.chc.arena.translationservice.service.exception.CtsErrorCode;

/**
 * The Class ApiError.
 */
public class ApiError {

	/** The code. */
	private CtsErrorCode errorCode;
	
	/** The timestamp. */
	private Date timestamp = new Date();
	
	/** The message. */
	private String message;
	
	/** The sub errors. */
	private List<SubError> subErrors;
	
	
	/**
	 * @return the errorCode
	 */
	public CtsErrorCode getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(CtsErrorCode errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Gets the timestamp.
	 *
	 * @return the timestamp
	 */
	public Date getTimestamp() {
		return timestamp;
	}

	/**
	 * Sets the timestamp.
	 *
	 * @param timestamp the new timestamp
	 */
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Gets the sub errors.
	 *
	 * @return the sub errors
	 */
	public List<SubError> getSubErrors() {
		return subErrors;
	}

	/**
	 * Sets the sub errors.
	 *
	 * @param subErrors the new sub errors
	 */
	public void setSubErrors(List<SubError> subErrors) {
		this.subErrors = subErrors;
	}
}
