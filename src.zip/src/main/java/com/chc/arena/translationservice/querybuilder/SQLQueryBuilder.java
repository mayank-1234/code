package com.chc.arena.translationservice.querybuilder;
import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Class SQLQueryBuilder.
 */
@Component
public class SQLQueryBuilder {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(SQLQueryBuilder.class);

	/** The code set meta data util. */
	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;

	/**
	 * Builds the universal insert query.
	 *
	 * @param codeSet the code set
	 * @param codeObject the code object
	 * @return the string
	 */
	public String buildUniversalInsertQuery(String codeSet, Map<String, String> codeObject) {
		logger.debug(" Building insert query for universal code set  [START]: CodeSet: {}, Universal Code Data: {} ",
				codeSet, codeObject);
		codeObject.put(TranslationServiceStringConstant.CREATION_DATE, "");
		String tableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		String columnNameWithColons = colonSeparatedColumnNames(codeObject.keySet());
		String columnNames = commaSeparatedColumnNames(codeObject.keySet());
		StringBuilder query = new StringBuilder();
		query.append(INSERT).append(SPACE).append(INTO).append(SPACE).append(tableName).append(" ( ")
				.append(columnNames).append(" ) ").append(VALUES).append(" ( ").append(columnNameWithColons)
				.append(" ) ");
		logger.debug(" Built insert query for universal code set [END]: CodeSet: {}, Universal Code Data: {} ", codeSet,
				codeObject);
		return query.toString();
	}

	/**
	 * Builds the universal delete query.
	 *
	 * @param codeSet the code set
	 * @return the string
	 */
	public String buildUniversalDeleteQuery(String codeSet) {
		logger.debug("Inside buildUniversalDeleteQuery  ");
		String tableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(DELETE).append(SPACE).append(FROM).append(SPACE).append(tableName).append(SPACE).append(WHERE)
				.append(SPACE).append(UNIVERSAL_CODE_FIELD).append(" =:").append(UNIVERSAL_CODE_FIELD);
		return query.toString();
	}
	
	/**
	 * Sets the universal delete parameters.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setUniversalDeleteParameters(String universalCode) {
		MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
		mapSqlParameterSource.addValue(UNIVERSAL_CODE_FIELD, universalCode);
		return mapSqlParameterSource;
	}

	/**
	 * Builds the universal update query.
	 *
	 * @param codeSet    the code set
	 * @param universalCodeData the universal code data
	 * @return the string
	 */
	public String buildUniversalUpdateQuery(String codeSet, Map<String, String> universalCodeData) {
		String tableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(UPDATE).append(tableName).append(SET);
		universalCodeData.keySet().forEach(key -> query.append(key).append("=:").append(key).append(", "));
		query.append(TranslationServiceStringConstant.LAST_UPDATED).append("=:")
				.append(TranslationServiceStringConstant.LAST_UPDATED).append(", ");
		query.deleteCharAt(query.lastIndexOf(","));
		query.append(WHERE).append(UNIVERSAL_CODE_FIELD).append("=:").append(UNIVERSAL_CODE_FIELD);
		return query.toString();
	}

	/**
	 * Builds the universal retrieve query.
	 *
	 * @param codeSet the code set
	 * @return the string
	 */
	public String buildUniversalRetrieveQuery(String codeSet) {
		logger.debug("Inside buildUniversalRetrieveQuery ");
		String tableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(SELECT).append(" * ").append(FROM).append(tableName).append(WHERE).append(UNIVERSAL_CODE_FIELD)
				.append("=:").append(UNIVERSAL_CODE_FIELD).append(SPACE);
		return query.toString();
	}

	/**
	 * Builds parameter source with universal_code parameter.
	 *
	 * @param universalCode the universal code
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setUniversalRetrieveParameters(String universalCode) {
		MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
		sqlParameters.addValue(UNIVERSAL_CODE_FIELD, universalCode);
		return sqlParameters;
	}

	/**
	 * Sets the universal update parameters.
	 *
	 * @param codeSet       the code set
	 * @param universalCodeData the universal code data
	 * @param universalCode the universal code
	 * @param updatedTime
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setUniversalUpdateParameters(String codeSet, Map<String, String> universalCodeData, String universalCode, Date updatedTime) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		universalCodeData.entrySet().stream().forEach(entry -> params.addValue(entry.getKey(), entry.getValue()));
		params.addValue(UNIVERSAL_CODE_FIELD, universalCode);
		params.addValue(TranslationServiceStringConstant.LAST_UPDATED, updatedTime);
		return params;
	}


	/**
	 * Builds the universal retrieve all query.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count   the count
	 * @param status  the status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the string
	 */
	public String buildUniversalRetrieveAllQuery(String codeSet, Integer page, Integer count, StatusEnum status,
			String orderBy, Direction direction) {
		logger.debug("Inside buildUniversalRetrieveAllQuery");

		String universalCodeSetTableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);

		List<String> universalCodeFields = codeSetMetaDataUtil.getUniversalCodeFields(codeSet);

		StringBuilder query = new StringBuilder();

		query.append(SELECT);

		ListIterator<String> listIterator = universalCodeFields.listIterator();

		while (listIterator.hasNext()) {
			String nextField = listIterator.next();
			query.append(universalCodeSetTableName).append(".").append(nextField);
			if (listIterator.hasNext())
				query.append(",").append(SPACE);
		}

		query.append(FROM).append(universalCodeSetTableName);

		if (status != null) {
			query.append(WHERE).append(universalCodeSetTableName).append(".").append(STATUS).append("=:").append(STATUS)
					.append(SPACE);
		}

		boolean orderByFlag=false;
		if (orderBy != null) {
			orderByFlag=true;
			query.append(ORDER_BY).append(orderBy).append(SPACE);
			if (direction != null)
				query.append(direction.name());
		}

		String tableName= universalCodeSetTableName;
		apendPaginationParams(page, count, query,orderByFlag,tableName);

		return query.toString();
	}

	/**
	 * Sets the universal retrieve all parameters.
	 *
	 * @param status the status
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setUniversalRetrieveAllParameters(StatusEnum status) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		if (status != null)
			params.addValue(STATUS, status.name());
		return params;
	}

	/**
	 * Builds the universal mapped platform query.
	 *
	 * @param codeSet the code set
	 * @return the string
	 */
	public String buildUniversalMappedPlatformQuery(String codeSet) {
		logger.debug("Inside buildUniversalMappedPlatformQuery ");
		String universalTable = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		String platformTable = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(SELECT).append(PLATFORM).append(".").append(UNIVERSAL_CODE_FIELD_IN_PLATFORM).append(", ")
				.append(PLATFORM).append(".").append(MAPPING_STATUS_COLUMN).append(", ").append(UNIVERSAL).append(".*")
				.append(FROM).append(platformTable).append(SPACE).append(PLATFORM).append(SPACE).append(LEFT_JOIN)
				.append(universalTable).append(SPACE).append(UNIVERSAL).append(SPACE).append(" ON ")
				.append(PLATFORM).append(".universal_code_id = ").append(UNIVERSAL).append(".id").append(WHERE);
		codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)
				.forEach(field -> query.append(field).append(" = ").append(":").append(field).append(AND));
		return query.substring(0, query.lastIndexOf(AND));
	}

	/**
	 * Sets the universal and platform mapping parameters.
	 *
	 * @param codeSet            the code set
	 * @param platformCodeObject the code object
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setUniversalAndPlatformMappingParameters(String codeSet,
			Map<String, String> platformCodeObject) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)
				.forEach(field -> params.addValue(field, platformCodeObject.get(field)));
		return params;
	}

	/**
	 * Builds the platform update query.
	 *
	 * @param codeSet the code set
	 * @return the string
	 */
	public String buildPlatformUpdateQuery(String codeSet) {
		logger.debug("Inside buildPlatformUpdateQuery ");
		String tableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		List<String> compositKeysList = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(UPDATE).append(tableName).append(SPACE).append(SET).append(MAPPING_STATUS_COLUMN).append("=:")
				.append(MAPPING_STATUS_COLUMN).append(", ").append(TranslationServiceStringConstant.LAST_UPDATED)
				.append("=:").append(TranslationServiceStringConstant.LAST_UPDATED).append(", ")
				.append(UNIVERSAL_CODE_FIELD_IN_PLATFORM).append("=:").append(UNIVERSAL_CODE_FIELD_IN_PLATFORM).append(SPACE)
				.append(WHERE); 
		compositKeysList.forEach(item -> query.append(item).append("=:").append(item).append(SPACE).append(AND));
		query.delete(query.length()-4, query.length());	
		
		return query.toString();
	}

	/**
	 * Build enable/disable platform by universal code id.
	 *
	 * @param codeSet the code set
	 * @return Query to enable/disable platform codes
	 */
	public String buildPlatformEnableDisableByUniversalCodeQuery(String codeSet) {
		String tableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(UPDATE).append(tableName).append(SET).append(MAPPING_STATUS_COLUMN).append("=:")
				.append(MAPPING_STATUS_COLUMN).append(", ").append(TranslationServiceStringConstant.LAST_UPDATED)
				.append("=:").append(TranslationServiceStringConstant.LAST_UPDATED).append(WHERE)
				.append(UNIVERSAL_CODE_ID_COLUMN).append("=:").append(UNIVERSAL_CODE_ID_COLUMN);
		return query.toString();
	}

	/**
	 * Set Platform Code Enable/Disable parameters
	 * @param codeSet
	 * @param status
	 * @param universalCodeId
	 * @param updatedTime
	 * @return parameters object
	 */
	public MapSqlParameterSource setPlatformEnableDisableByUniversalCodeParameters(String status, Integer universalCodeId, Date updatedTime) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue(MAPPING_STATUS_COLUMN, status);
		params.addValue(TranslationServiceStringConstant.LAST_UPDATED, updatedTime);
		params.addValue(UNIVERSAL_CODE_ID_COLUMN, universalCodeId);

		return params;
	}

	/**
	 * Sets the platform update parameters.
	 *
	 * @param codeSet    the code set
	 * @param codeObject the code object
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setPlatformUpdateParameters(String codeSet, Map<String, String> codeObject,Integer universalCodeId) {
		MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
		List<String> compositKeysList = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		sqlParameters.addValue(MAPPING_STATUS_COLUMN, codeObject.get(MAPPING_STATUS_COLUMN));
		sqlParameters.addValue(UNIVERSAL_CODE_FIELD_IN_PLATFORM, universalCodeId);
		sqlParameters.addValue(LAST_UPDATED, new Date());
		compositKeysList.forEach(key -> sqlParameters.addValue(key, codeObject.get(key)) );
		return sqlParameters;
	}

	/**
	 * Builds the platform retrieve by universal code id query.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count the count
	 * @param mappingStatus the mapping status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the string
	 */
	public String buildPlatformRetrieveByUniversalCodeIdQuery(String codeSet, Integer page, Integer count,
			StatusEnum mappingStatus, String orderBy, Direction direction) {

		logger.debug("Inside buildPlatformRetrieveByUniversalCodeIdQuery");

		String platformTableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);

		String universalCodeSetTableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);

		List<String> platformCodeFields = codeSetMetaDataUtil.getPlatformCodeFields(codeSet);

		StringBuilder query = new StringBuilder();

		query.append(SELECT).append(universalCodeSetTableName).append(".").append(UNIVERSAL_CODE_FIELD).append(",");

		ListIterator<String> listIterator = platformCodeFields.listIterator();
		while (listIterator.hasNext()) {
			String nextField = listIterator.next();
			if (!nextField.equalsIgnoreCase(UNIVERSAL_CODE_FIELD)) {
				query.append(platformTableName).append(".").append(nextField);
				if (listIterator.hasNext())
					query.append(",").append(SPACE);
			}
		}
		query.append(FROM).append(platformTableName).append(LEFT_JOIN).append(universalCodeSetTableName);
		query.append(ON);
		query.append(universalCodeSetTableName).append(".").append(ID).append(SPACE).append("=").append(SPACE)
				.append(platformTableName).append(".").append(UNIVERSAL_CODE_FIELD_IN_PLATFORM).append(SPACE);

		query.append(WHERE).append(universalCodeSetTableName).append(".").append(UNIVERSAL_CODE_FIELD).append(SPACE)
				.append("=:").append(UNIVERSAL_CODE_FIELD).append(SPACE);

		if (mappingStatus != null) {
			query.append(AND).append(platformTableName).append(".").append(PLATFORM_MAPPING_STATUS_FIELD).append("=:")
					.append(PLATFORM_MAPPING_STATUS_FIELD).append(SPACE);
		}

		boolean orderByFlag=false;
		if (orderBy != null) {
			orderByFlag=true;
			query.append(ORDER_BY).append(orderBy).append(SPACE);
			if (direction != null)
				query.append(direction.name());
		}
		
		String tableName= platformTableName;

		apendPaginationParams(page, count, query,orderByFlag,tableName);

		return query.toString();
	}

	/**
	 * Sets the platform retrieve by universal code id parameters.
	 *
	 * @param universalCode the universal code
	 * @param mappingStatus the mapping status
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setPlatformRetrieveByUniversalCodeIdParameters(String universalCode,
			StatusEnum mappingStatus) {
		MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
		sqlParameters.addValue(UNIVERSAL_CODE_FIELD, universalCode);

		if (mappingStatus != null) {
			sqlParameters.addValue(PLATFORM_MAPPING_STATUS_FIELD, mappingStatus.name());
		}
		return sqlParameters;
	}

	/**
	 * Sets the universal insert parameters.
	 *
	 * @param codeObject the code object
	 * @param currentDateTimeStamp the current date time stamp
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setUniversalInsertParameters(Map<String, String> codeObject,
			Date currentDateTimeStamp) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		codeObject.entrySet().stream().forEach(entry -> params.addValue(entry.getKey(), entry.getValue()));
		params.addValue(TranslationServiceStringConstant.CREATION_DATE, currentDateTimeStamp);
		return params;
	}

	/**
	 * Builds the universal record count query.
	 *
	 * @param codeSet the code set
	 * @param status the status
	 * @return the string
	 */
	public String buildUniversalRecordCountQuery(String codeSet, StatusEnum status) {

		String universalCodeSetTableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();

		query.append(SELECT).append(COUNT_STAR).append(FROM).append(universalCodeSetTableName);

		if (status != null) {
			query.append(WHERE).append(universalCodeSetTableName).append(".").append(STATUS).append("=:").append(STATUS)
					.append(SPACE);
		}
		return query.toString();
	}

	/**
	 * Builds the platform code record count by code set and universal code query.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param mappingStatus the mapping status
	 * @return the string
	 */
	public String buildPlatformCodeRecordCountByCodeSetAndUniversalCodeQuery(String codeSet, String universalCode,
			StatusEnum mappingStatus) {

		String platformTableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);

		String universalCodeSetTableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);

		StringBuilder query = new StringBuilder();

		query.append(SELECT).append(COUNT_STAR).append(FROM).append(platformTableName);
		query.append(LEFT_JOIN).append(universalCodeSetTableName);
		query.append(ON);
		query.append(universalCodeSetTableName).append(".").append(ID).append(SPACE).append("=").append(SPACE)
				.append(platformTableName).append(".").append(UNIVERSAL_CODE_FIELD_IN_PLATFORM).append(SPACE);
		query.append(WHERE).append(universalCodeSetTableName).append(".").append(UNIVERSAL_CODE_FIELD).append(SPACE)
				.append("=:").append(UNIVERSAL_CODE_FIELD).append(SPACE);

		if (mappingStatus != null) {
			query.append(AND).append(platformTableName).append(".").append(PLATFORM_MAPPING_STATUS_FIELD).append("=:")
					.append(PLATFORM_MAPPING_STATUS_FIELD).append(SPACE);
		}

		return query.toString();
	}

	/**
	 * Builds the platform retrieve all query.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count the count
	 * @param mappingStatus the mapping status filter
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the string
	 */
	public String buildPlatformRetrieveAllQuery(String codeSet, Integer page, Integer count, PlatformCodesMappingStatus mappingStatus,
			String orderBy, Direction direction, String platformIdentifier) {
		logger.debug("Building query for fetching all platform codes for the given CodeSet={}", codeSet);

		String platformTableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);

		String universalCodeSetTableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);

		List<String> platformCodeFields = codeSetMetaDataUtil.getPlatformCodeFields(codeSet);

		StringBuilder query = new StringBuilder();

		query.append(SELECT).append(universalCodeSetTableName).append(".").append(UNIVERSAL_CODE_FIELD).append(",");

		ListIterator<String> listIterator = platformCodeFields.listIterator();

		while (listIterator.hasNext()) {
			String nextField = listIterator.next();
			if (!nextField.equalsIgnoreCase(UNIVERSAL_CODE_FIELD)) {
				query.append(platformTableName).append(".").append(nextField);
				if (listIterator.hasNext())
					query.append(",").append(SPACE);
			}
		}
		query.append(FROM).append(platformTableName).append(LEFT_JOIN).append(universalCodeSetTableName);
		query.append(ON);
		query.append(universalCodeSetTableName).append(".").append(ID).append(SPACE).append("=").append(SPACE)
				.append(platformTableName).append(".").append(UNIVERSAL_CODE_FIELD_IN_PLATFORM);
		query.append(WHERE);
		boolean queryFlag=false;
		if (mappingStatus != null) {
			queryFlag=true;  
			appendMappingStatus(mappingStatus, platformTableName, query);
		}
		
		if(platformIdentifier != null) {
			queryFlag = appendPlatformIdentifier(platformTableName, query, queryFlag);
		}
		if(!queryFlag) {
			query.delete(query.length()-6, query.length());	
		}

		boolean orderByFlag=false;
		if (orderBy != null) {
			orderByFlag=true;
			query.append(ORDER_BY).append(orderBy).append(SPACE);
			if (direction != null)
				query.append(direction.name());
		}
		String tableName= platformTableName;

		apendPaginationParams(page, count, query,orderByFlag,tableName);

		return query.toString();

	}

	private boolean appendPlatformIdentifier(String platformTableName, StringBuilder query, boolean queryFlag) {
		if (queryFlag) {
			query.append(AND);
		}
		queryFlag = true;
		query.append(platformTableName).append(".").append(PLATFORM_IDENTIFIER_COLUMN).append("=:")
				.append(PLATFORM_IDENTIFIER_COLUMN).append(SPACE);
		return queryFlag;
	}

	private void appendMappingStatus(PlatformCodesMappingStatus mappingStatus, String platformTableName,
			StringBuilder query) {
		if (mappingStatus.equals(PlatformCodesMappingStatus.UNMAPPED))
			query.append(platformTableName).append(".").append(PLATFORM_MAPPING_STATUS_FIELD).append(IS).append(NULL)
					.append(SPACE);
		else
			query.append(platformTableName).append(".").append(PLATFORM_MAPPING_STATUS_FIELD).append("=:")
					.append(PLATFORM_MAPPING_STATUS_FIELD).append(SPACE);
	}

	
	private void apendPaginationParams(Integer page, Integer count, StringBuilder query,boolean orderByFlag,String tableName) {
		if (count != null) {
			if(!orderByFlag) {
				query.append(ORDER_BY).append(tableName).append(".").append(ID);
			}
			if (page != null) {
				int from = (count * page) - count;
				query.append(OFFSET).append(String.valueOf(from));
			} else {
				query.append(OFFSET).append(String.valueOf(0));
			}
			query.append(ROWS_FETCH_NEXT).append(String.valueOf(count)).append(ROWS_ONLY);
		}
	}

	/**
	 * Sets the platform retrieve all parameters.
	 *
	 * @param filter the filter
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setPlatformRetrieveAllParameters(PlatformCodesMappingStatus mappingStatus,String platformIdentifier) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		if (mappingStatus != null && !mappingStatus.equals(PlatformCodesMappingStatus.UNMAPPED))
			params.addValue(PLATFORM_MAPPING_STATUS_FIELD, mappingStatus.name());
		if (platformIdentifier != null && !platformIdentifier.isEmpty())
			params.addValue(PLATFORM_IDENTIFIER_COLUMN, platformIdentifier);
		return params;
	}

	/**
	 * Builds the platform record count query.
	 *
	 * @param codeSet the code set
	 * @param filter the filter
	 * @return the string
	 */
	public String buildPlatformRecordCountQuery(String codeSet, PlatformCodesMappingStatus mappingStatus,String platformIdentifier) {
		String platformCodeSetTableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();

		query.append(SELECT).append(COUNT_STAR).append(FROM).append(platformCodeSetTableName);
		query.append(WHERE);
		boolean queryFLag = false;
		if (mappingStatus != null) {
			queryFLag = true;
			appendMappingStatus(mappingStatus, platformCodeSetTableName, query);
		}

		if (platformIdentifier != null) {
			queryFLag = appendPlatformIdentifier(platformCodeSetTableName, query, queryFLag);
		}

		if (!queryFLag) {
			query.delete(query.length() - 6, query.length());
		}
		return query.toString();
	}
	

	/**
	 * Builds the platform code insert query.
	 *
	 * @param codeSet the code set
	 * @return the string
	 */
	public String buildPlatformInsertQuery(String codeSet) {
		logger.debug("Inside buildPlatformInsertQuery");
		String tableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		Set<String> platformCodeFields=new LinkedHashSet<>();
		platformCodeFields.addAll(codeSetMetaDataUtil.getPlatformCodeFields(codeSet));
		platformCodeFields.remove(UNIVERSAL_CODE_FIELD);
		platformCodeFields.add(UNIVERSAL_CODE_ID_COLUMN);
		String columnNames = commaSeparatedColumnNames(platformCodeFields); 
		String columnNameWithColons = colonSeparatedColumnNames(platformCodeFields);
		StringBuilder query = new StringBuilder();
		query.append(INSERT).append(INTO).append(tableName).append(" ( ")
		.append(columnNames).append(" ) ").append(" VALUES ( ").append(columnNameWithColons).append(" )");
		return query.toString();
	}

	/**
	 * Sets the platform insert query parameters.
	 *
	 * @param codeSet    the code set
	 * @param codeObject the code object
	 * @return the map sql parameter source
	 */
	public MapSqlParameterSource setPlatFormInsertParameters(String codeSet,Map<String,String> codeSetObject) {
		List<String> platformCodeFields=new ArrayList<>();
		platformCodeFields.addAll(codeSetMetaDataUtil.getPlatformCodeFields(codeSet));
		MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
		platformCodeFields.remove(UNIVERSAL_CODE_COLUMN);
		platformCodeFields.add(UNIVERSAL_CODE_ID_COLUMN);
		platformCodeFields.forEach(field -> sqlParameters.addValue(field, codeSetObject.get(field)));
		Date currentDate=new Date();
		sqlParameters.addValue(LAST_UPDATED, currentDate);
		sqlParameters.addValue(CREATION_DATE, currentDate);
		return sqlParameters;
	}

	/**
	 * Colon seprated column names.
	 *
	 * @param set the universal code set column names
	 * @return the string
	 */
	private String colonSeparatedColumnNames(Set<String> set) {
		return set.stream().map(":"::concat).collect(Collectors.joining(", "));
	}

	/**
	 * Comma seprated column names.
	 *
	 * @param set the universal code set column names
	 * @return the string
	 */
	private String commaSeparatedColumnNames(Set<String> set) { 
		return set.stream().collect(Collectors.joining(", "));
	}

	public String buildUniversalRetrieveQueryById(String codeSet) {
		logger.debug("Building query to get universal code data bases on Id ");
		String tableName = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(SELECT).append(" * ").append(FROM).append(tableName).append(WHERE).append(ID)
				.append("=:").append(ID).append(SPACE);
		logger.debug("Query building completed to get universal code data bases on Id ");
		return query.toString();
	}

	public MapSqlParameterSource setUniversalRetrieveParametersById(String universalIdInPlatform) {
		MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
		sqlParameters.addValue(ID, universalIdInPlatform);
		return sqlParameters;
	}
	
	/**
	 * Build update query to detach platform code with given universal code.
	 * @param codeSet
	 * @return Update prepared statement
	 */
	public String buildUpdatePlatformCodeDetachUniversalCodeMappingQuery(String codeSet) {
		logger.debug("Inside buildUpdatePlatformCodeDetachUniversalCodeMappingQuery");
		String tableName = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(UPDATE).append(tableName).append(SET).append(MAPPING_STATUS_COLUMN).append("= NULL")
		.append(", ").append(UNIVERSAL_CODE_ID_COLUMN).append("= NULL")
		.append(", ").append(LAST_UPDATED).append("=:").append(LAST_UPDATED)
		.append(WHERE).append(UNIVERSAL_CODE_ID_COLUMN).append("=:").append(UNIVERSAL_CODE_ID_COLUMN);
		return query.toString();
	}
	
	/**
	 * Set parameters to update PlatformCode's Universal Code Id and Mapping Status query
	 * @param universalCodeId
	 * @return Set UNIVERSAL_CODE_ID_COLUMN param
	 */
	public MapSqlParameterSource setUpdatePlatformCodeDetachUniversalCodeMappingQueryParameters(Integer universalCodeId, Date updatedTime) {
		MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
		sqlParameters.addValue(UNIVERSAL_CODE_ID_COLUMN, universalCodeId);
		sqlParameters.addValue(LAST_UPDATED, updatedTime);
		return sqlParameters;
	}

	public String buildQueryToGetMappedPlatformCodeAndUniversalCode(String codeSet,List<Map<String, String>>  mappingList) {
		logger.debug("Building query to get mapped platform codes with respect to universal code for the given codeSet={} ",codeSet);
		List<String> compositKeysList = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		String tableNameUniversal = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		String tableNamePlatform = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(SELECT).append(PLATFORM).append(".").append(UNIVERSAL_CODE_FIELD_IN_PLATFORM).append(", ").append(PLATFORM).append(".")
		.append(MAPPING_STATUS_COLUMN).append(" , ").append(getCompositKeysColumnsForQuery(compositKeysList))
		.append(", ").append(UNIVERSAL).append(".*").append(FROM).append(tableNamePlatform).append(SPACE).append(PLATFORM)
				.append(" LEFT JOIN ").append(tableNameUniversal).append(SPACE).append(UNIVERSAL).append(SPACE).append(ON).append(SPACE).append(PLATFORM).append(".")
				.append(UNIVERSAL_CODE_ID_COLUMN).append(" = ").append(UNIVERSAL).append(".").append(ID).append(SPACE)
				.append(WHERE);
		mappingList.stream().forEach(mappedObject -> {  
			query.append("( ");
			compositKeysList.forEach(item -> 
				query.append(PLATFORM).append(".").append(item).append(" = ").append("'").append(mappedObject.get(item))
						.append("'").append(AND)
			);
			query.delete(query.length()-4, query.length());
			query.append(")").append(" OR ");
		});
		query.delete(query.length()-3, query.length());
		logger.debug("Query building completed to get mapped platform codes with respect to universal code for the given codeSet={} ",codeSet);
		return query.toString();
	}

	private StringBuilder getCompositKeysColumnsForQuery(List<String> compositKeysList) {
		StringBuilder query = new StringBuilder();
		compositKeysList.forEach(item -> query.append(PLATFORM).append(".").append(item).append(" , "));
		query.delete(query.length() - 3, query.length());
		return query;
	}

	public String buildPlatformDataRetrieveQuery(String codeSet, Map<String, String> platformCodes) {
		logger.info("Building query to retrieve platform code data for the given codeset={} and for input request={}",codeSet,platformCodes);
		String tableNamePlatform = codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet);
		String tableNameUniversal = codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet);
		StringBuilder query = new StringBuilder();
		query.append(SELECT).append(PLATFORM).append(".* ,").append(UNIVERSAL).append(".").append(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN)
		.append(SPACE).append(FROM).append(tableNamePlatform).append(SPACE).append(PLATFORM)
		.append(LEFT_JOIN).append(tableNameUniversal).append(SPACE).append(UNIVERSAL).append(SPACE).append(ON).append(SPACE).append(PLATFORM).append(".")
		.append(UNIVERSAL_CODE_ID_COLUMN).append(" = ").append(UNIVERSAL).append(".").append(ID).append(SPACE)
		.append(WHERE);
		platformCodes.keySet().stream().forEach(field -> 
			query.append(field).append("=:").append(field).append(SPACE).append(AND)
		); 
		query.delete(query.length() - 4, query.length());
		logger.info("Query building completed to retrieve platform code data for the given codeset={} and for input reuest={}",codeSet,platformCodes);
		return query.toString();
	}

	public MapSqlParameterSource setPlatformDataRetrieveParameters(Map<String, String> platformCodes) {
		logger.info("Setting  parameters for retrieving platform code data query");
		MapSqlParameterSource params = new MapSqlParameterSource();
		platformCodes.entrySet().stream().forEach(entry -> params.addValue(entry.getKey(), entry.getValue()));
		return params;
	}

}
