package com.chc.arena.translationservice.validation.util;


import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.util.MessageSourceUtil;

/**
 * The Class ValidationUtil.
 */
@Component
public class ValidationUtil {

	private static final Logger logger = LoggerFactory.getLogger(ValidationUtil.class);
	
	private static MessageSourceUtil messageSourceUtil;

	private ValidationUtil() {
		throw new IllegalStateException("Utility class");
	}
    
    @Autowired
    private ValidationUtil(MessageSourceUtil messageSourceUtil) {
    	setBeanMessageSourceUtil(messageSourceUtil);
    }
    
    private static void setBeanMessageSourceUtil(MessageSourceUtil messageSourceUtilBean) {
    	messageSourceUtil= messageSourceUtilBean;
	}
	/**
	 * Reject invalid code set.
	 *
	 * @param validationErrors the validation errors
	 * @param codeSet          the code set
	 */
	public static void rejectInvalidCodeSet(ErrorDetails validationErrors, String codeSet) {
		logger.info("ValidationUtil.rejectInvalidCodeSet [START]");
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put("code-set", codeSet);
		validationErrors.getIssues().put(messageSourceUtil.getMessage("INVALID_CODE_SET"), rejectedValues);
	}

	/**
	 * Reject code set for mapping request.
	 * 
	 * @param validationErrors
	 * @param codeSet
	 */
	public static void rejectInvalidCodeSetForSerachOrMappingRequest(ErrorDetails validationErrors, String codeSet,
			boolean isMappingRequest) {
		logger.info("ValidationUtil.rejectInvalidCodeSetForMappingRequest [START]");
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put("code-set", codeSet);
		validationErrors.getIssues()
				.put(isMappingRequest ? messageSourceUtil.getMessage("INVALID_CODE_SET_FOR_MAPPING_REQUEST")
						: messageSourceUtil.getMessage("INVALID_CODE_SET_FOR_ADVANCED_SEARCH_REQUEST"),
						rejectedValues);
	}

	/**
	 * Missing required field.
	 *
	 * @param validationErrors the validation errors
	 * @param fieldName        the field name
	 */
	public static void missingRequiredField(ErrorDetails validationErrors, String fieldName) {
		HashMap<String, String> map = new HashMap<>();
		map.put(fieldName, null);
		validationErrors.getIssues().put("Required field: " + fieldName + ", missing in request body", map);
	}

	/**
	 * Reject invalid field.
	 *
	 * @param validationErrors the validation errors
	 * @param fieldName        the field name
	 * @param fieldValue       the field value
	 */
	public static void rejectInvalidField(ErrorDetails validationErrors, String fieldName, String fieldValue) {
		HashMap<String, String> map = new HashMap<>();
		map.put(fieldName, fieldValue);

		validationErrors.getIssues().put("Invalid field: " + fieldName + ", in request body", map);
	}

	/**
	 * Reject invalid field value.
	 *
	 * @param validationErrors the validation errors
	 * @param fieldName        the field name
	 * @param fieldValue       the field value
	 * @param regex            the regex
	 */
	public static void rejectInvalidFieldValue(ErrorDetails validationErrors, String fieldName, String fieldValue,
			String regex) {
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put(fieldName, fieldValue);

		validationErrors.getIssues().put("Invalid field value: " + fieldValue + " must match pattern: " + regex,
				rejectedValues);
	}

	/**
	 * Reject null field value.
	 *
	 * @param validationErrors the validation errors
	 * @param fieldName        the field name
	 * @param fieldValue       the field value
	 * @param regex            the regex
	 */
	public static void rejectNullFieldValue(ErrorDetails validationErrors, String fieldName, String fieldValue,
			String regex) {
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put(fieldName, fieldValue);
		validationErrors.getIssues().put("Null field value: " + fieldName + " must match pattern: " + regex,
				rejectedValues);

	}

	/**
	 * Reject field since its not editable by user
	 * 
	 * @param validationErrors
	 * @param fieldName
	 * @param fieldValue
	 */
	public static void rejectField(ErrorDetails validationErrors, String fieldName, String fieldValue) {
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put(fieldName, fieldValue);

		validationErrors.getIssues().put("Field: " + fieldName + " can't be updated.", rejectedValues);
	}

	/**
	 * Reject non key field values
	 * 
	 * @param validationErrors
	 * @param fieldName
	 * @param fieldValue
	 */
	public static void rejectNonKeyField(ErrorDetails validationErrors, String fieldName, String fieldValue) {
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put(fieldName, fieldValue);

		validationErrors.getIssues().put("Field: " + fieldName + ", is not a key/key-participant for platform-code.",
				rejectedValues);
	}

	/**
	 * Checks if is empty.
	 *
	 * @param validationErrors the validation errors
	 * @return true, if is empty
	 */
	public static boolean isEmpty(ErrorDetails validationErrors) {
		return validationErrors.getIssues().isEmpty();
	}

	/**
	 * Reject mulitiple universal code mapping.
	 *
	 * @param validationErrors the validation errors
	 * @param platformCode the platform code
	 * @param platformIdentifier the platform identifier
	 */
	public static void rejectMulitipleUniversalCodeMapping(ErrorDetails validationErrors,Map<String, String> entry,List<String> requiredFields) {
		HashMap<String, String> rejectedValues = new HashMap<>(); 
		requiredFields.stream().forEach(field->rejectedValues.put(field,entry.get(field)));
		validationErrors.getIssues().put("Request contains repeated values of : "+ requiredFields.stream().map(String::trim).collect(Collectors.joining(" , ")),rejectedValues);
	}
	
	/**
	 * Reject Platform Code Insert Request with Invalid Universal Code
	 * @param validationErrors
	 * @param codeSetData
	 */
	public static void rejectPlatformCodeWithInvalidUniversalCode(ErrorDetails validationErrors, Map<String,String> codeSetData) {
		String universalCode=codeSetData.get(UNIVERSAL_CODE_FIELD);
		validationErrors.getIssues().put(String.format(messageSourceUtil.getMessage("UNIVERSAL_CODE_NOT_FOUND_ERROR_MESSAGE"),universalCode), codeSetData);
	}
	
	/**
	 * Reject Duplicate Platform Code + Platform Identifier Insert Request
	 * @param validationErrors
	 * @param codeSetData
	 */
	public static void rejectDuplicatePlatformCode(ErrorDetails validationErrors, Map<String,String> codeSetData,List<String> requiredFields) {
		String platformDataInRequest=requiredFields.stream().map(codeSetData::get).map(String::trim).collect(Collectors.joining(" , "));
		String errorMessage=messageSourceUtil.getMessage("DUPLICATE_PLATFORM_CODE_INSERT_ERROR_MESSAGE")+" : "+platformDataInRequest;
		validationErrors.getIssues().put(errorMessage, codeSetData);
	}

	/**
	 * Reject invalid combination.
	 *
	 * @param validationErrors the validation errors
	 * @param field the field
	 * @param fieldValue the field value
	 */
	public static void rejectInvalidCombination(ErrorDetails validationErrors, String field,
			String fieldValue) {
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put(field, fieldValue);

		validationErrors.getIssues().put("Platform Code and Platform Identifier combination doesn't exist in request,  Field: "+field,
				rejectedValues);
	}

	/**
	 * Missing universal code field or mapping status.
	 *
	 * @param validationErrors the validation errors
	 * @param entryObject the entry object
	 */
	public static void missingUniversalCodeFieldOrMappingStatus(ErrorDetails validationErrors,Map<String, String> entryObject,List<String> requiredFields) {
		HashMap<String, String> rejectedValues = new HashMap<>();
		rejectedValues.put(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD, null);
		rejectedValues.put(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN, null);
		String platformDataInRequest=requiredFields.stream().map(entryObject::get).map(String::trim).collect(Collectors.joining(" , "));
		validationErrors.getIssues().put("Missing  "+TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD+" or "+ TranslationServiceStringConstant.MAPPING_STATUS_COLUMN+" in the request for combination "+platformDataInRequest,
				rejectedValues);
		
	}

	/**
	 * Reject request for no universal code.
	 *
	 * @param validationErrors the validation errors
	 * @param nonExistedUniversalCodesInDbList the non existed universal codes in db list
	 */
	public static void rejectRequestForNoUniversalCode(ErrorDetails validationErrors,
			List<Map<String, String>> nonExistedUniversalCodesInDbList) {
		nonExistedUniversalCodesInDbList.forEach(data->
			validationErrors.getIssues().put(messageSourceUtil.getMessage("REJECT_REQ_NO_UNIVERSAL_CODE"),
					data)
		);
		
	}

	/**
	 * Reject request for non existed platform code.
	 *
	 * @param validationErrors the validation errors
	 * @param nonExistedPlatformCodesInDb the non existed platform codes in db
	 */
	public static void rejectRequestForNonExistedPlatformCode(ErrorDetails validationErrors,
			List<Map<String, String>> nonExistedPlatformCodesInDb) {
		nonExistedPlatformCodesInDb.forEach(data->
			validationErrors.getIssues().put(messageSourceUtil.getMessage("REJECT_REQ_NO_PLATFORM_AND_IDENTIFIER"),
					data)
		);
	}

	/**
	 * Reject request for no platform code mapping with universal code.
	 *
	 * @param validationErrors the validation errors
	 * @param noPlatformCodeMappingWithUniversalCode the no platform code mapping with universal code
	 */
	public static void rejectRequestForNoPlatformCodeMappingWithUniversalCode(ErrorDetails validationErrors,
			List<Map<String, String>> noPlatformCodeMappingWithUniversalCode) {
		noPlatformCodeMappingWithUniversalCode.forEach(data->
			validationErrors.getIssues().put(messageSourceUtil.getMessage("REJECT_REQ_NO_MAPPING"),
					data)
		);
	}

	/**
	 * Reject request for disabled universal code.
	 *
	 * @param validationErrors the validation errors
	 * @param disableUniversalCodes the disable universal codes
	 */
	public static void rejectRequestForDisabledUniversalCode(ErrorDetails validationErrors,
			List<Map<String, String>> disableUniversalCodes) {
		disableUniversalCodes.forEach(data->
			validationErrors.getIssues().put(messageSourceUtil.getMessage("REJECT_REQ_DISABLED_UNIVERSAL_CODE"),
					data)
		);
	}

	/**
	 * Reject request for enable mapping with disabled universal code.
	 *
	 * @param validationErrors the validation errors
	 * @param enableMappingWithDisableUniversalCode the enable mapping with disable universal code
	 */
	public static void rejectRequestForEnableMappingWithDisabledUniversalCode(ErrorDetails validationErrors,
			List<Map<String, String>> enableMappingWithDisableUniversalCode) {
		enableMappingWithDisableUniversalCode.forEach(data->
			validationErrors.getIssues().put(messageSourceUtil.getMessage("REJECT_REQ_DISABLED_UNIVERSAL_CODE_WITH_ENABLED_MAPPING"),
					data)
		);
	}

	/**
	 * Invalid delete mapping request.
	 *
	 * @param validationErrors the validation errors
	 * @param entry the entry
	 */
	public static void invalidDeleteMappingRequest(ErrorDetails validationErrors, Map<String, String> entry) {
		validationErrors.getIssues().put("Inavlid delete mapping request, request should not contain "+TranslationServiceStringConstant.MAPPING_STATUS_COLUMN+"",entry);
	}
	
}
