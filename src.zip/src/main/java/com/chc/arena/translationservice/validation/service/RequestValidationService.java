package com.chc.arena.translationservice.validation.service;

import java.util.List;
import java.util.Map;

import com.chc.arena.translationservice.service.exception.ErrorDetails;

/**
 * The Interface RequestValidationService.
 */
public interface RequestValidationService {

	/**
	 * Checks if is valid code set.
	 *
	 * @param codeSet          the code set
	 * @param validationErrors the validation errors
	 * @return true, if is valid code set
	 */
	boolean isValidCodeSet(String codeSet, ErrorDetails validationErrors);

	/**
	 * Checks if is valid universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode    the universal code
	 * @param validationErrors the validation errors
	 * @return true, if is valid universal code
	 */
	boolean isValidUniversalCode(String codeSet, String universalCode, ErrorDetails validationErrors);

	/**
	 * Checks if is valid universal code create request.
	 *
	 * @param codeSet          the code set
	 * @param requestObject    the request object
	 * @param validationErrors the validation errors
	 * @return true, if is valid universal code create request
	 */
	boolean isValidUniversalCodeCreateRequest(String codeSet, Map<String, String> requestObject,
			ErrorDetails validationErrors);
	
	/**
	 * Checks if the platform code object is valid
	 * @param codeSet
	 * @param platformCodeObject
	 * @param validationErrors
	 * @return true if valid, else false with ValidationErrors containing all validation failures.
	 */
	boolean isValidRequestForGetMappedUniversalCode(String codeSet, Map<String, String> platformCodeObject,
			ErrorDetails validationErrors);
	
	/**
	 * Checks if the code set is not advanced search code set
	 * @param codeSet
	 * @param validationErrors
	 * @boolean isMappingRequest, true indicates mapping request, false indicates search request
	 * @return
	 */
	boolean isValidCodeSetForSearchOrMappingRequest(String codeSet, ErrorDetails validationErrors, boolean isMappingRequest);
	
	/**
	 * Check if the request is valid Universal Code update request.
	 * @param codeSet
	 * @param requestObject
	 * @param universalCode
	 * @param validationErrors
	 * @return
	 */
	boolean isValidUniversalCodeUpdateRequest(String codeSet, Map<String, String> requestObject, String universalCode, ErrorDetails validationErrors);
		
	/**
	 * Check if the request is valid search request.
	 * @param codeSet
	 * @param platformCodeData
	 * @param validationErrors
	 * @return
	 */
	boolean isValidSearchRequest(String codeSet, Map<String, String> platformCodeData, ErrorDetails validationErrors);
	
	/**
	 * Check validations in query parameters.
	 *
	 * @param validationErrors the validation errors
	 * @param page the page
	 * @param count the count
	 * @return true, if successful
	 */
	boolean checkValidationsInQueryParameters(ErrorDetails validationErrors, Integer page, Integer count,String platformIdentifier,String codeSet);

	/**
	 * Checks if is valid update mapping request.
	 *
	 * @param codeSet the code set
	 * @param platformCodeObject the platform code object
	 * @param validationErrors the validation errors
	 * @return true, if is valid update mapping request
	 */
	public boolean isValidUpdateMappingRequest(String codeSet, List<Map<String, String>> platformCodeObject,ErrorDetails validationErrors);
	

	/**
	 * Checks if is valid request for platform codes insertion.
	 *
	 * @param codeSet the code set
	 * @param platformCodes the platform codes
	 * @param validationErrors the validation errors
	 * @return true, if is valid request for platform codes insertion
	 */
	boolean isValidRequestForPlatformCodesInsertion(String codeSet, List<Map<String, String>> platformCodes, ErrorDetails validationErrors);

	/**
	 * Checks if is valid get request for plat form codes.
	 *
	 * @param codeSet the code set
	 * @param platformCodeObject the platform code object
	 * @param validationErrors the validation errors
	 * @return true, if is valid get request for plat form codes
	 */
	boolean isValidGetRequestForPlatFormCodes(String codeSet, Map<String, String> platformCodeObject,ErrorDetails validationErrors);
}
