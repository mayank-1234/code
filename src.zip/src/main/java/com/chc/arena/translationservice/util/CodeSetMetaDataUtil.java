package com.chc.arena.translationservice.util;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import com.chc.arena.translationservice.model.CodeSetsMetaData;

/**
 * The Class CodeSetMetaDataUtil.
 */
@Component
@EnableConfigurationProperties(CodeSetsMetaData.class)
public class CodeSetMetaDataUtil {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(CodeSetMetaDataUtil.class);

	/** The code sets meta data. */
	@Autowired
	private CodeSetsMetaData codeSetsMetaData;

	/**
	 * Gets the code sets.
	 *
	 * @return the code sets
	 */
	public List<String> getCodeSets() {
		logger.info("CodeSetMetaDataUtil.getCodeSets [START]");
		return codeSetsMetaData.getSupportedCodeSets();
	}

	/**
	 * Gets the universal code fields.
	 *
	 * @param codeSet the code set
	 * @return the universal code fields
	 */
	public List<String> getUniversalCodeFields(String codeSet) {
		return codeSetsMetaData.getUniversalCodeFields().get(codeSet);
	}

	/**
	 * Gets the universal code required fields.
	 *
	 * @param codeSet the code set
	 * @return the universal code required fields
	 */
	public List<String> getUniversalCodeRequiredFields(String codeSet) {
		return codeSetsMetaData.getUniversalCodeRequiredFields().get(codeSet);
	}

	/**
	 * Gets the universal code field value regex.
	 *
	 * @param codeSet the code set
	 * @param field   the field
	 * @return the universal code field value regex
	 */
	public String getUniversalCodeFieldValueRegex(String codeSet, String field) {
		return codeSetsMetaData.getUniversalCodeFieldValueRegex().get(codeSet).get(field);
	}

	/**
	 * Gets the collection for given code set.
	 *
	 * @param codeSet the code set
	 * @return the collection for given code set
	 */
	public String getAdvancedSearchCollectionName(String codeSet) {
		return codeSetsMetaData.getAdvancedSearchCollectionNames().get(codeSet);
	}
	
	/**
	 * Gets the advanced search enabled code sets.
	 *
	 * @return the advanced search enabled code sets
	 */
	public List<String> getAdvancedSearchEnabledCodeSets() {
		return codeSetsMetaData.getAdvancedSearchEnabledCodeSets();
	}
	

	/**
	 * Gets the universal code set table name.
	 *
	 * @param codeSet the code set
	 * @return the universal code set table name
	 */
	public String getUniversalCodeSetTableName(String codeSet) {
		return codeSetsMetaData.getUniversalCodeDbTableNames().get(codeSet);
	}

	/**
	 * Gets the platform code set table name.
	 *
	 * @param codeSet the code set
	 * @return the platform code set table name
	 */
	public String getPlatformCodeSetTableName(String codeSet) {
		return codeSetsMetaData.getPlatformCodeDbTableNames().get(codeSet);
	}


	/**
	 * Gets the list of fields in platform code for given code set. 
	 *
	 * @param codeSet the code set
	 * @return the platform code fields
	 */
	public List<String> getPlatformCodeFields(String codeSet) {
		return codeSetsMetaData.getPlatformCodeFields().get(codeSet);
	}
	
	/**
	 * Gets the platform code field value regex.
	 *
	 * @param codeSet the code set
	 * @param field the field
	 * @return the platform code field value regex
	 */
	public String getPlatformCodeFieldValueRegex(String codeSet, String field) {
		return codeSetsMetaData.getPlatformCodeFieldValueRegex().get(codeSet).get(field);
	}
	
	/**
	 * Get Platform Code Composite Key Fields of particular codeset.
	 *
	 * @param codeSet the code set
	 * @return the platform code composite key fields
	 */
	public List<String> getPlatformCodeCompositeKeyFields(String codeSet) {
		return codeSetsMetaData.getPlatformCodeCompositeKeyFields().get(codeSet);
	}
	
	/**
	 * Checks if is advanced search enabled code set.
	 *
	 * @param codeSet the code set
	 * @return true, if is advanced search enabled code set
	 */
	public boolean isAdvancedSearchEnabledCodeSet(String codeSet) {
		return codeSetsMetaData.getAdvancedSearchEnabledCodeSets().contains(codeSet);
	}
	
	/**
	 * Get required fields for advanced search for particular code set.
	 * @param codeSet
	 * @return list of all required fields.
	 */
	public List<String> getAdvancedSearchRequiredFields(String codeSet) {
		return codeSetsMetaData.getAdvancedSearchRequiredFields().get(codeSet);
	}

	/**
	 * Gets advanced search query fields for particular code set
	 * @param codeSet
	 * @return
	 */
	public Map<String, String> getAdvancedSearchQueryFields(String codeSet) {
		return codeSetsMetaData.getAdvancedSearchQueryFields().get(codeSet);
	}
	
	/**
	 * Gets advanced search filter query fields for particular code set
	 * @param codeSet
	 * @return
	 */
	public Map<String, String> getAdvancedSearchFilterQueryFields(String codeSet) {
		return codeSetsMetaData.getAdvancedSearchFilterQueryFields() == null ? new HashMap<>() : codeSetsMetaData.getAdvancedSearchFilterQueryFields().get(codeSet);
	}
	
	/**
	 * Advanced Search Default Result Count
	 * @return
	 */
	public int getAdvancedSearchDefaultResultCount() {
		return codeSetsMetaData.getAdvancedSearchDefaultResultCount();
	}
}
