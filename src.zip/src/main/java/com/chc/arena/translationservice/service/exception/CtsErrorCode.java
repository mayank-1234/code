/**
 * 
 */
package com.chc.arena.translationservice.service.exception;

import org.springframework.http.HttpStatus;

/**
 * The Enum ErrorCode.
 *
 * @author narendra.dubey
 */
public enum CtsErrorCode {
	
	/** The bad request. */
	BAD_REQUEST(HttpStatus.BAD_REQUEST),

	/** The internal server error. */
	INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR),
	
	/** The entity not found. */
	ENTITY_NOT_FOUND(HttpStatus.NOT_FOUND), 
	
	/** The resource already exist. */
	UNIVERSAL_CODE_ALREADY_EXIST(HttpStatus.CONFLICT),
	
	/** The platform code already exist. */
	PLATFORM_CODE_ALREADY_EXIST(HttpStatus.CONFLICT);
	
    /** The http status. */
    private HttpStatus httpStatus;


    /**
     * Instantiates a new cts error code.
     *
     * @param httpStatus the http status
     */
    CtsErrorCode(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }


    /**
     * Gets the http status.
     *
     * @return the http status
     */
    public HttpStatus getHttpStatus() {
        return this.httpStatus;
    }


    /**
     * Gets the enum by http status.
     *
     * @param httpStatus the http status
     * @return the enum by http status
     */
    public static CtsErrorCode getEnumByHttpStatus(HttpStatus httpStatus) {
        for (CtsErrorCode ctsErrorCode : CtsErrorCode.values()) {
            if (httpStatus == ctsErrorCode.httpStatus)
                return ctsErrorCode;
        }
        return null;
    }
}
