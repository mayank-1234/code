package com.chc.arena.translationservice.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ApiResponse;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.UniversalCodeService;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.validation.annotation.RequestType;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.annotation.ValidRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@CrossOrigin(origins = { "*" }, maxAge = 4800, allowCredentials = "false", exposedHeaders = {"hasPreviousPage", "hasNextPage", "currentPage", "totalPages", "totalRecordsCount", "currentPageRecordsCount", "requestedRecordsCount"})
@Validated
@RequestMapping("/code-sets/{code-set}")
@Api(value = "Universal Codes Service", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, tags = {
		"Operations pertaining to management of Universal Codes and data." })
public class UniversalCodeController {

	private static final Logger logger = LoggerFactory.getLogger(UniversalCodeController.class);

	@Autowired
	private UniversalCodeService universalCodeService;
	
	/**
	 * Gets the all.
	 *
	 * @param codeSet the code set
	 * @param from    the from
	 * @param count   the count
	 * @param status  the status
	 * @return the all
	 * @throws ServiceException
	 */
	@GetMapping(value = "/universal-codes", produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType=RequestType.GET_ALL_UNIVERSAL_CODES)
	@ApiOperation(value = "${universal-code.api.apioperation.getAll.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.getAll.notes}")
	public ResponseEntity<ApiResponse> getAll(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet, @ApiParam(value = "${record-from}", required = false) @RequestParam(value = "page", required = false) Integer page, 
			@ApiParam(value = "${record-count}", required = false) @RequestParam(value = "count", required = false) Integer count, @ApiParam(value = "${status-type-universal}", required = false) @RequestParam(value = "status", required = false) StatusEnum status, 
			@ApiParam(value = "${orderBy-universal}", required = false) @RequestParam(value = "orderBy", required = false) String orderBy, @ApiParam(value = "${direction-universal}", required = false) @RequestParam(value = "direction", required = false) Direction direction
			) throws ServiceException {
		
		logger.info("Handling incoming request to get all Universal Codes for the given CodeSet={}, query parameters and values passed are Page={}, Count={}, Status={}, OrderBy{} and Direction={}", codeSet, page, count, status, orderBy, direction);
		int currentPageRecordsCount = 0;
		
		HttpHeaders responseHeaders = setResponseHeaders(codeSet, page, count, status);
				
		ServiceResponse<List<Map<String,String>>> universalCodes = universalCodeService.getAllUniversalCodes(codeSet, page, count, status, orderBy, direction);
		
		currentPageRecordsCount = universalCodes.getBody().size();
		
		logger.info("Returning Count={} Universal Codes for the given CodeSet={}", universalCodes.getBody().size(), codeSet);
				
	    responseHeaders.set("currentPageRecordsCount", String.valueOf(currentPageRecordsCount));
	    
	    logger.info("Setting Response headers with details ResponseHeaders={}", responseHeaders);
		
		return ResponseEntity.ok().headers(responseHeaders).body(new ApiResponse(ApiStatus.SUCCESS, universalCodes.getBody(), universalCodes.getMessage()));
	}

	/**
	 * Gets the by id.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return the by id
	 */
	@GetMapping(value = "/universal-codes/{universal-code}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.GET_UNIVERSAL_BY_UNIVERSAL_CODE)
	@ApiOperation(value = "${universal-code.api.apioperation.getByCode.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.getByCode.notes}")
	public ResponseEntity<ApiResponse> getByCode(
			@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${universal-code}", required = true) @PathVariable("universal-code") String universalCode)
			throws ServiceException {
		logger.info("Handling incloming request to get Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
		ServiceResponse<Map<String, String>> universalCodeDataServiceResponse = universalCodeService.getByCode(codeSet, universalCode);
		logger.info("Returning Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
		return ResponseEntity.ok(new ApiResponse(ApiStatus.SUCCESS, universalCodeDataServiceResponse.getBody(), universalCodeDataServiceResponse.getMessage()));
	}

	/**
	 * Search.
	 *
	 * @param codeSet          the code set
	 * @param platformCodeData the platform code data
	 * @return the response entity
	 * @throws ServiceException
	 */
	@PostMapping(value = "/universal-codes/search", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.SEARCH_UNIVERSAL_CODE)
	@ApiOperation(value = "${universal-code.api.apioperation.search.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.search.notes}")
	public ResponseEntity<ApiResponse> search(
			@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${platform-data}", required = true) @RequestBody Map<String, String> platformCodeData,
			@ApiParam(value = "${record-from}", required = false) @RequestParam(value = "from", required = false) Integer from,
			@ApiParam(value = "${record-count}", required = false) @RequestParam(value = "count", required = false) Integer count)
			throws ServiceException {
		logger.info("Handling incoming request to Search Universal Code for the given CodeSet={}, request body Platfrom Code Data={} & Query parameters and values passed are From={}, Count={}", codeSet, platformCodeData, from, count);

		ServiceResponse<List<Map<String, String>>> serivceResponse = universalCodeService.search(codeSet, platformCodeData, from, count);
		
		logger.info("Search Universal Code Service for the given CodeSet={}, request body Platfrom Code Data={} & Query parameters From={}, Count={}, is returning with Status={}, & {} Universal Code(s), with message={}", 
				codeSet, platformCodeData, from, count, ApiStatus.SUCCESS, serivceResponse.getBody().size(), serivceResponse.getMessage());
		return ResponseEntity.ok(new ApiResponse(ApiStatus.SUCCESS, serivceResponse.getBody(), serivceResponse.getMessage()));
	}

	/**
	 * Gets the mapped universal code.
	 *
	 * @param codeSet      the code set
	 * @param platformCode the platform code
	 * @return the mapped universal code
	 * @throws ServiceException
	 */
	@PostMapping(value = "/platform-codes/mapped-universal-code", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.GET_MAPPED_UNIVERSAL_CODE)
	@ApiOperation(value = "${universal-code.api.apioperation.getMappedUniversalCode.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.getMappedUniversalCode.notes}")
	public ResponseEntity<ApiResponse> getMappedUniversalCode(
			@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${platform-code-data}", required = true) @RequestBody Map<String, String> platformCode)
			throws ServiceException {
		logger.info("Handling incoming request to Get Mapped Universal Code for the given CodeSet={}, request body Platfrom Code Data={}", codeSet, platformCode);

		ServiceResponse<Map<String, String>> serviceResponse = universalCodeService.getMappedUniversalCode(codeSet, platformCode);

		logger.info("Request to Get Mapped Universal Code for the given CodeSet={}, request body Platfrom Code Data={} is Returning with status: {}, Universal-Code: {}", 
				codeSet, platformCode, ApiStatus.SUCCESS, serviceResponse.getBody() != null? serviceResponse.getBody().get(TranslationServiceStringConstant.UNIVERSAL_CODE_COLUMN) : null);

		return ResponseEntity.ok(new ApiResponse(ApiStatus.SUCCESS, serviceResponse.getBody(), serviceResponse.getMessage()));
	}

	/**
	 * Insert.
	 *
	 * @param codeSet           the code set
	 * @param universalCodeData the universal code data
	 * @return the response entity
	 * @throws ServiceException
	 */
	@PostMapping(value = "/universal-codes", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.CREATE_UNIVERSAL_CODE)
	@ApiOperation(value = "${universal-code.api.apioperation.insert.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.insert.notes}")
	public ResponseEntity<ApiResponse> insert(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet, @ApiParam(value = "${universal-code-data}", required = true) @RequestBody Map<String, String> universalCodeData) throws ServiceException {		
		logger.info("Insert [START]: Code Set: {}, Universal Code Data: {}", codeSet, universalCodeData);
		String message = universalCodeService.insert(codeSet, universalCodeData);
		ApiResponse apiResponse =new ApiResponse(ApiStatus.SUCCESS,null,message);
		logger.info("Insert [END]: Code Set: {}, Universal Code Data: {}", codeSet, universalCodeData);
		return ResponseEntity.ok(apiResponse);
	}

	/**
	 * Update.
	 *
	 * @param codeSet           the code set
	 * @param universalCodeData the universal code data
	 * @param universalCode     the universal code
	 * @return the response entity
	 * @throws ServiceException
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	@PatchMapping(value = "/universal-codes/{universal-code}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.UPDATE_UNIVERSAL_CODE)
	@ApiOperation(value = "${universal-code.api.apioperation.update.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.update.notes}")
	public ResponseEntity<ApiResponse> update(
			@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${universal-code-data}", required = true) @RequestBody Map<String, String> universalCodeData,
			@ApiParam(value = "${universal-code}", required = true) @PathVariable("universal-code") String universalCode)
			throws ServiceException {
		logger.info("Handling incoming Update Request for Universal Code for the given CodeSet={}, request body Universal Code Data={}, Query Params Universal Code={}", codeSet, universalCodeData, universalCode);
		String message = universalCodeService.update(codeSet, universalCode, universalCodeData);
		logger.info("Incoming Update Request for Universal Code for the given CodeSet={}, request body Universal Code Data={}, Query Params Universal Code={}, is returning with Message={}", codeSet, universalCodeData, universalCode, message);
		return ResponseEntity.ok(new ApiResponse(ApiStatus.SUCCESS, null, message));
	}

	/**
	 * Delete.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @return the response entity
	 * @throws ServiceException
	 */
	@DeleteMapping(value = "/universal-codes/{universal-code}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest
	@ApiOperation(value = "${universal-code.api.apioperation.delete.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${universal-code.api.apioperation.delete.notes}")
	public ResponseEntity<ApiResponse> delete(
			@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${universal-code}", required = true) @PathVariable("universal-code") String universalCode)
			throws ServiceException {
		logger.info("Handling incoming Update Request to delete a Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
		ServiceResponse<Boolean> universalCodeDeleteResponse=universalCodeService.delete(codeSet, universalCode);
		logger.info("Successfully deleted Universal Code identified by UniversalCode={} for the given CodeSet={}", universalCode, codeSet);
		return ResponseEntity.ok(new ApiResponse(ApiStatus.SUCCESS, null, universalCodeDeleteResponse.getMessage()));
	}
	
	/**
	 * Sets the response headers.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count the count
	 * @param status the status
	 * @return the http headers
	 */
	private HttpHeaders setResponseHeaders(String codeSet, Integer page, Integer count, StatusEnum status) {
		HttpHeaders responseHeaders = new HttpHeaders();
		
		if(page != null && count != null) {
			int totalPages = 0;
			int totalRecordsCount = universalCodeService.getUniversalCodesRecordCount(codeSet, status);
			if(totalRecordsCount > 0) {
				double calculatedPages = ((double)totalRecordsCount/(double)count);
				totalPages = (int) Math.ceil(calculatedPages);
			}
			boolean hasNextPage = totalPages > page;
			boolean hasPreviousPage = page > 1;
			
			responseHeaders.set("hasPreviousPage", String.valueOf(hasPreviousPage));
		    responseHeaders.set("hasNextPage", String.valueOf(hasNextPage));
		    responseHeaders.set("currentPage", String.valueOf(page));
		    responseHeaders.set("totalPages", String.valueOf(totalPages));
		    responseHeaders.set("totalRecordsCount", String.valueOf(totalRecordsCount));
		    responseHeaders.set("requestedRecordsCount", String.valueOf(count));
		}
		return responseHeaders;
	}
}
