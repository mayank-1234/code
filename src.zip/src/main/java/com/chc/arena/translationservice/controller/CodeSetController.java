package com.chc.arena.translationservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chc.arena.translationservice.response.model.ApiResponse;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.service.CodeSetService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * The Class CodeSetController.
 */
@RestController
@CrossOrigin(origins = { "*" }, maxAge = 4800, allowCredentials = "false", exposedHeaders = {"hasPreviousPage", "hasNextPage", "currentPage", "totalPages", "totalRecordsCount", "currentPageRecordsCount"})
@PropertySource("classpath:swagger.properties")
@Api(value = "Code-Set Service", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, tags = {"Operations pertaining to management of code-sets."})
public class CodeSetController {
	
	private static final Logger logger=LoggerFactory.getLogger(CodeSetController.class);

	/** The code set service. */
	@Autowired
	private CodeSetService codeSetService;

	/**
	 * Gets the all.
	 *
	 * @return the all
	 */
	@GetMapping(path = "/code-sets", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "${code-set.api.apioperation.getall.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${code-set.api.apioperation.getall.notes}")
	public ResponseEntity<ApiResponse> getAll() {
		logger.info("Fetching all supported code-sets");
		List<String>codeSets=codeSetService.getAllSupportedCodeSets();
		ApiResponse apiResponse = new ApiResponse();
		apiResponse.setBody(codeSets);
		apiResponse.setStatus(ApiStatus.SUCCESS);
		logger.info("Returning {} supported code-sets.", codeSets.size());
		return ResponseEntity.ok(apiResponse);
	}
}
