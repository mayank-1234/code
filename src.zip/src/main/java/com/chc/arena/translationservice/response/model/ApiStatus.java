/**
 * 
 */
package com.chc.arena.translationservice.response.model;

/**
 * The Enum ServiceStatus.
 *
 * @author narendra.dubey
 */
public enum ApiStatus {
	
	/** The success. */
	SUCCESS("SUCCESS"),
	
	/** The error. */
	ERROR("ERROR"),
	
	/** The partial success. */
	PARTIAL_SUCCESS ("PARTIAL_SUCCESS");
	
    private String status;

    /**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

    ApiStatus(String status) {
        this.status = status;
    }

    public static ApiStatus getApiStatusByStatus(String status) {
        for (ApiStatus apiStatus : ApiStatus.values()) {
            if (status.equalsIgnoreCase(apiStatus.status))
                return apiStatus;
        }
        return null;
    }

}
