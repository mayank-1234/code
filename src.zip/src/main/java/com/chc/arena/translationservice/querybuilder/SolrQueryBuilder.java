package com.chc.arena.translationservice.querybuilder;

import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.OR;
import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.SCORE;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.util.ClientUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;

@Component
public class SolrQueryBuilder {

	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	/**
	 * Build SolrQuery for specified parameters & code set meta data configurations
	 * @param codeSet
	 * @param platformObject
	 * @param from
	 * @param count
	 * @return SolrQuery
	 */
	public SolrQuery buildQueryForSearch(String codeSet, Map<String, String> platformObject, Integer from, Integer count) {
		Map<String, String> queryFields = codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet);
		Map<String, String> filterQueryFields = codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet);
		List<String> fieldList = codeSetMetaDataUtil.getUniversalCodeFields(codeSet);
		SolrQuery query = new SolrQuery();		
		StringBuilder queryString = new StringBuilder();
		queryFields.entrySet().stream().forEach(entry -> {
			if(platformObject.containsKey(entry.getKey())) {
				queryString.append(replacePlaceHoldersWithActualValues(platformObject, entry));
				queryString.append(OR);
			}
		});
		query.setQuery(queryString.length() != 0 ? queryString.substring(0, queryString.lastIndexOf(OR)) : "*");
		filterQueryFields.entrySet().stream().forEach(entry -> {
			if(platformObject.containsKey(entry.getKey())) {
				query.addFilterQuery(replacePlaceHoldersWithActualValues(platformObject, entry));
			}
		});
		
		query.addFilterQuery("status: ENABLED");
		
		fieldList.forEach(query::addField);
		query.addField(SCORE);
		
		query.setStart(from);
		query.setRows(count != null ? count : codeSetMetaDataUtil.getAdvancedSearchDefaultResultCount());
		
		return query;
	}
	
	private String replacePlaceHoldersWithActualValues(Map<String, String> platformObject, Entry<String, String> entry) {
	    return entry.getValue().replaceAll("<" + entry.getKey() + ">", Matcher.quoteReplacement(ClientUtils.escapeQueryChars(platformObject.get(entry.getKey()))));
	}

}
