/**
 * 
 */
package com.chc.arena.translationservice.service.impl;

import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.ID;
import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.MAPPING_STATUS_COLUMN;
import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.STATUS;
import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD;
import static com.chc.arena.translationservice.contants.TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.dao.PlatformCodeSetSQLDao;
import com.chc.arena.translationservice.dao.UniversalCodeSetSQLDao;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.PlatformCodeService;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.util.ValidationUtil;

/**
 * The Class PlatformCodeServiceImpl.
 *
 * @author narendra.dubey
 */
@Service
public class PlatformCodeServiceImpl implements PlatformCodeService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(PlatformCodeServiceImpl.class);

	@Autowired
	private PlatformCodeSetSQLDao platformCodeSetSQLDao;

	@Autowired
	private UniversalCodeSetSQLDao universalCodeSetSQLDao;

	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Autowired
	private MessageSourceUtil messageSourceUtil;

	public static final String NO_UNIVERSAL_CODE = "NO_UNIVERSAL_CODE";
	
	public static final String NO_PLATFORM_CODE = "NO_PLATFORM_CODE";
	
	public static final String NO_MAPPING = "NO_MAPPING";
	
	public static final String MAPPING_WITH_DISABLE = "MAPPING_WITH_DISABLE";
	
	public static final String DISABLE_UNIVERSAL_CODE = "DISABLE_UNIVERSAL_CODE";

	/**
	 * Gets the platform codes by universal code.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @param from          the from
	 * @param count         the count
	 * @param mappingStatus the mapping status
	 * @param orderBy       the order by
	 * @param direction     the direction
	 * @return the platform codes by universal code
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<List<Map<String, String>>> getPlatformCodesByUniversalCode(String codeSet,
			String universalCode, Integer page, Integer count, StatusEnum mappingStatus, String orderBy,
			Direction direction) throws ServiceException {

		logger.info("Processing request to get all mapped platform codes for the given CodeSet={} and UniversalCode={}",
				codeSet, universalCode);

		List<Map<String, String>> mappedPlatformCodes = new ArrayList<>();

		try {
			universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode);

			List<Map<String, Object>> platformCodesByUniversalCode = platformCodeSetSQLDao
					.getPlatformCodesByUniversalCode(codeSet, universalCode, page, count, mappingStatus, orderBy,
							direction);

			ListIterator<Map<String, Object>> platformCodeIterator = platformCodesByUniversalCode.listIterator();

			while (platformCodeIterator.hasNext()) {
				Map<String, Object> nextPlaformCodeData = platformCodeIterator.next();

				Map<String, String> collectedPlatformCode = new HashMap<>();
				nextPlaformCodeData.entrySet().forEach(entry -> collectedPlatformCode.put(entry.getKey(),
						(entry.getValue() != null ? entry.getValue().toString() : null)));
				mappedPlatformCodes.add(collectedPlatformCode);
			}

		} catch (DaoException daoException) {
			String message = daoException.getMessage();
			CtsErrorCode errorCode = daoException.getErrorCode();
			logger.error(
					"Data access exception occured while trying to fetch mapped platform codes for CodeSet={} and UniversalCode={}, Error={}",
					codeSet, universalCode, errorCode + ":" + message);
			if (errorCode.equals(CtsErrorCode.ENTITY_NOT_FOUND)) {
				Map<String, String> rejectedUniversalCode = new HashMap<>();
				rejectedUniversalCode.put("Universal code in URL", universalCode);
				throw new ServiceException(message, rejectedUniversalCode, errorCode);
			}

			throw new ServiceException(message, errorCode, null);
		}

		if (mappedPlatformCodes.isEmpty()) {
			logger.warn("No mapped Platform Codes found in repository for the given CodeSet={} and UniversalCode={}",
					codeSet, universalCode);
		} else {
			logger.info("Found {} mapped Platform Code(s) for the given CodeSet={} and UniversalCode={}",
					mappedPlatformCodes.size(), codeSet, universalCode);
		}

		return new ServiceResponse<>(
				(mappedPlatformCodes.isEmpty() ? messageSourceUtil.getMessage("NO_MAPPED_PLATFORM_CODES_FOUND") : messageSourceUtil.getMessage("MAPPED_PLATFORM_CODES_FOUND")),
				mappedPlatformCodes);
	}

	/**
	 * Insert one or more platform codes in repository and optionally map them to
	 * existing universal code.
	 *
	 * @param codeSet       the code set
	 * @param platformCodes the platform code data
	 * @return the service response
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<String> insert(String codeSet, List<Map<String, String>> platformCodes)
			throws ServiceException {

		logger.info("Inserting PlatformCodesCount={} platform codes for the given CodeSet={}.", platformCodes.size(),
				codeSet);

		ErrorDetails validationErrors = new ErrorDetails();

		final AtomicInteger insertionCount = new AtomicInteger();

		platformCodes.forEach(platformCodeData -> {
			boolean isInsertable = true;
			String universalCode = platformCodeData.get(UNIVERSAL_CODE_FIELD);
			List<String> requiredFields=codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
			String platformDataInRequest=requiredFields.stream().map(platformCodeData::get).map(String::trim).collect(Collectors.joining(" , "));
			if (universalCode != null) {
				try {
					Map<String, Object> universalCodeDbObject = universalCodeSetSQLDao.getByUniversalCode(codeSet,
							universalCode);
					platformCodeData.put(UNIVERSAL_CODE_ID_COLUMN, universalCodeDbObject.get(ID).toString());
					platformCodeData.put(MAPPING_STATUS_COLUMN, universalCodeDbObject.get(STATUS).toString());
				} catch (DaoException e) {
					logger.warn(
							"Rejecting insertion for this Platform Codes Data as UniversalCode={} in provided Platform Code insert request "
									+ "identified by PlatformData={} does not exist.",
							universalCode, platformDataInRequest);
					isInsertable = false;
					ValidationUtil.rejectPlatformCodeWithInvalidUniversalCode(validationErrors, platformCodeData);
				}
			}
			if (isInsertable) {
				try {
					platformCodeSetSQLDao.insert(codeSet, platformCodeData);
					logger.info(
							"Successfully inserted a new Platform Codes identified by PlatformData={} for the given CodeSet={}",
							platformDataInRequest, codeSet);
					insertionCount.incrementAndGet();
				} catch (DaoException daoException) {
					logger.warn(
							"Rejecting insertion for this Platform Code Data as provided Platform Codes identified by PlatformData={} already exist in repository for the given CodeSet={}.",
							platformDataInRequest, codeSet);
					ValidationUtil.rejectDuplicatePlatformCode(validationErrors, platformCodeData,requiredFields);
				}
			}
		});

		if (insertionCount.get() < 1) {
			logger.info(
					"All PlatformCodesCount={} Platform Codes insertion failed for the given CodeSet={}, either due to non-existing Universal Code for mapping or the requested Platform Code already existed in repository.",
					codeSet, platformCodes.size());
			throw new ServiceException(messageSourceUtil.getMessage("PLATFOM_CODES_INSERT_ERROR"), CtsErrorCode.BAD_REQUEST, validationErrors);
		}

		String response = validationErrors.getIssues().isEmpty() ? ApiStatus.SUCCESS.name()
				: ApiStatus.PARTIAL_SUCCESS.name();

		logger.info("Successfully inserted PlatformCodeInsertedCount={} Platform Codes for the given CodeSet={}",
				insertionCount, codeSet);

		return new ServiceResponse<>(
				(validationErrors.getIssues().isEmpty() ? messageSourceUtil.getMessage("PLATFORM_CODES_CREATED") : messageSourceUtil.getMessage("PLATFORM_CODES_CREATED_PARTIALLY")),
				validationErrors, response);
	}

	/**
	 * Update given platform codes mapping(s) or enable/disable the platform
	 * code(s).
	 *
	 * @param codeSet       the code set
	 * @param platformCodes the platform codes
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<String> update(String codeSet,
			List<Map<String, String>> platformCodeData) throws ServiceException {
		logger.info(
				"Processing request to update all Platform Codes with mappingRequestSize={} with respect to Universal Codes for the given CodeSet={}",
				platformCodeData.size(), codeSet);
		List<Map<String, String>> nonExistedUniversalCodesInDb = new ArrayList<>();
		List<Map<String, String>> nonExistedPlatformCodesInDb = new ArrayList<>();
		List<Map<String, String>> noPlatformCodeMappingWithUniversalCode = new ArrayList<>();
		List<Map<String, String>> enableMappingWithDisableUniversalCode = new ArrayList<>();
		List<Map<String, String>> disableUniversalCodes = new ArrayList<>();
		Map<String, List<Map<String, String>>> errorMap = initializeErrorMap(nonExistedUniversalCodesInDb,
				nonExistedPlatformCodesInDb, noPlatformCodeMappingWithUniversalCode,
				enableMappingWithDisableUniversalCode, disableUniversalCodes);
		AtomicInteger count = new AtomicInteger();
		List<Map<String, Map<String, Object>>> mappedPlatformData = platformCodeSetSQLDao
				.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet, platformCodeData);
		platformCodeData.stream().forEach(reqObject -> {
			logger.debug(" Processing request for request object ={} ", reqObject);
			Map<String, Object> platformData;
			String key = getKeyForMappedObject(codeSet, reqObject);
			if (!mappedPlatformData.isEmpty()) {
				String availableKeyInDb = "";
				for (Map<String, Map<String, Object>> mapData : mappedPlatformData) {
					platformData = mapData.get(key);
					availableKeyInDb = processRequest(codeSet, errorMap, count, reqObject, platformData, key,
							availableKeyInDb);
				}
				if (!availableKeyInDb.equalsIgnoreCase(key)) {
					logger.debug(" Non existed platform_codes and platform_identifier in request object ={} ",
							reqObject);
					errorMap.get(NO_PLATFORM_CODE).add(reqObject);
				}
			} else {
				errorMap.get(NO_PLATFORM_CODE).add(reqObject);
			}
		});
		ErrorDetails validationErrors = new ErrorDetails();
		buildResponseObject(errorMap, validationErrors);
		String response = validationErrors.getIssues().isEmpty() ? ApiStatus.SUCCESS.name()
				: ApiStatus.PARTIAL_SUCCESS.name();
		if(count.get()==0) {
			response=ApiStatus.ERROR.name();
		}
		logger.info(
				"Processing completed to update all Platform Codes with respect to Universal Codes for the given CodeSet={}",
				codeSet);
		return new ServiceResponse<>(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS") + "= " + count,
				validationErrors, response);
		
	}

	/**
	 * Process request.
	 *
	 * @param codeSet the code set
	 * @param errorMap the error map
	 * @param count the count
	 * @param reqObject the req object
	 * @param platformData the platform data
	 * @param key the key
	 * @param availableKeyInDb the available key in db
	 * @return the string
	 */
	private String processRequest(String codeSet, Map<String, List<Map<String, String>>> errorMap, AtomicInteger count,
			Map<String, String> reqObject, Map<String, Object> platformData, String key, String availableKeyInDb) {
		if (platformData != null) {
			availableKeyInDb = key;
			if (isDeleteMappingRequest(reqObject)) {
				logger.debug(" Processing request for delete mapping,  request object ={} ", reqObject);
				platformCodeSetSQLDao.update(codeSet, reqObject, null);
				count.getAndIncrement();
			} else {
				processUpdateRequest(codeSet, errorMap, count, reqObject, platformData);
			}
		}
		return availableKeyInDb;
	}

	/**
	 * Checks if is delete mapping request.
	 *
	 * @param reqObject the req object
	 * @return true, if is delete mapping request
	 */
	private boolean isDeleteMappingRequest(Map<String, String> reqObject) {
		return reqObject.containsKey(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD)
				&& !reqObject.containsKey(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN)
				&& reqObject.get(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD) == null;
	}

	/**
	 * Initialize error map.
	 *
	 * @param nonExistedUniversalCodesInDb the non existed universal codes in db
	 * @param nonExistedPlatformCodesInDb the non existed platform codes in db
	 * @param noPlatformCodeMappingWithUniversalCode the no platform code mapping with universal code
	 * @param enableMappingWithDisableUniversalCode the enable mapping with disable universal code
	 * @param disableUniversalCodes the disable universal codes
	 * @return the map
	 */
	private Map<String, List<Map<String, String>>> initializeErrorMap(
			List<Map<String, String>> nonExistedUniversalCodesInDb,
			List<Map<String, String>> nonExistedPlatformCodesInDb,
			List<Map<String, String>> noPlatformCodeMappingWithUniversalCode,
			List<Map<String, String>> enableMappingWithDisableUniversalCode,
			List<Map<String, String>> disableUniversalCodes) {
		Map<String, List<Map<String, String>>> errorMap = new HashMap<>();
		errorMap.put(NO_UNIVERSAL_CODE, nonExistedUniversalCodesInDb);
		errorMap.put(NO_PLATFORM_CODE, nonExistedPlatformCodesInDb);
		errorMap.put(NO_MAPPING, noPlatformCodeMappingWithUniversalCode);
		errorMap.put(MAPPING_WITH_DISABLE, enableMappingWithDisableUniversalCode);
		errorMap.put(DISABLE_UNIVERSAL_CODE, disableUniversalCodes);
		return errorMap;
	}

	/**
	 * Process update request.
	 *
	 * @param codeSet the code set
	 * @param errorMap the error map
	 * @param count the count
	 * @param reqObject the req object
	 * @param platformData the platform data
	 */
	private void processUpdateRequest(String codeSet, Map<String, List<Map<String, String>>> errorMap,
			AtomicInteger count, Map<String, String> reqObject, Map<String, Object> platformData) {
		String universalCodeInRequest = reqObject.get(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD);
		if (universalCodeInRequest != null && !universalCodeInRequest.isEmpty()) {
			logger.debug(" Processing request with universal code present in request object  ={} ", reqObject);
			Map<String, Object> universalCodeData = universalCodeSetSQLDao
					.getUniversalCodeRecordsToVerifyStatus(codeSet, reqObject);
			if (universalCodeData != null) {
				validateMappingWithUniversalCode(codeSet, errorMap, count, reqObject, universalCodeData);
			} else {
				logger.debug(" Non existed universal code in database present in request Object ={} ", reqObject);
				errorMap.get(NO_UNIVERSAL_CODE).add(reqObject);
			}

		} else {
			logger.debug(" Processing request no universal code present in request object  ={} ", reqObject);
			validateMappingWithoutUniversalCode(codeSet, errorMap, count, reqObject, platformData);
		}
	}

	/**
	 * Gets the key for mapped object.
	 *
	 * @param codeSet the code set
	 * @param reqObject the req object
	 * @return the key for mapped object
	 */
	private String getKeyForMappedObject(String codeSet, Map<String, String> reqObject) {
		List<String> compositKeysList = codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet);
		StringBuilder key = new StringBuilder();
		for (String item : compositKeysList) {
			key.append(reqObject.get(item));
		}
		return key.toString();
	}

	/**
	 * Validate mapping without universal code.
	 *
	 * @param codeSet the code set
	 * @param errorMap the error map
	 * @param count the count
	 * @param requestObject the request object
	 * @param platformData the platform data
	 */
	private void validateMappingWithoutUniversalCode(String codeSet, Map<String, List<Map<String, String>>> errorMap,
			AtomicInteger count, Map<String, String> requestObject, Map<String, Object> platformData) {
		logger.debug(" Processing request for update mapping, without universal code,  request object ={} ",
				requestObject);
		if (platformData.get(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD_IN_PLATFORM) != null) {
			String mappingStatusInRequest = requestObject.get(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN);
			String universalCodeIdINPlatform = platformData
					.get(TranslationServiceStringConstant.UNIVERSAL_CODE_FIELD_IN_PLATFORM).toString();
			Map<String, Object> universalCodeDataById = universalCodeSetSQLDao.getById(codeSet,
					universalCodeIdINPlatform);
			if (mappingStatusInRequest.equalsIgnoreCase(TranslationServiceStringConstant.ENABLED)) {
				validateEnableMappingWithoutUniversalCode(codeSet, errorMap, count, requestObject,
						universalCodeDataById);
			} else {
				platformCodeSetSQLDao.update(codeSet, requestObject,
						Integer.parseInt(universalCodeDataById.get(TranslationServiceStringConstant.ID).toString()));
				count.getAndIncrement();
			}

		} else {
			logger.debug(" No platform_codes mapping found for universal code in request object ={} ", requestObject);
			errorMap.get(NO_MAPPING).add(requestObject);
		}
	}

	/**
	 * Validate enable mapping without universal code.
	 *
	 * @param codeSet the code set
	 * @param errorMap the error map
	 * @param count the count
	 * @param requestObject the request object
	 * @param universalCodedataById the universal codedata by id
	 */
	private void validateEnableMappingWithoutUniversalCode(String codeSet,
			Map<String, List<Map<String, String>>> errorMap, AtomicInteger count, Map<String, String> requestObject,
			Map<String, Object> universalCodedataById) {
		logger.debug(" Processing request without universal code in request, for enable mapping request object  ={} ", requestObject);
		if (universalCodedataById != null) {
			if (universalCodedataById.get(TranslationServiceStringConstant.STATUS) != null
					&& universalCodedataById.get(TranslationServiceStringConstant.STATUS).toString().trim()
							.equalsIgnoreCase(TranslationServiceStringConstant.ENABLED)) {
				requestObject.put(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN,
						TranslationServiceStringConstant.ENABLED);
				platformCodeSetSQLDao.update(codeSet, requestObject,
						Integer.parseInt(universalCodedataById.get(TranslationServiceStringConstant.ID).toString()));
				count.getAndIncrement();
			} else {
				logger.debug(" Can not perform update operation for disable universal code in DB, request Object ={} ",
						requestObject);
				errorMap.get(DISABLE_UNIVERSAL_CODE).add(requestObject);
			}
		} else {
			logger.debug(" Non existed universal code in database present in request Object ={} ", requestObject);
			errorMap.get(NO_UNIVERSAL_CODE).add(requestObject);
		}
	}

	/**
	 * Validate mapping with universal code.
	 *
	 * @param codeSet the code set
	 * @param errorMap the error map
	 * @param count the count
	 * @param requestObject the request object
	 * @param universalCodeData the universal code data
	 */
	private void validateMappingWithUniversalCode(String codeSet, Map<String, List<Map<String, String>>> errorMap,
			AtomicInteger count, Map<String, String> requestObject, Map<String, Object> universalCodeData) {

		if (universalCodeData.get(TranslationServiceStringConstant.STATUS).toString().trim()
				.equalsIgnoreCase(TranslationServiceStringConstant.DISABLED)) {
			logger.debug(" Start validating if universal code is disabled, present in request Object ={} ",
					requestObject);
			validateWithDisableStatusUniversalCode(codeSet, errorMap, count, requestObject, universalCodeData);
		} else {
			if (requestObject.get(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN) != null
					&& !requestObject.get(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN).isEmpty()) {
				platformCodeSetSQLDao.update(codeSet, requestObject,
						Integer.parseInt(universalCodeData.get(TranslationServiceStringConstant.ID).toString()));
				count.getAndIncrement();
			} else {
				requestObject.put(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN,
						TranslationServiceStringConstant.ENABLED);
				platformCodeSetSQLDao.update(codeSet, requestObject,
						Integer.parseInt(universalCodeData.get(TranslationServiceStringConstant.ID).toString()));
				count.getAndIncrement();
			}
		}
	}

	/**
	 * Validate with disable status universal code.
	 *
	 * @param codeSet the code set
	 * @param errorMap the error map
	 * @param count the count
	 * @param requestObject the request object
	 * @param universalCodeData the universal code data
	 */
	private void validateWithDisableStatusUniversalCode(String codeSet, Map<String, List<Map<String, String>>> errorMap,
			AtomicInteger count, Map<String, String> requestObject, Map<String, Object> universalCodeData) {
		String mappingStatusInRequest = requestObject.get(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN);
		if (mappingStatusInRequest != null && !mappingStatusInRequest.isEmpty()) {
			if (mappingStatusInRequest.equalsIgnoreCase(TranslationServiceStringConstant.DISABLED)) {
				platformCodeSetSQLDao.update(codeSet, requestObject,
						Integer.parseInt(universalCodeData.get(TranslationServiceStringConstant.ID).toString()));
				count.getAndIncrement();
			} else {
				logger.debug(
						" Can not perform update operation for enable mapping with disable universal code, request Object ={} ",
						requestObject);
				errorMap.get(MAPPING_WITH_DISABLE).add(requestObject);
			}
		} else {

			requestObject.put(TranslationServiceStringConstant.MAPPING_STATUS_COLUMN,
					TranslationServiceStringConstant.DISABLED);
			logger.debug(" Update mapping with disabled status, request Object ={} ", requestObject);
			platformCodeSetSQLDao.update(codeSet, requestObject,
					Integer.parseInt(universalCodeData.get(TranslationServiceStringConstant.ID).toString()));
			count.getAndIncrement();
		}
	}

	/**
	 * Builds the response object.
	 *
	 * @param errorMap the error map
	 * @param validationErrors the validation errors
	 */
	private void buildResponseObject(Map<String, List<Map<String, String>>> errorMap, ErrorDetails validationErrors) {
		logger.debug(" Start building response object ={} ", errorMap);
		if (!errorMap.get(NO_UNIVERSAL_CODE).isEmpty()) {
			ValidationUtil.rejectRequestForNoUniversalCode(validationErrors, errorMap.get(NO_UNIVERSAL_CODE));
		}
		if (!errorMap.get(NO_PLATFORM_CODE).isEmpty()) {
			ValidationUtil.rejectRequestForNonExistedPlatformCode(validationErrors, errorMap.get(NO_PLATFORM_CODE));
		}
		if (!errorMap.get(NO_MAPPING).isEmpty()) {
			ValidationUtil.rejectRequestForNoPlatformCodeMappingWithUniversalCode(validationErrors,
					errorMap.get(NO_MAPPING));
		}
		if (!errorMap.get(DISABLE_UNIVERSAL_CODE).isEmpty()) {
			ValidationUtil.rejectRequestForDisabledUniversalCode(validationErrors,
					errorMap.get(DISABLE_UNIVERSAL_CODE));
		}
		if (!errorMap.get(MAPPING_WITH_DISABLE).isEmpty()) {
			ValidationUtil.rejectRequestForEnableMappingWithDisabledUniversalCode(validationErrors,
					errorMap.get(MAPPING_WITH_DISABLE));
		}
		logger.debug(" End building response object ={} ", errorMap);
	}

	/**
	 * Gets the platform codes count by code set and universal code.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @param status        the mapping status
	 * @return the platform codes count by code set and universal code
	 */
	@Override
	public int getPlatformCodesCountByCodeSetAndUniversalCode(String codeSet, String universalCode,
			StatusEnum mappingStatus) {
		logger.info(
				"Finding total Platform Codes count for the given CodeSet={}, UniversalCode={} and MappingStatus={}",
				codeSet, universalCode, mappingStatus);
		int platformCodesCountByCodeSetAndUniversalCode = platformCodeSetSQLDao
				.getPlatformCodesCountByCodeSetAndUniversalCode(codeSet, universalCode, mappingStatus);
		logger.info("Found Count={} Platform Codes for the given CodeSet={}, UniversalCode={} and MappingStatus={}",
				platformCodesCountByCodeSetAndUniversalCode, codeSet, universalCode, mappingStatus);
		return platformCodesCountByCodeSetAndUniversalCode;
	}

	/**
	 * Gets the all platform codes.
	 *
	 * @param codeSet   the code set
	 * @param page      the page
	 * @param count     the count
	 * @param filter    the filter
	 * @param orderBy   the order by
	 * @param direction the direction
	 * @return the all platform codes
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<List<Map<String, String>>> getAllPlatformCodes(String codeSet, Integer page, Integer count,
			PlatformCodesMappingStatus mappingStatus, String orderBy, Direction direction,String platformIdentifier) throws ServiceException {
		logger.info("Processing request to get all Platform Codes for the given CodeSet={}", codeSet);

		List<Map<String, String>> platformCodes = new ArrayList<>();
		try {
			List<Map<String, Object>> repoPlatformCodes = platformCodeSetSQLDao.getAllPlatformCodes(codeSet, page,
					count, mappingStatus, orderBy, direction,platformIdentifier);

			ListIterator<Map<String, Object>> platformCodesIterator = repoPlatformCodes.listIterator();

			while (platformCodesIterator.hasNext()) {
				Map<String, Object> nextPlatformCodeData = platformCodesIterator.next();

				Map<String, String> collectedPlatformCodeData = new HashMap<>();

				nextPlatformCodeData.entrySet().forEach(entry -> collectedPlatformCodeData.put(entry.getKey(),
						(entry.getValue() != null ? entry.getValue().toString() : null)));

				platformCodes.add(collectedPlatformCodeData);
			}
		} catch (DaoException daoException) {

			String message = daoException.getMessage();

			CtsErrorCode errorCode = daoException.getErrorCode();

			logger.error(
					"Data access exception occured while trying to fetch all Platform Codes for the given CodeSet={}, Error={}",
					codeSet, errorCode + ":" + message);

			throw new ServiceException(message, errorCode, null);
		}

		if (platformCodes.isEmpty()) {
			logger.warn("No Platform Codes found in repository for the given CodeSet={}", codeSet);
		} else {
			logger.info("Found PlatformCodesCount={} Platform Code(s) for the given CodeSet={}", platformCodes.size(),
					codeSet);
		}

		return new ServiceResponse<>(
				(platformCodes.isEmpty() ? messageSourceUtil.getMessage("NO_PLATFORM_CODES_IN_DATABASE") : messageSourceUtil.getMessage("PLATFORM_CODES_IN_DATABASE")), platformCodes);
	}

	/**
	 * Gets the platform codes record count.
	 *
	 * @param codeSet       the code set
	 * @param mappingStatus the mapping status
	 * @return the platform codes record count
	 */
	@Override
	public int getPlatformCodesRecordCount(String codeSet, PlatformCodesMappingStatus mappingStatus, String platformIdentifier) {
		logger.info("Finding total Platform Codes count for the given CodeSet={} and MappingStatus={}", codeSet,
				mappingStatus);
		int platformCodesRecordCount = platformCodeSetSQLDao.getPlatformCodesRecordCount(codeSet, mappingStatus,platformIdentifier);
		logger.info("Found Count={} Platform Codes for the given CodeSet={} and MappingStatus={}",
				platformCodesRecordCount, codeSet, mappingStatus);
		return platformCodesRecordCount;
	}

	/**
	 * Gets the by code.
	 *
	 * @param codeSet the code set
	 * @param platformCodes the platform codes
	 * @return the by code
	 * @throws ServiceException the service exception
	 */
	@Override
	public ServiceResponse<Map<String, String>> getByCode(String codeSet, Map<String, String> platformCodes) throws ServiceException {
		logger.info("Processing to get Platform Code Data identified by request={} for the given CodeSet={}",
				platformCodes, codeSet);
		Map<String, Object> platformCodeObject;  
		try {
			platformCodeObject = platformCodeSetSQLDao.getPlatformCodeDataByCode(codeSet, platformCodes);
		} catch (DaoException daoException) {
			logger.error("No Platform Codes found in repository for the given CodeSet={}",codeSet);
			throw new ServiceException(daoException.getMessage(), platformCodes, daoException.getErrorCode());
		}
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeObject.entrySet().stream()
				.filter(entry -> !TranslationServiceStringConstant.ID.equals(entry.getKey()) && !TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN.equals(entry.getKey() ))
				.forEach(entry -> platformCodeData.put(entry.getKey(),
						(entry.getValue() != null ? entry.getValue().toString() : null)));
		logger.info("Found platform code data for the given CodeSet={} and request={}", codeSet, platformCodes);
		return new ServiceResponse<>(messageSourceUtil.getMessage("PLATFORM_CODE_IN_DATABASE"),platformCodeData);
	}

}
