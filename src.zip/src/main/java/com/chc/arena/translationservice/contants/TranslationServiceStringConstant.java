package com.chc.arena.translationservice.contants;

public class TranslationServiceStringConstant {

	private TranslationServiceStringConstant() {
		
	}

	public static final String INSERT = "INSERT ";
	public static final String INTO = "INTO ";
	public static final String VALUES = "VALUES ";
	public static final String UPDATE = "UPDATE ";
	public static final String DELETE = "DELETE ";
	public static final String WHERE = " WHERE ";
	public static final String SELECT = "SELECT ";
	public static final String AND = " AND ";
	public static final String FROM = " FROM ";
	public static final String UNIVERSAL_CODE_FIELD = "universal_code";
	public static final String PLATFORM_IDENTIFIER_COLUMN = "platform_identifier";
	public static final String ENABLED = "ENABLED";
	public static final String SPACE = " ";
	public static final String UNIVERSAL_CODE_FIELD_IN_PLATFORM = "universal_code_id";
	public static final String STATUS = "status";
	public static final String CREATION_DATE = "creation_date";
	public static final String LAST_UPDATED = "last_updated";
	public static final String SET = " SET ";
	public static final String MAPPING_STATUS_COLUMN = "mapping_status";
	public static final String UNIVERSAL_CODE_ID_COLUMN = "universal_code_id";
	public static final String MAPPING_ENABLED_COLUMN = "mapping_enabled";
	public static final String UNIVERSAL_CODE_COLUMN = "universal_code";
	public static final String PLATFORM_MAPPING_STATUS_FIELD = "mapping_status";
	public static final String ORDER_BY = " ORDER BY ";
	public static final String LEFT_JOIN = " LEFT JOIN ";
	public static final String ON = " ON ";
	public static final String ID = "id";
	public static final String OFFSET = " OFFSET ";
	public static final String OR = " OR ";
	public static final String SCORE = "score";
	public static final String COUNT_STAR = " COUNT(*) ";
	public static final String DISABLED = "DISABLED";
	public static final String IS = " IS ";
	public static final String NULL = " NULL ";
	public static final String PLATFORM = "PLATFORM";
	public static final String UNIVERSAL = "UNIVERSAL";
	public static final String ROWS_FETCH_NEXT = " ROWS FETCH NEXT ";
	public static final String ROWS_ONLY=" ROWS ONLY ";
	
	
}
