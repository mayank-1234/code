package com.chc.arena.translationservice.validation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The Interface ValidRequest.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface ValidRequest {
	
	/**
	 * Request type.
	 *
	 * @return the request type
	 */
	public RequestType requestType() default RequestType.ANY_REQUEST;
}
