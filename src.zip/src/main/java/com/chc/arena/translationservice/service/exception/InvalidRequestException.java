/**
 * 
 */
package com.chc.arena.translationservice.service.exception;

/**
 * The Class InvalidRequestException.
 *
 */
public class InvalidRequestException extends IllegalArgumentException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4760987649778712673L;

	/** The code. */
	private final CtsErrorCode errorCode;
	
	/** The validation errors. */
	private final ErrorDetails errorDetails;		
	
	/**
	 * Instantiates a new invalid request exception.
	 *
	 * @param message the message
	 * @param errorCode the error code
	 * @param errorDetails the error details
	 */
	public InvalidRequestException(String message, CtsErrorCode errorCode, ErrorDetails errorDetails) {
		super(message);
		this.errorCode = errorCode;
		this.errorDetails = errorDetails;
	}
	
	/**
	 * Gets the error code.
	 *
	 * @return the errorCode
	 */
	public CtsErrorCode getErrorCode() {
		return errorCode;
	}
	/**
	 * Gets the error details.
	 *
	 * @return the errorDetails
	 */
	public ErrorDetails getErrorDetails() {
		return errorDetails;
	}
}
