package com.chc.arena.translationservice.util;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class CommonUtil.
 */
public class CommonUtil {
	
	private static final Logger logger=LoggerFactory.getLogger(CommonUtil.class);
	
	private static final String SOLR_DATE_FORMAT="EEE MMM dd HH:mm:ss zzz yyyy";
	private static final String SIMPLE_DATE_FORMAT="yyyy-MM-dd HH:mm:ss";
	
	/**
	 * Instantiate CommonUtil
	 */
	private CommonUtil() {
		throw new IllegalStateException("Utility class");
	}

	/**
	 * Gets the decoded universal code.
	 *
	 * @param encodedUniversalCode the encoded universal code
	 * @return the decoded universal code
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 */
	public static String getDecodedUniversalCode(String encodedUniversalCode) throws UnsupportedEncodingException {
		return new String(Base64.getUrlDecoder().decode(encodedUniversalCode), "utf-8");
	}
	
	public static String covertSolrDateToSimpleDateFormat(String inputDate) {
		logger.error("Start converting solr date to simple date format, Date : {}", inputDate);
		try {
			DateFormat inputFormat = new SimpleDateFormat(SOLR_DATE_FORMAT, Locale.ENGLISH);
			Date date = inputFormat.parse(inputDate);
			DateFormat outputFormat = new SimpleDateFormat(SIMPLE_DATE_FORMAT, Locale.ENGLISH);
			return outputFormat.format(date);
		} catch (ParseException exception) {
			logger.error("Exception occured while converting solr date to simple date format, Exception Message : {} ",
					exception.getMessage());
		}
		return inputDate;
	}
}
