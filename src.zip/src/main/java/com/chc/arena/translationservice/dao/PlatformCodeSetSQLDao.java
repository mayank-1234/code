package com.chc.arena.translationservice.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;

/**
 * The Interface PlatformCodeSetSQLDao.
 */
public interface PlatformCodeSetSQLDao {

	/**
	 * Gets the platform codes by universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param from the from
	 * @param count the count
	 * @param mappingStatus the mapping status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the platform codes by universal code
	 * @throws DaoException the dao exception
	 */
	public List<Map<String, Object>> getPlatformCodesByUniversalCode(String codeSet, String universalCode, Integer page,
			Integer count, StatusEnum mappingStatus, String orderBy, Direction direction) throws DaoException;

	/**
	 * Insert.
	 *
	 * @param codeSet the code set
	 * @param codeObjects the code objects
	 */
	public void insert(String codeSet, Map<String, String> codeObjects) throws DaoException;

	/**
	 * Update.
	 *
	 * @param codeSet the code set
	 * @param codeObjects the code objects
	 */
	public void update(String codeSet, Map<String, String> codeObjects,Integer universalCodeId);

	
	/**
	 * Disable/Enable all platform codes associated with universal code
	 * @param codeSet
	 * @param status
	 * @param universalCodeId
	 * @param updatedTime
	 * @return
	 */
	public int disableEnablePlatformCodesMappedToUniversalCode(String codeSet, String status, int universalCodeId, Date updatedTime);

	/**
	 * Gets the platform codes count by code set and universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param mappingStatus the mapping status
	 * @return the platform codes count by code set and universal code
	 */
	public int getPlatformCodesCountByCodeSetAndUniversalCode(String codeSet, String universalCode, StatusEnum mappingStatus);

	/**
	 * Get all platform codes for the given CodeSet.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count the count
	 * @param mappingStatus the mapping status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the all platform codes
	 */
	public List<Map<String, Object>> getAllPlatformCodes(String codeSet, Integer page, Integer count, PlatformCodesMappingStatus mappingStatus,
			String orderBy, Direction direction,String platformIdentifier) throws DaoException;

	/**
	 * Gets the platform codes record count.
	 *
	 * @param codeSet the code set
	 * @param mappingStatus the mapping status
	 * @return the platform codes record count
	 */
	public int getPlatformCodesRecordCount(String codeSet, PlatformCodesMappingStatus mappingStatus, String platformIdentifier);
	
	/**
	 * Update platform code universal code maaping to null & status as disabled.
	 *
	 * @param codeSet the code set
	 * @param universalCodeId the universal code id
	 * @return the int
	 */
	public int removePlatformCodeMappingForUniversalCodeId(String codeSet,Integer universalCodeId, Date updatedTime);

	/**
	 * Gets the plat from code dat with universal code data set.
	 *
	 * @param codeSet the code set
	 * @param mappingList the mapping list
	 * @return the plat from code dat with universal code data set
	 */
	public List<Map<String, Map<String, Object>>> getPlatFormCodeDataWithUniversalCodeDataSet(String codeSet,List<Map<String, String>> mappingList);

	/**
	 * Gets the platform code data by code.
	 *
	 * @param codeSet the code set
	 * @param platformCodes the platform codes
	 * @return the platform code data by code
	 * @throws DaoException the dao exception
	 */
	public Map<String, Object> getPlatformCodeDataByCode(String codeSet, Map<String, String> platformCodes) throws DaoException;

}
