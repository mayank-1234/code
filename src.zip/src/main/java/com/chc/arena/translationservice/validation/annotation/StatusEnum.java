package com.chc.arena.translationservice.validation.annotation;

/**
 * The Enum FilterType.
 */
public enum StatusEnum {
	
	/** The enabled. */
	ENABLED("ENABLED"),
	
	/** The disabled. */
	DISABLED("DISABLED");
	
	/** The status. */
	private String status;
	
	/**
	 * Instantiates a new filter type.
	 *
	 * @param status the status
	 */
	private StatusEnum(String status) {
		this.status = status;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
}
