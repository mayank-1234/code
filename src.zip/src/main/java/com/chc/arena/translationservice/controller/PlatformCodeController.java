package com.chc.arena.translationservice.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ApiError;
import com.chc.arena.translationservice.response.model.ApiResponse;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.response.model.SubError;
import com.chc.arena.translationservice.service.PlatformCodeService;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;
import com.chc.arena.translationservice.validation.annotation.RequestType;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.annotation.ValidRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@CrossOrigin(origins = { "*" }, maxAge = 4800, allowCredentials = "false", exposedHeaders = {"hasPreviousPage", "hasNextPage", "currentPage", "totalPages", "totalRecordsCount", "currentPageRecordsCount", "requestedRecordsCount"})
@RequestMapping("/code-sets/{code-set}")
@Api(value = "Platform Codes Service", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, tags = {"Operations pertaining to management of Platform Codes."})
public class PlatformCodeController {
	
	private static final Logger logger=LoggerFactory.getLogger(PlatformCodeController.class);
	
	@Autowired
	private PlatformCodeService platformCodeService;

	@GetMapping(value="/universal-codes/{universal-code}/platform-codes", produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.GET_PLATFORM_CODES_BY_UNIVERSAL_CODE)
	@ApiOperation(value = "${platform-code.api.apioperation.getPlatformCodesByUniversalCode.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${platform-code.api.apioperation.getPlatformCodesByUniversalCode.notes}")
	public ResponseEntity<ApiResponse> getPlatformCodesByUniversalCode(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${universal-code}", required = true) @PathVariable("universal-code") String universalCode, @ApiParam(value = "${record-from}", required = false) @RequestParam(value = "page", required = false) Integer page,
			@ApiParam(value = "${record-count}", required = false) @RequestParam(value = "count", required = false) Integer count, @ApiParam(value = "${status-type}", required = false) @RequestParam(value = "mappingStatus", required = false) StatusEnum mappingStatus, 
			@ApiParam(value = "${orderBy-universal}", required = false) @RequestParam(value = "orderBy", required = false) String orderBy, @ApiParam(value = "${direction-universal}", required = false) @RequestParam(value = "direction", required = false) Direction direction) throws ServiceException {
		
		logger.info("Handling incoming request to get all Platform Codes for the given CodeSet={} and UniversalCode={}, query parameters and values passed are Page={}, Count={}, MappingStatus={}, OrderBy={} and Direction={}", codeSet, universalCode, page, count, mappingStatus, orderBy, direction);
		
		int currentPageRecordsCount = 0;
		
		HttpHeaders responseHeaders = setResponseHeaders(codeSet, universalCode, page, count, mappingStatus, null,null);
		
		ServiceResponse<List<Map<String, String>>> platformCodesByUniversalCodeServiceResponse = platformCodeService.getPlatformCodesByUniversalCode(codeSet, universalCode, page, count, mappingStatus, orderBy, direction);
		currentPageRecordsCount = platformCodesByUniversalCodeServiceResponse.getBody().size();
		responseHeaders.set("currentPageRecordsCount", String.valueOf(currentPageRecordsCount));
		logger.info("Returning Count={} Platform Codes for the given CodeSet={} and UniversalCode={}", currentPageRecordsCount, codeSet, universalCode);
		
		return ResponseEntity.ok().headers(responseHeaders).body(new ApiResponse(ApiStatus.SUCCESS, platformCodesByUniversalCodeServiceResponse.getBody(), platformCodesByUniversalCodeServiceResponse.getMessage()));
	}

	@PostMapping(value ="/platform-codes", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.CREATE_PLATFORM_CODES)
	@ApiOperation(value = "${platform-code.api.apioperation.insert.value}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${platform-code.api.apioperation.insert.notes}")
	public ResponseEntity<ApiResponse> insert(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet, @ApiParam(value = "${platform-code-data}", required = true) @RequestBody List<Map<String, String>> platformCodes) throws ServiceException {
		
		logger.info("Handling incoming request to insert PlatformCodesCount={} Platform Codes for the given CodeSet={}", platformCodes.size(), codeSet);

		ServiceResponse<String> serviceResponse=platformCodeService.insert(codeSet, platformCodes);
		
		ErrorDetails errorDetails = serviceResponse.getErrorDetails();
		
		ApiResponse apiResponse = new ApiResponse(ApiStatus.getApiStatusByStatus(serviceResponse.getBody()), null, serviceResponse.getMessage());
		
		if(errorDetails.getIssues().size() > 0) {
			ApiError apiError = new ApiError();
			List<SubError> subErrors = errorDetails.getIssues().entrySet().stream()
							.map(entry -> new SubError(entry.getValue(), entry.getKey())).collect(Collectors.toList());
			apiError.setSubErrors(subErrors);
			apiError.setErrorCode(CtsErrorCode.BAD_REQUEST);
			apiError.setMessage(serviceResponse.getMessage());
			apiResponse.setApiError(apiError);
		}
		logger.info("Successfully inserted one or more Platform Codes for the given CodeSet={}", codeSet);
		return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
	}

	@PatchMapping(value = "/platform-codes", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.UPDATE_PLATFORM_CODES)
	@ApiOperation(value = "${platform-code.api.apioperation.update.value}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${platform-code.api.apioperation.update.notes}")
	public ResponseEntity<ApiResponse> update(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet, @ApiParam(value = "${update-platform-data}", required = true) @RequestBody List<Map<String, String>> platformCodes) throws ServiceException {
		
		logger.info(" Handling incoming request to update mapping for the given CodeSet={} and Mapped Object count in request={} ",codeSet,platformCodes.size());
		
		ServiceResponse<String> response =platformCodeService.update(codeSet, platformCodes);
		ErrorDetails errorDetails = response.getErrorDetails();
		ApiResponse apiResponse = new ApiResponse(ApiStatus.getApiStatusByStatus(response.getBody()), null, response.getMessage());
		if(errorDetails.getIssues().size() > 0) {
			ApiError apiError = new ApiError();
			List<SubError> subErrors = errorDetails.getIssues().entrySet().stream()
							.map(entry -> new SubError(entry.getValue(), entry.getKey())).collect(Collectors.toList());
			apiError.setSubErrors(subErrors);
			apiError.setErrorCode(CtsErrorCode.BAD_REQUEST);
			apiResponse.setApiError(apiError);
			logger.error(" Handling service validations in API errors ={}",apiError);
		}
		
		logger.info(" Returning reponse for updated mapping with validated mapped objects {} ",apiResponse);  
		return ResponseEntity.ok(apiResponse);
	}
	
	@GetMapping(value = "/platform-codes", produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType=RequestType.GET_ALL_PLATFORM_CODES)
	@ApiOperation(value = "${platform-code.api.apioperation.getAll.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${platform-code.api.apioperation.getAll.notes}")
	public ResponseEntity<ApiResponse> getAllPlatformCodes(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet, @ApiParam(value = "${record-from}", required = false) @RequestParam(value = "page", required = false) Integer page, 
			@ApiParam(value = "${record-count}", required = false) @RequestParam(value = "count", required = false) Integer count, @ApiParam(value = "${mapping-status}", required = false) @RequestParam(value = "mappingStatus", required = false) PlatformCodesMappingStatus mappingStatus, 
			@ApiParam(value = "${orderBy-universal}", required = false) @RequestParam(value = "orderBy", required = false) String orderBy, @ApiParam(value = "${direction-universal}", required = false) @RequestParam(value = "direction", required = false) Direction direction,
			@ApiParam(value = "${platform-identifier}", required = false) @RequestParam(value = "platformIdentifier", required = false) String platformIdentifier) throws ServiceException {
		
		logger.info("Handling incoming request to get all Platform Codes for the given CodeSet={}, query parameters and values passed are Page={}, Count={}, Filter={}, OrderBy{} and Direction={}", codeSet, page, count, mappingStatus, orderBy, direction);
		
		int currentPageRecordsCount = 0;
		
		HttpHeaders responseHeaders = setResponseHeaders(codeSet, null, page, count, null, mappingStatus,platformIdentifier);
				
		ServiceResponse<List<Map<String,String>>> platformCodes = platformCodeService.getAllPlatformCodes(codeSet, page, count, mappingStatus, orderBy, direction,platformIdentifier);
		 
		currentPageRecordsCount = platformCodes.getBody().size();
		
		logger.info("Returning Count={} Platform Codes for the given CodeSet={}", platformCodes.getBody().size(), codeSet);
				
	    responseHeaders.set("currentPageRecordsCount", String.valueOf(currentPageRecordsCount));
	    
	    logger.info("Setting Response headers with details ResponseHeaders={}", responseHeaders);
		
		return ResponseEntity.ok().headers(responseHeaders).body(new ApiResponse(ApiStatus.SUCCESS, platformCodes.getBody(), platformCodes.getMessage()));

	}  
	
	
	@PostMapping(value = "/platform-codes/fetch", produces = MediaType.APPLICATION_JSON_VALUE)
	@ValidRequest(requestType = RequestType.GET_PLATFORM_CODE)
	@ApiOperation(value = "${platform-code.api.apioperation.getByCode.value}", produces = MediaType.APPLICATION_JSON_VALUE, response = ApiResponse.class, notes = "${platform-code.api.apioperation.getByCode.notes}")
	public ResponseEntity<ApiResponse> getByCode(@ApiParam(value = "${code-set-name}", required = true) @PathVariable("code-set") String codeSet,
			@ApiParam(value = "${platform-code-data}", required = true) @RequestBody Map<String, String> platformCodes)throws ServiceException {
		logger.info("Handling incloming request to get platform Code data identified by request={} for the given CodeSet={}", platformCodes, codeSet);
		ServiceResponse<Map<String, String>> platformCodeDataServiceResponse = platformCodeService.getByCode(codeSet, platformCodes);
		logger.info("Returning platform Code data identified by request={} for the given CodeSet={}", platformCodes, codeSet);
		return ResponseEntity.ok(new ApiResponse(ApiStatus.SUCCESS, platformCodeDataServiceResponse.getBody(), platformCodeDataServiceResponse.getMessage()));
	}
	
	/**
	 * Sets the response headers.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param page the page
	 * @param count the count
	 * @param status the status
	 * @param mappingStatus the mapping status
	 * @return the http headers
	 */
	private HttpHeaders setResponseHeaders(String codeSet, String universalCode, Integer page, Integer count, StatusEnum status, PlatformCodesMappingStatus mappingStatus,String platformIdentifier) {
		HttpHeaders responseHeaders = new HttpHeaders();
		if(page != null && count != null) {
			int totalPages = 0;
			int totalRecordsCount = 0;
			if(universalCode != null)
				totalRecordsCount = platformCodeService.getPlatformCodesCountByCodeSetAndUniversalCode(codeSet, universalCode, status);
			else
				totalRecordsCount = platformCodeService.getPlatformCodesRecordCount(codeSet, mappingStatus,platformIdentifier);
			if(totalRecordsCount > 0) {
				double calculatedPages = ((double)totalRecordsCount/(double)count);
				totalPages = (int) Math.ceil(calculatedPages);
			}
			boolean hasNextPage = totalPages > page;
			boolean hasPreviousPage = page > 1;
			
			responseHeaders.set("hasPreviousPage", String.valueOf(hasPreviousPage));
		    responseHeaders.set("hasNextPage", String.valueOf(hasNextPage));
		    responseHeaders.set("currentPage", String.valueOf(page));
		    responseHeaders.set("totalPages", String.valueOf(totalPages));
		    responseHeaders.set("totalRecordsCount", String.valueOf(totalRecordsCount));
		    responseHeaders.set("requestedRecordsCount", String.valueOf(count));
		}
		
		return responseHeaders;
	} 
}
