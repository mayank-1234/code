/**
 * 
 */
package com.chc.arena.translationservice.service.exception;

import java.util.Map;

/**
 * The Class ServiceException.
 *
 * @author narendra.dubey
 */
public class ServiceException extends Exception {

	/** The error code. */
	private final CtsErrorCode errorCode;

	/** The error details. */
	private final ErrorDetails errorDetails;

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new service exception.
	 *
	 * @param message      the message
	 * @param errorCode    the error code
	 * @param errorDetails the error details
	 */
	public ServiceException(String message, CtsErrorCode errorCode, ErrorDetails errorDetails) {
		super(message);
		this.errorCode = errorCode;
		this.errorDetails = errorDetails;
	}

	/**
	 * Instantiates a new service exception.
	 *
	 * @param message      the message
	 * @param err          the err
	 * @param errorCode    the error code
	 * @param errorDetails the error details
	 */
	public ServiceException(String message, Throwable err, CtsErrorCode errorCode, ErrorDetails errorDetails) {
		super(message, err);
		this.errorCode = errorCode;
		this.errorDetails = errorDetails;
	}
	
	public ServiceException(String message, Map<String, String> rejectedValue, CtsErrorCode errorCode) {
		super(message);
		this.errorCode = errorCode;
		this.errorDetails = new ErrorDetails();
		this.errorDetails.getIssues().put(message, rejectedValue);
	}
	
	/**
	 * Gets the error code.
	 *
	 * @return the errorCode
	 */
	public CtsErrorCode getErrorCode() {
		return errorCode;
	}

	/**
	 * Gets the error details.
	 *
	 * @return the errorDetails
	 */
	public ErrorDetails getErrorDetails() {
		return errorDetails;
	}
}
