package com.chc.arena.translationservice;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import microsoft.servicefabric.services.communication.runtime.ServiceInstanceListener;
import microsoft.servicefabric.services.runtime.StatelessService;
import system.fabric.CancellationToken;

/**
 * The Class CodeTranslationService.
 */
public class CodeTranslationService extends StatelessService {

	private static final Logger logger=LoggerFactory.getLogger(CodeTranslationService.class);
	
    /**
     * Creates the service instance listeners.
     *
     * @return the list
     */
    @Override
    protected List<ServiceInstanceListener> createServiceInstanceListeners() {
    	logger.info("Creating Service Listener");
        return super.createServiceInstanceListeners();
    }

    /**
     * Run async.
     *
     * @param cancellationToken the cancellation token
     * @return the completable future
     */
    @Override
    protected CompletableFuture<?> runAsync(CancellationToken cancellationToken) {
    	logger.info("Run Async");
        return super.runAsync(cancellationToken);
    }
}
