package com.chc.arena.translationservice.dao.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.request.SolrPing;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.client.solrj.response.SolrPingResponse;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.dao.CodeSetSolrDao;
import com.chc.arena.translationservice.querybuilder.SolrQueryBuilder;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.CommonUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;

/**
 * The Class CodeSetSolrDaoImpl.
 */
@Repository
public class CodeSetSolrDaoImpl implements CodeSetSolrDao {
	
	private static final Logger logger=LoggerFactory.getLogger(CodeSetSolrDaoImpl.class);

	@Autowired
	private SolrClient solrClient;

	@Autowired
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Autowired
	private SolrQueryBuilder solrQueryBuilder;

	@Autowired
	private MessageSourceUtil messageSourceUtil;
	
	/** The Constant SOLR_STATUS_PARAM. */
	private static final String SOLR_STATUS_PARAM = "distrib";

	/** The Constant SOLR_STATUS_FLAG. */
	private static final String SOLR_STATUS_FLAG = "true";

	/** The Constant SOLR_COMMIT_INTERVAL. */
	private static final int SOLR_COMMIT_INTERVAL = 1;
	
	private static final String ERROR_IN_SEARCH_SERVICE="ERROR_IN_SEARCH_SERVICE";
	
	private static final String COMMUNICATION_ERROR_WITH_SEARCH_SERVICE="COMMUNICATION_ERROR_WITH_SEARCH_SERVICE";
	

	@Override
	public List<Map<String, String>> search(String codeSet, Map<String, String> platformObject, Integer from, Integer count) throws DaoException {
		logger.info("Fetching Universal Code for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}", codeSet, platformObject, from, count);
		String collectionName = codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet);
		SolrQuery query = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, from, count);
		logger.debug("Fetching Universal Code for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, has build Query={}", codeSet, platformObject, from, count, query);
		QueryResponse response = null;
		
		try {
	        response = solrClient.query(collectionName, query);
		} catch(SolrServerException solrServerException) {
			logger.error("Fetching Universal Code for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, has encountered SolrServerException={}", codeSet, platformObject, from, count, solrServerException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage(ERROR_IN_SEARCH_SERVICE), CtsErrorCode.INTERNAL_SERVER_ERROR);
		} catch(IOException ioException) {
			logger.error("Fetching Universal Code for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, has encountered IOException={}", codeSet, platformObject, from, count, ioException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage(COMMUNICATION_ERROR_WITH_SEARCH_SERVICE), CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
		SolrDocumentList results = response.getResults();
		List<Map<String, String>> responseList = new ArrayList<>();
		
		for (SolrDocument solrDocument : results) {
			Map<String, String> convertedMap = new HashMap<>();
			solrDocument.getFieldNames().stream().forEach(field -> {
				if (field.equalsIgnoreCase(TranslationServiceStringConstant.CREATION_DATE)
						|| field.equalsIgnoreCase(TranslationServiceStringConstant.LAST_UPDATED)) {
					convertedMap.put(field,
							CommonUtil.covertSolrDateToSimpleDateFormat(solrDocument.get(field).toString()));
				} else {
					convertedMap.put(field, solrDocument.get(field).toString());
				}
			});
			responseList.add(convertedMap);
		}
		if(responseList.isEmpty()) {
			logger.info("Fetching Universal Code for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, has found No Matching Universal Codes", codeSet, platformObject, from, count);
		} else {
			logger.info("Fetching Universal Code for the given CodeSet={}, Platfrom Code Data={}, From={} & Count={}, has found={} Universal Code(s)", codeSet, platformObject, from, count, responseList.size());
		}
		return responseList;
	}

	

	/**
	 * Insert or update code sets document.
	 *
	 * @param codeSet    the code set
	 * @param codeObject the code object
	 * @return the update response
	 * @throws DaoException if there is an error solr server or error while communicating with Solr
	 */
	@Override
	public UpdateResponse update(String codeSet, Map<String, Object> codeObject, Date updatedTime) throws DaoException {
		logger.info("Updating Solr Document for Universal Code of the given CodeSet={}, Universal Code Data={}, Time={}", codeSet, codeObject, updatedTime);
		try {
			String collection = codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet);
			codeObject.put(TranslationServiceStringConstant.LAST_UPDATED, updatedTime);
			UpdateResponse updateResponse = solrClient.add(collection, getSolrDocument(codeObject), SOLR_COMMIT_INTERVAL);
			logger.info("Updating Solr Document for Universal Code of the given CodeSet={}, Universal Code Data={}, Time={}, successfully updated Solr Document", codeSet, codeObject, updatedTime);
			return updateResponse;
		} catch(SolrServerException solrServerException) {
			logger.error("Updating Solr Document for Universal Code of the given CodeSet={}, Universal Code Data={}, Time={}, SolrServerException occured:{}", codeSet, codeObject, updatedTime, solrServerException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage(ERROR_IN_SEARCH_SERVICE), CtsErrorCode.INTERNAL_SERVER_ERROR);
		} catch(IOException ioException) {
			logger.error("Updating Solr Document for Universal Code of the given CodeSet={}, Universal Code Data={}, Time={}, IOException occured:{}", codeSet, codeObject, updatedTime, ioException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage(COMMUNICATION_ERROR_WITH_SEARCH_SERVICE), CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@Override
	public UpdateResponse insert(String codeSet, Map<String, Object> universalCodeData) throws DaoException {
		logger.info("insert [START]: CodeSet: {}, Universal Code Data: {} ", codeSet, universalCodeData);
		try {
			String collection = codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet);
			return solrClient.add(collection, getSolrDocument(universalCodeData), SOLR_COMMIT_INTERVAL);
		} catch (SolrServerException solrServerException) {
			logger.error(
					"Exception occured in solr indexing : CodeSet: {}, Universal Code data: {}, Exception Message : {} ",
					codeSet, universalCodeData, solrServerException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage(ERROR_IN_SEARCH_SERVICE),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		} catch (IOException ioException) {
			logger.error(
					"Exception occured in solr indexing : CodeSet: {}, Universal Code data: {}, Exception Message : {} ",
					codeSet, universalCodeData, ioException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage(COMMUNICATION_ERROR_WITH_SEARCH_SERVICE),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Delete code sets document.
	 *
	 * @param codeSet    the code set
	 * @param universalCode unique identifier of the object
	 * @throws IOException
	 * @throws SolrServerException
	 */
	@Override
	public UpdateResponse deleteCodeSetsDocumentByUniversalCode(String codeSet, String universalCode)
			throws DaoException {
		logger.info("Processing delete document operation in Solr Server for the UniversalCode={} in CodeSet={}", universalCode, codeSet);
		String collection = codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet);
		try {
			return solrClient.deleteById(collection, universalCode, SOLR_COMMIT_INTERVAL);
		} catch(SolrServerException solrServerException) {
			logger.error(
					"Exception occured in solr server while trying to delete UniversalCode={} for the given CodeSet={}, Error={} ",
					universalCode, codeSet, solrServerException.getMessage());
			throw new DaoException(messageSourceUtil.getMessage("SOLR_DELETED_FAILED"), CtsErrorCode.INTERNAL_SERVER_ERROR);
		} catch(IOException ioException) {
			throw new DaoException(messageSourceUtil.getMessage(COMMUNICATION_ERROR_WITH_SEARCH_SERVICE),
					CtsErrorCode.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Check solr health status.
	 *
	 * @param codeSet the code set
	 * @return the string
	 * @throws SolrServerException the solr server exception
	 * @throws IOException         Signals that an I/O exception has occurred.
	 */
	@Override
	public String checkSolrHealthStatus(String codeSet) throws SolrServerException, IOException {
		SolrPing ping = new SolrPing();
		// To make it a distributed request against a collection
		new SolrPing().getParams().add(SOLR_STATUS_PARAM, SOLR_STATUS_FLAG);
		SolrPingResponse response = ping.process(solrClient, codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet));
		return response.toString();
	}

	/**
	 * Gets the solr document.
	 *
	 * @param codeObject the code object
	 * @return the solr document
	 */
	private SolrInputDocument getSolrDocument(Map<String, Object> codeObject) {
		SolrInputDocument doc = new SolrInputDocument();
		codeObject.entrySet().stream().filter(entry -> !entry.getKey().equalsIgnoreCase("id")).forEach(entry -> doc.addField(entry.getKey(), entry.getValue()));
		return doc;
	}
}
