/**
 * 
 */
package com.chc.arena.translationservice.service;

import java.util.List;
import java.util.Map;

import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;

/**
 * The Interface PlatformCodeService.
 *
 * @author narendra.dubey
 */
public interface PlatformCodeService {

	/**
	 * Gets the platform codes by universal code.
	 *
	 * @param codeSet       the code set
	 * @param universalCode the universal code
	 * @param from          the from
	 * @param count         the count
	 * @param mappingStatus the mapping status
	 * @param orderBy       the order by
	 * @param direction     the direction
	 * @return the platform codes by universal code
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<List<Map<String, String>>> getPlatformCodesByUniversalCode(String codeSet, String universalCode, Integer page, Integer count,
			StatusEnum mappingStatus, String orderBy, Direction direction) throws ServiceException;
	
	/**
	 * Insert one or more platform codes in repository and optionally map them to existing universal code.
	 *
	 * @param codeSet the code set
	 * @param platformCodes with one or more platform code data
	 * @return the service response
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<String> insert(String codeSet, List<Map<String, String>> platformCodes) throws ServiceException;
	
	/**
	 * Update given platform codes mapping(s) or enable/disable the platform code(s).
	 *
	 * @param codeSet the code set
	 * @param platformCodes the platform codes
	 * @return true, if successful
	 * @throws ServiceException the service exception
	 */
	 ServiceResponse<String> update(String codeSet, List<Map<String, String>> platformCodes) throws ServiceException;
	
	/**
	 * Gets the platform codes count by code set and universal code.
	 *
	 * @param codeSet the code set
	 * @param universalCode the universal code
	 * @param status the mapping status
	 * @return the platform codes count by code set and universal code
	 */
	int getPlatformCodesCountByCodeSetAndUniversalCode(String codeSet, String universalCode, StatusEnum mappingStatus);
	
	/**
	 * Gets the all platform codes.
	 *
	 * @param codeSet the code set
	 * @param page the page
	 * @param count the count
	 * @param mappingStatus the mapping status
	 * @param orderBy the order by
	 * @param direction the direction
	 * @return the all platform codes
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<List<Map<String,String>>> getAllPlatformCodes(String codeSet, Integer page,
			Integer count, PlatformCodesMappingStatus mappingStatus, String orderBy, Direction direction,String platformIdentifier) throws ServiceException;

	
	/**
	 * Gets the platform codes record count.
	 *
	 * @param codeSet the code set
	 * @param mappingStatus the mapping status
	 * @return the platform codes record count
	 */
	int getPlatformCodesRecordCount(String codeSet, PlatformCodesMappingStatus mappingStatus, String platformIdentifier);

	/**
	 * Gets the by code.
	 *
	 * @param codeSet the code set
	 * @param platformCodes the platform codes
	 * @return the by code
	 * @throws ServiceException the service exception
	 */
	ServiceResponse<Map<String, String>> getByCode(String codeSet, Map<String, String> platformCodes) throws ServiceException;

}
