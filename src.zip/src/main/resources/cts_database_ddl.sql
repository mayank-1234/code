CREATE SCHEMA IF NOT EXISTS `cts_database` DEFAULT CHARACTER SET utf8 DEFAULT ENCRYPTION='N';
CREATE USER IF NOT EXISTS 'ctsuser'@'localhost' IDENTIFIED BY 'ctspassword';
GRANT ALL PRIVILEGES ON cts_database.* TO 'ctsuser'@'localhost';

CREATE TABLE `cts_database`.`insurance_universal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `universal_code` varchar(45) NOT NULL,
  `insurance_name` varchar(100) NOT NULL,
  `insurance_type` varchar(100) NOT NULL,
  `address_line1` varchar(200) DEFAULT NULL,
  `address_line2` varchar(200) DEFAULT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `creation_date` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'ENABLED',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `universal-code_UNIQUE` (`universal_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `cts_database`.`comment_universal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `universal_code` varchar(45) NOT NULL,
  `description` varchar(200) NOT NULL,
  `creation_date` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'ENABLED',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `universal_code_UNIQUE` (`universal_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	
CREATE TABLE `cts_database`.`comment_platform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform_code` varchar(45) NOT NULL,
  `platform_identifier` varchar(10) NOT NULL,
  `creation_date` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  `universal_code_id` int(11) DEFAULT NULL,
  `mapping_status` varchar(10)  DEFAULT NULL
  PRIMARY KEY (`platform_code`,`platform_identifier`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `universal_code_id_idx` (`universal_code_id`),
  CONSTRAINT `universal_code_id` FOREIGN KEY (`universal_code_id`) REFERENCES `comment_universal` (`id`) 
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
