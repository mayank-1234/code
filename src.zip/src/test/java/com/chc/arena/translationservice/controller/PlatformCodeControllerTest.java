/**
 * 
 */
package com.chc.arena.translationservice.controller;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mockitoSession;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ApiError;
import com.chc.arena.translationservice.response.model.ApiResponse;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.response.model.SubError;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.service.impl.PlatformCodeServiceImpl;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;

/**
 * The Class PlatformCodeControllerTest.
 *
 * @author narendra.dubey
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class PlatformCodeControllerTest {
	
	@LocalServerPort
    int randomServerPort;
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	@MockBean
	private PlatformCodeServiceImpl platformCodeServiceImpl;

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.PlatformCodeController#getPlatformCodesByUniversalCode(java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer, com.chc.arena.translationservice.validation.annotation.StatusEnum)}.
	 * @throws ServiceException 
	 */
	@Test
	public void testGetPlatformCodesByUniversalCode_Sucess_NoFilter() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		urlVariables.put("universal-code", "PIL*RY4*HJ");  
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}/platform-codes";
		
		List<Map<String, String>> expectedBody = new ArrayList<>();
		Map<String, String> platformCodeData1 = new HashMap<>();
		platformCodeData1.put("universal_code", "PIL*RY4*HJ");
		platformCodeData1.put("platform_code", "ABC*123S*HJ");
		platformCodeData1.put("platform_identifier", "MDIV");
		platformCodeData1.put("last_updated", null);
		platformCodeData1.put("creation_date", "2020-02-21 09:00:00.0");
		platformCodeData1.put("mapping_status", "ENABLED");
		expectedBody.add(platformCodeData1);
		Map<String, String> platformCodeData12 = new HashMap<>();
		platformCodeData12.put("universal_code", "PIL*RY4*HJ");
		platformCodeData12.put("platform_code", "PQR*123S*HJ");
		platformCodeData12.put("platform_identifier", "GFS");
		platformCodeData12.put("last_updated", null);
		platformCodeData12.put("creation_date", "2020-01-21 11:00:00.0");
		platformCodeData12.put("mapping_status", "DISABLED");
		expectedBody.add(platformCodeData12);
		String message="Returning mapped Platform Codes for the given Universal Code.";
		ServiceResponse<List<Map<String, String>>> serviceResponse = new ServiceResponse<List<Map<String,String>>>(message, expectedBody );
		
		String codeSet = urlVariables.get("code-set");
		String universalCode = urlVariables.get("universal-code");
		Integer page = null;
		Integer count = null;
		StatusEnum filter = null;
		String orderBy = null;
		Direction direction = null;
		Mockito.when(platformCodeServiceImpl.getPlatformCodesByUniversalCode(codeSet, universalCode, page, count, filter, orderBy, direction)).thenReturn(serviceResponse);
		
		ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());	    
		@SuppressWarnings("unchecked")
		List<Map<String, String>> body = (List<Map<String, String>>)serviceResult.getBody().getBody();
		Assert.assertEquals(2, body.size());
	    Assert.assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void testGetPlatformCodesByUniversalCode_mustFail_Invalid_CodeSet() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "invalCodeSet");
		urlVariables.put("universal-code", "PIL*RY4*HJ");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}/platform-codes";
		
		ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    ApiError apiError = serviceResult.getBody().getApiError();
		Assert.assertNotNull(apiError);
		CtsErrorCode errorCode = apiError.getErrorCode();
		Assert.assertEquals(CtsErrorCode.BAD_REQUEST, errorCode);
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void testGetPlatformCodesByUniversalCode_mustFail_CodeSetWithNoPlatformMappings() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "PIL*RY4*HJ");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}/platform-codes";
		
		ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    ApiError apiError = serviceResult.getBody().getApiError();
		Assert.assertNotNull(apiError);
		CtsErrorCode errorCode = apiError.getErrorCode();
		List<SubError> subErrors = apiError.getSubErrors();
		String message = subErrors.get(0).getMessage();
		Assert.assertEquals("Code Set in Request URL does not have associated Platform Code Mappings.", message);
		Assert.assertEquals(CtsErrorCode.BAD_REQUEST, errorCode);
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void testGetPlatformCodesByUniversalCode_mustFail_WithInvalidUniversalCode() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		urlVariables.put("universal-code", "PIL*RY4*HJ*JKHDFSD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}/platform-codes";
		
		ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    ApiError apiError = serviceResult.getBody().getApiError();
		Assert.assertNotNull(apiError);
		CtsErrorCode errorCode = apiError.getErrorCode();
		List<SubError> subErrors = apiError.getSubErrors();
		String message = subErrors.get(0).getMessage();
		Assert.assertEquals("Invalid field value: PIL*RY4*HJ*JKHDFSD must match pattern: ^[A-Z0-9*]{8,15}(?<!\\*)", message);
		Assert.assertEquals(CtsErrorCode.BAD_REQUEST, errorCode);
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.PlatformCodeController#insert(java.lang.String, java.util.List)}.
	 */
	@Test
	public void testInsert() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform-code", "PLA*123*CD");
		platformCodeData.put("platform-identifier", "MDIV");
		
		ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    /*Assert.assertEquals(201, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());
	    Assert.assertEquals("Success", serviceResult.getBody().getStatus());*/
		assertTrue(true);
	}
	
	
	@Test
	public void testUpdatePlatformCodeMaping_mustPass_WithValidMappingRequest() throws ServiceException {
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("universal_code", "CMN1*536*01");
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("mapping_status", "DISABLED");
		platformMappingList.add(mappingdata);
		String mappingMessage="Updated mapping records ";
		ServiceResponse<String> response = new ServiceResponse<String>(mappingMessage+"= "+1,new ErrorDetails(), ApiStatus.SUCCESS.name()); 
		Mockito.when(platformCodeServiceImpl.update("comment", platformMappingList)).thenReturn(response);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, platformMappingList, ApiResponse.class, urlVariables);
		assertNull(serviceResult.getBody());
		assertEquals("SUCCESS", serviceResult.getStatus().name());
		assertEquals(mappingMessage+"= "+1,serviceResult.getMessage());
	}
	
	@Test
	public void testUpdatePlatformCodeMaping_ShouldReturnBadRequest_WithInValidRequest() throws ServiceException {
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("universal_code", "");
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("mapping_status", "DISABLED");
		platformMappingList.add(mappingdata);
		String mappingMessage="Updated mapping records ";
		ServiceResponse<String> response = new ServiceResponse<String>(mappingMessage+"= "+1,new ErrorDetails(), null); 
		Mockito.when(platformCodeServiceImpl.update("comment", platformMappingList)).thenReturn(response);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, platformMappingList, ApiResponse.class, urlVariables);
		assertNull(serviceResult.getBody());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST,serviceResult.getApiError().getErrorCode() );
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	}
	
	@Test
	public void testUpdatePlatformCodeMaping_ShouldReturnBadRequest_WithInValidParameterRequest() throws ServiceException {
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("universal_code", "CMN1*536*01");
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("mapping_status", "DISABLED");
		mappingdata.put("last_updated", "");
		platformMappingList.add(mappingdata);
		String mappingMessage="Updated mapping records ";
		ServiceResponse<String> response = new ServiceResponse<String>(mappingMessage+"= "+1,new ErrorDetails(), null); 
		Mockito.when(platformCodeServiceImpl.update("comment", platformMappingList)).thenReturn(response);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, platformMappingList, ApiResponse.class, urlVariables);
		assertNull(serviceResult.getBody());
		serviceResult.getApiError().getSubErrors().forEach(error->{
			 Assert.assertEquals("Field: last_updated can't be updated.",error.getMessage());
		});
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST,serviceResult.getApiError().getErrorCode() );
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	}
	
	
	@Test
	public void testUpdatePlatformCodeMaping_ShouldReturnBadRequest_WithRepeatativePlatformCodesInRequest() throws ServiceException {
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdataOne= new HashMap<>();
		mappingdataOne.put("universal_code", "CMN1*536*01");
		mappingdataOne.put("platform_code", "MDV2*536*5109");
		mappingdataOne.put("platform_identifier", "MDIV");
		mappingdataOne.put("mapping_status", "DISABLED");
		platformMappingList.add(mappingdataOne);
		Map<String,String> mappingdataTwo= new HashMap<>();
		mappingdataTwo.put("universal_code", "CMN1*536*02");
		mappingdataTwo.put("platform_code", "MDV2*536*5109");
		mappingdataTwo.put("platform_identifier", "MDIV");
		mappingdataTwo.put("mapping_status", "DISABLED");
		platformMappingList.add(mappingdataTwo);
		String mappingMessage="Updated mapping records ";
		ServiceResponse<String> response = new ServiceResponse<String>(mappingMessage+"= "+1,new ErrorDetails(), null); 
		Mockito.when(platformCodeServiceImpl.update("comment", platformMappingList)).thenReturn(response);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, platformMappingList, ApiResponse.class, urlVariables);
		assertNull(serviceResult.getBody());
		serviceResult.getApiError().getSubErrors().forEach(error->{

		});
		Assert.assertEquals(CtsErrorCode.BAD_REQUEST,serviceResult.getApiError().getErrorCode() );
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	}
	

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.PlatformCodeController#update(java.lang.String, java.util.List)}.
	 */
	//@Test
	public void testUpdate() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("universal-code", "UNIV*152*G");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(null, serviceResult.getApiError());
	    Assert.assertEquals("Success", serviceResult.getStatus());
	}
	
	@Test
	public void getPlatformCodesByUniversalCodeTest_Success() throws ServiceException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		String orderBy = "A";
		Direction direction = Direction.ASC;
		String platformIdentifier="GFS";
		
		Map<String, Object> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		urlVariables.put("page", String.valueOf(page));
		urlVariables.put("count", String.valueOf(count));
		urlVariables.put("mappingStatus", filter);
		urlVariables.put("orderBy", orderBy);
		urlVariables.put("direction", direction);
		urlVariables.put("platformIdentifier", platformIdentifier);
		
	
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes?"
				+ "page={page}&count={count}&mappingStatus={mappingStatus}&orderBy={orderBy}&direction={direction}"
				+ "&platformIdentifier={platformIdentifier}";
		
		
		List<Map<String, String>> expectedBody = new ArrayList<>();
		Map<String, String> platformCodeData1 = new HashMap<>();
		platformCodeData1.put("universal_code", "PIL*RY4*HJ");
		platformCodeData1.put("platform_code", "ABC*123S*HJ");
		platformCodeData1.put("platform_identifier", "MDIV");
		platformCodeData1.put("last_updated", null);
		platformCodeData1.put("creation_date", "2020-02-21 09:00:00.0");
		platformCodeData1.put("mapping_status", "ENABLED");
		expectedBody.add(platformCodeData1);
		Map<String, String> platformCodeData12 = new HashMap<>();
		platformCodeData12.put("universal_code", "PIL*RY4*HJ");
		platformCodeData12.put("platform_code", "PQR*123S*HJ");
		platformCodeData12.put("platform_identifier", "GFS");
		platformCodeData12.put("last_updated", null);
		platformCodeData12.put("creation_date", "2020-01-21 11:00:00.0");
		platformCodeData12.put("mapping_status", "DISABLED");
		expectedBody.add(platformCodeData12);
		
		String message="Returning Platform Codes for the given Code Set.";
		ServiceResponse<List<Map<String, String>>> serviceResponse = new ServiceResponse<List<Map<String,String>>>(message, expectedBody );
		
		Mockito.when(platformCodeServiceImpl.getAllPlatformCodes(codeSet,page, count,filter , orderBy, direction,platformIdentifier)).thenReturn(serviceResponse);
		
		Mockito.when(platformCodeServiceImpl.getPlatformCodesRecordCount(codeSet, filter,null)).thenReturn(2);
		
		ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    HttpHeaders headers = serviceResult.getHeaders();
	    Set<String> keySet = headers.keySet();
	    Assert.assertEquals(true, keySet.contains("totalRecordsCount"));
	    Assert.assertEquals(true, keySet.contains("totalPages"));
	    Assert.assertEquals(true, keySet.contains("hasNextPage"));
	    Assert.assertEquals(true, keySet.contains("hasPreviousPage"));
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());
	    Assert.assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	
	}
	
	@Test
	public void getPlatformCodesByUniversalCodeTest_ValidationError_InvalidPaging() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment";
		Integer page = -1;
		Integer count = -1;
		StatusEnum filter = StatusEnum.ENABLED;
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		urlVariables.put("page", String.valueOf(page));
		urlVariables.put("count", String.valueOf(count));
		urlVariables.put("filter", filter.name());
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes?page={page}&count={count}&filter={filter}";
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    ApiError apiError = responseBody.getApiError();
	    List<SubError> subErrors = apiError.getSubErrors();
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertNotNull(serviceResult.getBody().getApiError());
	    Assert.assertNotNull(subErrors);
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}
	 
	@Test
	public void getPlatformCodesByUniversalCodeTest_ValidationError_InvalidCodeSet() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment1";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes";
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    ApiError apiError = responseBody.getApiError();
	    List<SubError> subErrors = apiError.getSubErrors();
	    SubError subError = subErrors.get(0);
	    Assert.assertTrue(subError.getRejectedValue().containsKey("code-set"));
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertNotNull(serviceResult.getBody().getApiError());
	    Assert.assertNotNull(subErrors);
	    Assert.assertEquals("Error occurred while processing the request. URI Path: /code-sets/comment1/platform-codes", responseBody.getMessage());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void getPlatformCodesDataByPlatformCodesTest_ValidationError_InvalidRequest() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/fetch";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		
	    ResponseEntity<ApiResponse> serviceResult =  this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    ApiError apiError = responseBody.getApiError();
	    List<SubError> subErrors = apiError.getSubErrors();
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertNotNull(serviceResult.getBody().getApiError());
	    Assert.assertNotNull(subErrors);
	    Assert.assertEquals("Error occurred while processing the request. URI Path: /code-sets/comment/platform-codes/fetch", responseBody.getMessage());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void getPlatformCodesDataByPlatformCodesTest_shouldReturnData_validRequest() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/fetch";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "MDV2*536*5111");
		platformCodeData.put("platform_identifier", "MDIV");
		
		
		Map<String, String> dbObject = new HashMap<>();
		dbObject.put("universal_code", "PIL*RY4*HJ");
		dbObject.put("platform_code", "MDV2*536*5111");
		dbObject.put("platform_identifier", "MDIV");
		dbObject.put("last_updated", "2020-01-21 11:00:00.0");
		dbObject.put("creation_date", "2020-01-21 11:00:00.0");
		dbObject.put("mapping_status", "DISABLED");
		ServiceResponse<Map<String, String>> response=new ServiceResponse<>("Returning Platform Code Data for the given input request and Code Set.",platformCodeData);
		Mockito.when(platformCodeServiceImpl.getByCode(codeSet, platformCodeData)).thenReturn(response);
		
	    ResponseEntity<ApiResponse> serviceResult =  this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    Assert.assertEquals(200,serviceResult.getStatusCodeValue());
	    Assert.assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	    Assert.assertNull(responseBody.getApiError());
	    Assert.assertEquals("Returning Platform Code Data for the given input request and Code Set.", responseBody.getMessage());
	}

	@Test
	public void getPlatformCodesDataByPlatformCodesTest_ValidationError_InvalidRequestFormats() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/fetch";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CDttt");
		platformCodeData.put("platform_identifier", null);
	    ResponseEntity<ApiResponse> serviceResult =  this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    ApiError apiError = responseBody.getApiError();
	    List<SubError> subErrors = apiError.getSubErrors();
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertNotNull(serviceResult.getBody().getApiError());
	    Assert.assertNotNull(subErrors);
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    
	    
	}
}
