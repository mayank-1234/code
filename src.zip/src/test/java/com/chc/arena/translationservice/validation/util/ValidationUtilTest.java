package com.chc.arena.translationservice.validation.util;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.chc.arena.translationservice.service.exception.ErrorDetails;
import com.chc.arena.translationservice.validation.util.ValidationUtil;

/**
 * The Class ValidationUtilTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ValidationUtilTest {

	/**
	 * Reject invalid code set should report validation errors.
	 */
	@Test
	public void rejectInvalidCodeSet_ShouldReportValidationErrors() {		
		ErrorDetails validationErrors = new ErrorDetails();
		
		ValidationUtil.rejectInvalidCodeSet(validationErrors, "A");
		
		assertTrue(validationErrors.getIssues().containsKey("Invalid Code Set in Request URL"));
		assertTrue(validationErrors.getIssues().get("Invalid Code Set in Request URL").get("code-set").equals("A"));
	}
	
	/**
	 * Missing required field should report validation errors.
	 */
	@Test
	public void missingRequiredField_ShouldReportValidationErrors() {		
		ErrorDetails validationErrors = new ErrorDetails();
		
		ValidationUtil.missingRequiredField(validationErrors, "ABC");
		
		assertTrue(validationErrors.getIssues().containsKey("Required field: ABC, missing in request body"));
		assertNull(validationErrors.getIssues().get("Required field: ABC, missing in request body").get("ABC"));
	}
	
	/**
	 * Reject invalid field should report validation errors.
	 */
	@Test
	public void rejectInvalidField_ShouldReportValidationErrors() {		
		ErrorDetails validationErrors = new ErrorDetails();
		
		ValidationUtil.rejectInvalidField(validationErrors, "ABC", "DEF");
		
		assertTrue(validationErrors.getIssues().containsKey("Invalid field: ABC, in request body"));
		assertEquals("DEF", validationErrors.getIssues().get("Invalid field: ABC, in request body").get("ABC"));
	}
	
	/**
	 * Reject invalid field value should report validation errors.
	 */
	@Test
	public void rejectInvalidFieldValue_ShouldReportValidationErrors() {		
		ErrorDetails validationErrors = new ErrorDetails();
		
		ValidationUtil.rejectInvalidFieldValue(validationErrors, "ABC", "DEF", "Regex");
		
		assertTrue(validationErrors.getIssues().containsKey("Invalid field value: DEF must match pattern: Regex"));
		assertEquals("DEF", validationErrors.getIssues().get("Invalid field value: DEF must match pattern: Regex").get("ABC"));
	}
	
	/**
	 * Checks if is empty should return true if empty.
	 */
	@Test
	public void isEmpty_ShouldReturnTrue_IfEmpty() {		
		ErrorDetails validationErrors = new ErrorDetails();
		
		boolean actualValue = ValidationUtil.isEmpty(validationErrors);
		
		assertTrue(actualValue);		
	}
	
	/**
	 * Checks if is empty should return false if empty.
	 */
	@Test
	public void isEmpty_ShouldReturnFalse_IfEmpty() {		
		ErrorDetails validationErrors = new ErrorDetails();
		validationErrors.getIssues().put("A", new HashMap<String, String>());
		
		boolean actualValue = ValidationUtil.isEmpty(validationErrors);
		
		assertFalse(actualValue);		
	}
}
