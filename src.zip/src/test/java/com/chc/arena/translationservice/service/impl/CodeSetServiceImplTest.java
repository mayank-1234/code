package com.chc.arena.translationservice.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;

/**
 * The Class CodeSetServiceImplTest.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class CodeSetServiceImplTest {
	
	/** The code set service impl. */
	@InjectMocks
	private CodeSetServiceImpl codeSetServiceImpl;
	
	/** The code set meta data util. */
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	/**
	 * Setup.
	 */
	@BeforeClass
	public static void setup() {
		
	}

	/**
	 * Setup this.
	 */
	@Before
	public void setupThis() {
	}
	
	/**
	 * Gets the all supported code sets should return supported code sets.
	 *
	 * @return the all supported code sets should return supported code sets
	 */
	@Test
	public void getAllSupportedCodeSets_shouldReturnSupportedCodeSets() {
		List<String> codeSets=new ArrayList<String>();
		codeSets.add("insurance");codeSets.add("transaction-code");codeSets.add("comment");
		Mockito.when(codeSetMetaDataUtil.getCodeSets()).thenReturn(codeSets);
		assertEquals(codeSets, codeSetServiceImpl.getAllSupportedCodeSets());
		assertNotNull(codeSetServiceImpl.getAllSupportedCodeSets());
		assertEquals(3, codeSetServiceImpl.getAllSupportedCodeSets().size());
	}

}
