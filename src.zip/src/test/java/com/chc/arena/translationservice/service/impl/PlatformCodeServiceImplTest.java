/**
 * 
 */
package com.chc.arena.translationservice.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.dao.UniversalCodeSetSQLDao;
import com.chc.arena.translationservice.dao.impl.PlatformCodeSetSQLDaoImpl;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;

/**
 * @author narendra.dubey
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PlatformCodeServiceImplTest {
	
	@Mock
	private PlatformCodeSetSQLDaoImpl platformCodeSetSQLDao;
	
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Mock
	private UniversalCodeSetSQLDao universalCodeSetSQLDao;
	
	@InjectMocks
	private PlatformCodeServiceImpl platformCodeServiceImpl;
	
	@Mock
	private MessageSourceUtil messageSourceUtil;
		
	private static final String UPDATED_MAPPING_RECORDS="Updated mapping records ";
	
	public static final String PLATFORM_CODE_FIELD = "platform_code";
	public static final String PLATFORM_IDENTIFIER_COLUMN = "platform_identifier";
	
	/**
	 * Test method for {@link com.chc.arena.translationservice.service.impl.PlatformCodeServiceImpl#getPlatformCodesByUniversalCode(java.lang.String, java.lang.String, java.lang.Integer, java.lang.Integer, com.chc.arena.translationservice.validation.annotation.Status, java.lang.String, com.chc.arena.translationservice.model.Direction)}.
	 * @throws DaoException 
	 * @throws ServiceException 
	 */
	@Test
	public void testGetPlatformCodesByUniversalCode() throws DaoException, ServiceException {
		String codeSet = "comment";
		String universalCode = "PIL*RY4*HJ";
		
		List<Map<String, Object>> expectedBody = new ArrayList<>();
		Map<String, Object> platformCodeData1 = new HashMap<>();
		platformCodeData1.put("universal_code", "PIL*RY4*HJ");
		platformCodeData1.put("platform_code", "ABC*123S*HJ");
		platformCodeData1.put("platform_identifier", "MDIV");
		platformCodeData1.put("last_updated", null);
		platformCodeData1.put("creation_date", "2020-02-21 09:00:00.0");
		platformCodeData1.put("mapping_status", "ENABLED");
		expectedBody.add(platformCodeData1);
		Map<String, Object> platformCodeData12 = new HashMap<>();
		platformCodeData12.put("universal_code", "PIL*RY4*HJ");
		platformCodeData12.put("platform_code", "PQR*123S*HJ");
		platformCodeData12.put("platform_identifier", "GFS");
		platformCodeData12.put("last_updated", null);
		platformCodeData12.put("creation_date", "2020-01-21 11:00:00.0");
		platformCodeData12.put("mapping_status", "DISABLED");
		expectedBody.add(platformCodeData12);
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(new HashMap<>());
		
		Mockito.when(platformCodeSetSQLDao
					.getPlatformCodesByUniversalCode(codeSet, universalCode, null, null, null, null, null)).thenReturn(expectedBody);
		
		ServiceResponse<List<Map<String,String>>> platformCodesByUniversalCode = platformCodeServiceImpl.getPlatformCodesByUniversalCode(codeSet, universalCode, null, null, null, null, null);
		Assert.assertNotNull(platformCodesByUniversalCode);
		List<Map<String, String>> actualResult = platformCodesByUniversalCode.getBody();
		Assert.assertEquals(2, actualResult.size());
	}
	
	@Test
	public void testGetPlatformCodesByUniversalCode_MustSucceed_NoMappingsFound() throws DaoException, ServiceException {
		String codeSet = "comment";
		String universalCode = "PIL*RY4*HJ";
		
		List<Map<String, Object>> expectedBody = new ArrayList<>();
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(new HashMap<>());
				
		Mockito.when(platformCodeSetSQLDao
					.getPlatformCodesByUniversalCode(codeSet, universalCode, null, null, null, null, null)).thenReturn(expectedBody);
		String message="No mapped Platform Codes found for the given Universal Code.";
		
		Mockito.when(messageSourceUtil.getMessage("NO_MAPPED_PLATFORM_CODES_FOUND")).thenReturn(message);
		
		ServiceResponse<List<Map<String,String>>> platformCodesByUniversalCode = platformCodeServiceImpl.getPlatformCodesByUniversalCode(codeSet, universalCode, null, null, null, null, null);
		Assert.assertNotNull(platformCodesByUniversalCode);
		List<Map<String, String>> actualResult = platformCodesByUniversalCode.getBody();
		Assert.assertEquals(0, actualResult.size());
		Assert.assertEquals(message, platformCodesByUniversalCode.getMessage());
	}
	
	@Test
	public void testGetPlatformCodesByUniversalCode_MustFail_DaoException() throws DaoException {
		String codeSet = "comment";
		String universalCode = "PIL*RY4*HJ";
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(new HashMap<>());
		
		String message="Application failed to query database.";
		
		Mockito.when(platformCodeSetSQLDao
					.getPlatformCodesByUniversalCode(codeSet, universalCode, null, null, null, null, null)).thenThrow(new DaoException(message,
							CtsErrorCode.INTERNAL_SERVER_ERROR));
		
		try {
			platformCodeServiceImpl.getPlatformCodesByUniversalCode(codeSet, universalCode, null, null, null, null, null);
		} catch (ServiceException e) {
			Assert.assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, e.getErrorCode());
			Assert.assertEquals(message, e.getMessage());
		}
		
	}
	
	@Test
	public void update_shouldMapPlatformCodesWithRespectiveUniversalCodes() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";
		Map<String,String> map= platformMappingDataList.get(0);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");

		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		
		
		Map<String, Object> universalDbObject= new HashMap<>();
		universalDbObject.put(TranslationServiceStringConstant.STATUS,"DISABLED");
		universalDbObject.put(TranslationServiceStringConstant.ID, 10);
		Mockito.when(universalCodeSetSQLDao.getUniversalCodeRecordsToVerifyStatus(codeSet, map)).thenReturn(universalDbObject);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void getAllPlatformCodesTest_Success() throws DaoException, ServiceException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		String orderBy = null;
		Direction direction = null;
		
		List<Map<String, Object>> expectedBody = new ArrayList<>();
		Map<String, Object> platformCodeData1 = new HashMap<>();
		platformCodeData1.put("universal_code", "PIL*RY4*HJ");
		platformCodeData1.put("platform_code", "ABC*123S*HJ");
		platformCodeData1.put("platform_identifier", "MDIV");
		platformCodeData1.put("last_updated", null);
		platformCodeData1.put("creation_date", "2020-02-21 09:00:00.0");
		platformCodeData1.put("mapping_status", "ENABLED");
		expectedBody.add(platformCodeData1);
		String message="Returning Platform Codes for the given Code Set.";
		Mockito.when(messageSourceUtil.getMessage("PLATFORM_CODES_IN_DATABASE")).thenReturn(message);
		
		Mockito.when(platformCodeSetSQLDao.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null)).thenReturn(expectedBody);
		
		ServiceResponse<List<Map<String,String>>> platformCodesServiceResponse = platformCodeServiceImpl.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null);
		
		List<Map<String, String>> responseBody = platformCodesServiceResponse.getBody();
		String responseMessage = platformCodesServiceResponse.getMessage();
		
		assertEquals(message, responseMessage);
		assertNotNull(responseBody);
		assertEquals(1, responseBody.size());
	}
	
	@Test
	public void getAllPlatformCodesTest_Success_EmptyBody() throws DaoException, ServiceException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		String orderBy = null;
		Direction direction = null;
		
		List<Map<String, Object>> repoPlatformCodes = new ArrayList<>();
		String exceptionMessage= "No Platform Codes found in database for the given Code Set.";
		Mockito.when(messageSourceUtil.getMessage("NO_PLATFORM_CODES_IN_DATABASE")).thenReturn(exceptionMessage);
		
		Mockito.when(platformCodeSetSQLDao.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null)).thenReturn(repoPlatformCodes);
		
		ServiceResponse<List<Map<String,String>>> platformCodesServiceResponse = platformCodeServiceImpl.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null);
		
		List<Map<String, String>> responseBody = platformCodesServiceResponse.getBody();
		String responseMessage = platformCodesServiceResponse.getMessage();
		
		assertEquals(exceptionMessage, responseMessage);
		assertNotNull(responseBody);
		assertEquals(0, responseBody.size());		
	}
	
	@Test
	public void getAllPlatformCodesTest_Failure_DaoException() throws DaoException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		String orderBy = null;
		Direction direction = null;
		
		String message="Application failed to query database.";
		
		DaoException daoException = new DaoException(message,
				CtsErrorCode.INTERNAL_SERVER_ERROR);
		
		Mockito.when(platformCodeSetSQLDao.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null)).thenThrow(daoException);
		
		try {
			platformCodeServiceImpl.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null);
		} catch (ServiceException serviceException) {
			assertEquals(message, serviceException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, serviceException.getErrorCode());
		}		
	}

	
	
	@Test
	public void update_shouldReject_PassedStatusIsEnable_WithDisableUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		map.put("mapping_status", "ENABLED");

		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		
		
		Map<String, Object> universalDbObject= new HashMap<>();
		universalDbObject.put(TranslationServiceStringConstant.STATUS,"DISABLED");
		universalDbObject.put(TranslationServiceStringConstant.ID, 10);
		Mockito.when(universalCodeSetSQLDao.getUniversalCodeRecordsToVerifyStatus(codeSet, map)).thenReturn(universalDbObject);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+0, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(0)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldUpdate_PassedStatusIsEnable_WithEnableUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		map.put("mapping_status", "ENABLED");

		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		
		Map<String, Object> universalDbObject= new HashMap<>();
		universalDbObject.put(TranslationServiceStringConstant.STATUS,"ENABLED");
		universalDbObject.put(TranslationServiceStringConstant.ID, 10);
		Mockito.when(universalCodeSetSQLDao.getUniversalCodeRecordsToVerifyStatus(codeSet, map)).thenReturn(universalDbObject);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	
	@Test
	public void update_shouldUpdate_NoStatusIsPassed_WithEnableUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		map.put("mapping_status", "");

		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		
		Map<String, Object> universalDbObject= new HashMap<>();
		universalDbObject.put(TranslationServiceStringConstant.STATUS,"DISABLED");
		universalDbObject.put(TranslationServiceStringConstant.ID, 10);
		Mockito.when(universalCodeSetSQLDao.getUniversalCodeRecordsToVerifyStatus(codeSet, map)).thenReturn(universalDbObject);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	
	
	@Test
	public void update_shouldUpdate_NoStatusIsPassed_WithDisableUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		map.put("mapping_status", null);
		
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Map<String, Object> universalDbObject= new HashMap<>();
		universalDbObject.put(TranslationServiceStringConstant.STATUS,"ENABLED");
		universalDbObject.put(TranslationServiceStringConstant.ID, 10);
		Mockito.when(universalCodeSetSQLDao.getUniversalCodeRecordsToVerifyStatus(codeSet, map)).thenReturn(universalDbObject);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldReject_NoUniversalMappingIsPresentInDB_RequestWithoutUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		map.put("universal_code", null);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,null);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		
		
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		
		Map<String, Object> universalDbObject= new HashMap<>();
		universalDbObject.put(TranslationServiceStringConstant.STATUS,"ENABLED");
		universalDbObject.put(TranslationServiceStringConstant.ID, 10);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+0, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(0)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldReject_UniversalMappingIsPresentInDB_RequestWithoutUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		map.put("universal_code", null);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		
		
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Map<String, Object> universalDbObjectByPlatformUniversalID= new HashMap<>();
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.STATUS,"ENABLED");
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.ID, 10); 
		Mockito.when(universalCodeSetSQLDao.getById(codeSet, "10")).thenReturn(universalDbObjectByPlatformUniversalID);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldReject_UniversalMappingIsPresentInDB_RequestWithoutUniversalCode_WithNullMappingStatus() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		map.put("universal_code", null);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
	
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);

		Map<String, Object> universalDbObjectByPlatformUniversalID= new HashMap<>();
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.STATUS,"ENABLED");
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.ID, 10); 
		Mockito.when(universalCodeSetSQLDao.getById(codeSet, "10")).thenReturn(universalDbObjectByPlatformUniversalID);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldUpdate_EnableUniversalCodeEnablemapping_WithoutUniversalCode() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		map.put("universal_code", null);
		map.put("mapping_status", "ENABLED");
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		
		
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>();
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		
		
		Map<String, Object> universalDbObjectByPlatformUniversalID= new HashMap<>();
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.STATUS,"ENABLED");
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.ID, 10); 
		Mockito.when(universalCodeSetSQLDao.getById(codeSet, "10")).thenReturn(universalDbObjectByPlatformUniversalID);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	
	@Test
	public void update_shouldReject_NoUniversalCodeDataFoundInDb() throws ServiceException {
	
		List<Map<String,String>> platformMappingDataList= getMappingObjectToUpdate();
		String codeSet = "comment";  
		Map<String,String> map= platformMappingDataList.get(0);
		Map<String, Object> platformDbObject= new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		map.put("mapping_status", null);
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(map);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>(); 
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Map<String, Object> universalDbObject=  null;
		Mockito.when(universalCodeSetSQLDao.getUniversalCodeRecordsToVerifyStatus(codeSet, map)).thenReturn(universalDbObject);
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingDataList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+0, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(0)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldReject_DisableUniversalCodeDataWithEnableMapping() throws ServiceException {
	
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("platform_code", "MDV2*536*5109"); 
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("mapping_status", "ENABLED");
		platformMappingList.add(mappingdata);
		String codeSet = "comment";  
		Map<String, Object> platformDbObject= new HashMap<>(); 
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		platformDbObject.put(TranslationServiceStringConstant.STATUS, "DISABLED");
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(mappingdata);
		
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>(); 
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Map<String, Object> universalDbObjectByPlatformUniversalID= new HashMap<>();
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.STATUS,"DISABLED");
		universalDbObjectByPlatformUniversalID.put(TranslationServiceStringConstant.ID, 10); 
		ServiceResponse<String> response = platformCodeServiceImpl.update(codeSet, platformMappingList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+0, response.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(0)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
		
		Map<String, Object> universalDbObject= null; 
		Mockito.when(universalCodeSetSQLDao.getById(Mockito.eq(codeSet),Mockito.any())).thenReturn(universalDbObject);
		ServiceResponse<String> responseForNoNExistedUniversal = platformCodeServiceImpl.update(codeSet, platformMappingList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+0, responseForNoNExistedUniversal.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(0)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
		
	}
	
 
	@Test
	public void update_shouldReject_IfNoPlatfromCodeExistInDB() throws ServiceException {
		String codeSet = "comment";
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("mapping_status", "ENABLED");  
		platformMappingList.add(mappingdata);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		ServiceResponse<String> responseForNoNExistedUniversal = platformCodeServiceImpl.update(codeSet, platformMappingList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+0, responseForNoNExistedUniversal.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(0)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	
	@Test
	public void update_shouldAccept_IfDeleteMappingRequest() throws ServiceException {
		String codeSet = "comment";
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("universal_code", null);  
		platformMappingList.add(mappingdata);
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(mappingdata);
		Map<String, Object> platformDbObject= new HashMap<>(); 
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN,10);
		platformDbObject.put(PLATFORM_CODE_FIELD,"MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN,"MDIV");
		platformDbObject.put(TranslationServiceStringConstant.STATUS, "DISABLED");
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>(); 
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		mappedDbDataWithCompositKeys.put("MDV2*536*5109"+"MDIV", platformDbObject);
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		Mockito.when(messageSourceUtil.getMessage("UPDATED_MAPPING_RECORDS")).thenReturn(UPDATED_MAPPING_RECORDS);
		Mockito.when(platformCodeSetSQLDao.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet,platformCodeData)).thenReturn(mappedPlatformDbData);
		ServiceResponse<String> responseForNoNExistedUniversal = platformCodeServiceImpl.update(codeSet, platformMappingList);
		assertEquals(UPDATED_MAPPING_RECORDS+"= "+1, responseForNoNExistedUniversal.getMessage());
		Mockito.verify(platformCodeSetSQLDao,times(1)).update(Mockito.eq(codeSet), Mockito.anyMap(),Mockito.any());
	}
	
	private List<Map<String,String>> getMappingObjectToUpdate() {
		List<Map<String,String>> platformMappingList= new ArrayList<>();
		Map<String,String> mappingdata= new HashMap<>();
		mappingdata.put("universal_code", "CMN1*536*01");
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("mapping_status", "DISABLED");
		platformMappingList.add(mappingdata);
		return platformMappingList;
	}
	
	
	@Test
	public void getByCode_shouldReturnPlatformData_IfValidRequest() throws ServiceException, DaoException {
		String codeSet = "comment";
		String message="Success";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "MDV2*536*5111");
		platformCodeData.put("platform_identifier", "MDIV");
		
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("universal_code", "PIL*RY4*HJ");
		dbObject.put("platform_code", "MDV2*536*5111");
		dbObject.put("platform_identifier", "MDIV");
		dbObject.put("last_updated", "2020-01-21 11:00:00.0");
		dbObject.put("creation_date", "2020-01-21 11:00:00.0");
		dbObject.put("mapping_status", "DISABLED");
		dbObject.put("universal_code_id", "15");
		Mockito.when(messageSourceUtil.getMessage("PLATFORM_CODE_IN_DATABASE")).thenReturn(message);
		Mockito.when(platformCodeSetSQLDao.getPlatformCodeDataByCode(codeSet, platformCodeData)).thenReturn(dbObject);
		ServiceResponse<Map<String, String>> response=platformCodeServiceImpl.getByCode(codeSet, platformCodeData);
		assertEquals(response.getMessage(), message);
		assertFalse(response.getBody().containsKey("universal_code_id"));
		assertTrue(response.getBody().containsKey("universal_code"));
		assertTrue(response.getBody().containsKey("platform_code"));
		assertTrue(response.getBody().containsKey("last_updated"));
		assertTrue(response.getBody().containsKey("creation_date"));
		assertTrue(response.getBody().containsKey("mapping_status"));
		assertEquals(response.getMessage(), message);
		
	}
	
	
	@Test
	public void getByCode_shouldReturnPlatformData_IfEntitytNotFound() throws  DaoException {
		String codeSet = "comment";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "MDV2*536*5111");
		platformCodeData.put("platform_identifier", "MDIV");
		String message="No Platform Codes found in database for the given Code Set.";
		try {
			Mockito.when(platformCodeSetSQLDao.getPlatformCodeDataByCode(codeSet, platformCodeData)).thenThrow(new DaoException(message, CtsErrorCode.ENTITY_NOT_FOUND));
			platformCodeServiceImpl.getByCode(codeSet, platformCodeData);
		} catch (ServiceException e) {
			assertNotNull(e.getErrorDetails());
			assertEquals(e.getMessage(), message);
		} 
	}

}
