package com.chc.arena.translationservice.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.querybuilder.SQLQueryBuilder;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Class PlatformCodeSetSQLDaoImplTest.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class PlatformCodeSetSQLDaoImplTest {
	
	/** The jdbc template. */
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	@Mock
	private SQLQueryBuilder sqlQueryBuilder;
	
	@Mock
	private MessageSourceUtil messageSourceUtil;
		
	
	/** The platform code set SQL dao impl. */
	@InjectMocks
	private PlatformCodeSetSQLDaoImpl platformCodeSetSQLDaoImpl;
	
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;

	
	public static final String PLATFORM_CODE_FIELD = "platform_code";
	public static final String PLATFORM_IDENTIFIER_COLUMN = "platform_identifier";
	/**
	 * Setup.
	 */
	@BeforeClass
	public static void setup() {
	}

	/**
	 * Setup this.
	 */
	@Before
	public void setupThis() {
	}

	/**
	 * Gets the platform codes by universal code should return valid platform codes.
	 *
	 * @return the platform codes by universal code should return valid platform codes
	 * @throws DaoException 
	 */
	@Test
	public void getPlatformCodesByUniversalCode_shouldReturn_validPlatformCodes() throws DaoException {
		String codeSet = "comment";
		String universalCode = "PIL*RY4*HJ";
		Integer page = null;
		Integer count = null;
		StatusEnum filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String getPlatformByUniversalQuery = "SELECT comment_universal.universal_code,comment_platform.platform_code, comment_platform.platform_identifier, comment_platform.creation_date, comment_platform.last_updated, comment_platform.mapping_status FROM comment_platform LEFT JOIN comment_universal ON comment_universal.id = comment_platform.universal_code_id  WHERE comment_universal.universal_code =:universal_code ";
		
		Mockito.when(sqlQueryBuilder
				.buildPlatformRetrieveByUniversalCodeIdQuery(codeSet, page, count, filter, orderBy, direction)).thenReturn(getPlatformByUniversalQuery);
		
		MapSqlParameterSource mapSqlParameters = new MapSqlParameterSource();
		
		mapSqlParameters.addValue("universal_code", universalCode);
				
		Mockito.when(sqlQueryBuilder
				.setPlatformRetrieveByUniversalCodeIdParameters(universalCode, filter)).thenReturn(mapSqlParameters );
		
		List<Map<String, Object>> platformCodes = new ArrayList<>();
		Map<String, Object> platformCodeMap = new HashMap<>();
		platformCodeMap.put("universal_code", "PIL*RY4*HJ");
		platformCodeMap.put("platform_identifier", "MDIV");
		platformCodes.add(platformCodeMap);
		
		Mockito.when(namedParameterJdbcTemplate.queryForList(getPlatformByUniversalQuery,
				mapSqlParameters)).thenReturn(platformCodes);
		
		List<Map<String,Object>> platformCodesByUniversalCode = platformCodeSetSQLDaoImpl.getPlatformCodesByUniversalCode(codeSet, universalCode, page, count, filter, orderBy, direction);

		assertNotNull(platformCodesByUniversalCode);
		assertEquals(1, platformCodesByUniversalCode.size());
	}
	
	@Test
	public void getPlatformCodesByUniversalCode_shouldThrow_DaoException() {
		String codeSet = "comment";
		String universalCode = "PIL*RY4*HJ";
		Integer from = null;
		Integer count = null;
		StatusEnum filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String invalidPlatformByUniversalQuery = "SELECTTT comment_universal.universal_code,comment_platform.platform_code, comment_platform.platform_identifier, comment_platform.creation_date, comment_platform.last_updated, comment_platform.mapping_status FROM comment_platform LEFT JOIN comment_universal ON comment_universal.id = comment_platform.universal_code_id  WHERE comment_universal.universal_code =:universal_code ";
		
		Mockito.when(sqlQueryBuilder
				.buildPlatformRetrieveByUniversalCodeIdQuery(codeSet, from, count, filter, orderBy, direction)).thenReturn(invalidPlatformByUniversalQuery);
		
		MapSqlParameterSource mapSqlParameters = new MapSqlParameterSource();
		
		mapSqlParameters.addValue("universal_code", universalCode);
				
		Mockito.when(sqlQueryBuilder
				.setPlatformRetrieveByUniversalCodeIdParameters(universalCode, filter)).thenReturn(mapSqlParameters );
		String message="Application failed to query database.";
		Mockito.when(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR")).thenReturn(message);
		
		DaoException daoException = new DaoException(message,
				CtsErrorCode.INTERNAL_SERVER_ERROR);
		
		DataAccessException dataAccessException = new DataAccessException("Something went wrong") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
		};
		
		Mockito.when(namedParameterJdbcTemplate.queryForList(invalidPlatformByUniversalQuery,
				mapSqlParameters)).thenThrow(dataAccessException);
		
		try {
			platformCodeSetSQLDaoImpl.getPlatformCodesByUniversalCode(codeSet, universalCode, from, count, filter, orderBy, direction);
		} catch (DaoException e) {
			assertEquals(daoException.getMessage(), e.getMessage());
		}
	}

	/**
	 * Insert should verify addition of platform codes.
	 */
	@Test
	public void insert_shouldVerify_additionOfPlatformCodes() {
		assertTrue(true);
	}

	/**
	 * Update should verify updation of platform codes.
	 */
	@Test
	public void update_shouldVerify_updationOfPlatformCodes() {
		Map<String, String> codeObject = new HashMap<>();
		Integer id=10;
		Mockito.when(namedParameterJdbcTemplate.update(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenReturn(10);
		Mockito.when(sqlQueryBuilder.buildPlatformUpdateQuery("comment")).thenReturn("Query");
		MapSqlParameterSource params =new MapSqlParameterSource();
		Mockito.when(sqlQueryBuilder.setPlatformUpdateParameters(Mockito.eq("comment"), Mockito.anyMap(),Mockito.eq(id))).thenReturn( params);
		platformCodeSetSQLDaoImpl.update("comment", codeObject, id);
		Mockito.verify(namedParameterJdbcTemplate).update(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class));
		
	}
	

	
	@Test
	public void disableEnablePlatformCodesMappedToUniversalCode_shouldDisableEnablePlatformCodes() {
		Mockito.when(namedParameterJdbcTemplate.update(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenReturn(10);
		
		Mockito.when(sqlQueryBuilder.buildPlatformEnableDisableByUniversalCodeQuery("comment")).thenReturn("Query");
		Mockito.when(sqlQueryBuilder.setPlatformEnableDisableByUniversalCodeParameters(Mockito.eq("ENABLED"), Mockito.eq(1), Mockito.any(Date.class))).thenReturn(new MapSqlParameterSource());
		
		int count = platformCodeSetSQLDaoImpl.disableEnablePlatformCodesMappedToUniversalCode("comment", "ENABLED", 1, new Date());
		
		assertEquals(10, count);
		Mockito.verify(namedParameterJdbcTemplate).update(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class));
	}
	
	
	@Test
	public void getAllPlatformCodesTest_Success() throws DaoException {
		String codeSet = "comment";
		Integer page = null;
		Integer count = null;
		PlatformCodesMappingStatus filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String getAllPlatformQuery = "SELECT comment_platform.universal_code,comment_platform.description, comment_platform.creation_date, comment_platform.last_updated, comment_platform.status FROM comment_platform ";
		
		Mockito.when(sqlQueryBuilder
				.buildPlatformRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction,null)).thenReturn(getAllPlatformQuery);
		
		MapSqlParameterSource mapSqlParameters = new MapSqlParameterSource();
		
		Mockito.when(sqlQueryBuilder
				.setPlatformRetrieveAllParameters(filter,null)).thenReturn(mapSqlParameters );
		
		List<Map<String, Object>> expectedBody = new ArrayList<>();
		Map<String, Object> platformCodeData1 = new HashMap<>();
		platformCodeData1.put("universal_code", "PIL*RY4*HJ");
		platformCodeData1.put("platform_code", "ABC*123S*HJ");
		platformCodeData1.put("platform_identifier", "MDIV");
		platformCodeData1.put("last_updated", null);
		platformCodeData1.put("creation_date", "2020-02-21 09:00:00.0");
		platformCodeData1.put("mapping_status", "ENABLED");
		expectedBody.add(platformCodeData1);
		
		Mockito.when(namedParameterJdbcTemplate.queryForList(getAllPlatformQuery,
				mapSqlParameters)).thenReturn(expectedBody);
		
		List<Map<String,Object>> actualRepoUniversalCodes = platformCodeSetSQLDaoImpl.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null);

		assertNotNull(actualRepoUniversalCodes);
		assertEquals(1, actualRepoUniversalCodes.size());
	}
	
	@Test
	public void getAllPlatformCodesTest_shouldThrow_DaoException() {
		String codeSet = "comment";
		Integer page = null;
		Integer count = null;
		PlatformCodesMappingStatus filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String invalidGetAllPlatformQuery = "SELECTTTT comment_universal.universal_code,comment_universal.description, comment_universal.creation_date, comment_universal.last_updated, comment_universal.status FROM comment_universal ";
		
		Mockito.when(sqlQueryBuilder
				.buildPlatformRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction,null)).thenReturn(invalidGetAllPlatformQuery);
		
		MapSqlParameterSource mapSqlParameters = new MapSqlParameterSource();
		
		Mockito.when(sqlQueryBuilder
				.setPlatformRetrieveAllParameters(filter,null)).thenReturn(mapSqlParameters );
		String message="Application failed to query database.";
		Mockito.when(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR")).thenReturn(message);
		DaoException daoException = new DaoException(message,
				CtsErrorCode.INTERNAL_SERVER_ERROR);
		
		DataAccessException dataAccessException = new DataAccessException("Something went wrong") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
		};
		
		Mockito.when(namedParameterJdbcTemplate.queryForList(invalidGetAllPlatformQuery,
				mapSqlParameters)).thenThrow(dataAccessException);
		
		try {
			platformCodeSetSQLDaoImpl.getAllPlatformCodes(codeSet, page, count, filter, orderBy, direction,null);
		} catch (DaoException e) {
			assertEquals(daoException.getMessage(), e.getMessage());
		}
	}
	
	@Test
	public void getPlatformCodesRecordCountTest() {
		String codeSet = "comment";
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		
		String query = "SELECT COUNT(*) FROM comment_platform WHERE mapping_status =: mapping_status";
		
		Mockito.when(sqlQueryBuilder.buildPlatformRecordCountQuery(codeSet, filter,null)).thenReturn(query);
		
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource();
		sqlParameterSource.addValue("mapping_status", "ENABLED");
		
		Mockito.when(sqlQueryBuilder.setPlatformRetrieveAllParameters(filter,null)).thenReturn(sqlParameterSource);
		
		Mockito.when(namedParameterJdbcTemplate.queryForObject(query, sqlParameterSource, Integer.class)).thenReturn(1);
		
		int platformCodesRecordCount = platformCodeSetSQLDaoImpl.getPlatformCodesRecordCount(codeSet, filter,null);
		
		assertEquals(1, platformCodesRecordCount);
	}
	
	@Test
	public void getPlatformCodesCountByCodeSetAndUniversalCodeTest() {
		String codeSet = "comment";
		String universalCode = "ABC*1234";
		StatusEnum filter = StatusEnum.ENABLED;
		
		String query = "SELECT COUNT(*) FROM comment_platform WHERE mapping_status =: mapping_status";
		
		Mockito.when(sqlQueryBuilder.buildPlatformCodeRecordCountByCodeSetAndUniversalCodeQuery(codeSet, universalCode, filter)).thenReturn(query);
		
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource();
		sqlParameterSource.addValue("mapping_status", "ENABLED");
		
		Mockito.when(sqlQueryBuilder.setPlatformRetrieveByUniversalCodeIdParameters(universalCode, filter)).thenReturn(sqlParameterSource);
		
		Mockito.when(namedParameterJdbcTemplate.queryForObject(query, sqlParameterSource, Integer.class)).thenReturn(1);
		
		int platformCodesRecordCount = platformCodeSetSQLDaoImpl.getPlatformCodesCountByCodeSetAndUniversalCode(codeSet, universalCode, filter);
		
		assertEquals(1, platformCodesRecordCount);
	} 
	
	@Test
	public void getPlatFormCodeDataWithUniversalCodeDataSet_shouldReturnMappedData() {
		List<Map<String, String>> platformMappingList = new ArrayList<>();
		Map<String, String> mappingdata = new HashMap<>();
		mappingdata.put("universal_code", "CMN1*536*01");
		mappingdata.put("platform_code", "MDV2*536*5109");
		mappingdata.put("platform_identifier", "MDIV");
		mappingdata.put("mapping_status", "DISABLED");
		platformMappingList.add(mappingdata);

		String codeSet = "comment";
		Map<String, String> requestObject = platformMappingList.get(0);

		List<Map<String, String>> platformCodeData = new ArrayList<>();
		platformCodeData.add(requestObject);
   
		List<Map<String, Object>> dbObjectList = new ArrayList<>();
		Map<String, Object> platformDbObject = new HashMap<>();
		platformDbObject.put(TranslationServiceStringConstant.UNIVERSAL_CODE_ID_COLUMN, 10);
		platformDbObject.put(PLATFORM_CODE_FIELD, "MDV2*536*5109");
		platformDbObject.put(PLATFORM_IDENTIFIER_COLUMN, "MDIV");
		
		dbObjectList.add(platformDbObject);

		List<String> compositKeys = new ArrayList<>();
		compositKeys.add("platform_code");
		
		compositKeys.add("platform_identifier");
		
		String compositKeysCombination="MDV2*536*5109"+"MDIV";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		Mockito.when(sqlQueryBuilder.buildQueryToGetMappedPlatformCodeAndUniversalCode(codeSet, platformCodeData))
				.thenReturn("Query");
		Mockito.when(jdbcTemplate.queryForList( Mockito.eq("Query"))).thenReturn(dbObjectList);
		List<Map<String, Map<String, Object>>> actualData = platformCodeSetSQLDaoImpl.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet, platformMappingList);

		Map<String, Map<String, Object>> mappedDbDataWithCompositKeys=new HashMap<>(); 
		mappedDbDataWithCompositKeys.put(compositKeysCombination, platformDbObject);
		List<Map<String, Map<String, Object>>> mappedPlatformDbData= new ArrayList<>();
		mappedPlatformDbData.add(mappedDbDataWithCompositKeys);
		assertEquals(mappedDbDataWithCompositKeys.size(), actualData.size());
		actualData.forEach(data->{
			assertEquals(mappedDbDataWithCompositKeys.get(compositKeysCombination).size(), data.get(compositKeysCombination).size());
			assertEquals(platformDbObject,data.get(compositKeysCombination));
			assertEquals(compositKeysCombination,data.keySet().stream().collect(Collectors.joining("")));
		});
		
	}
	
	@Test
	public void getPlatFormCodeDataWithUniversalCodeDataSet_shouldReturnEmptyMappedData_ifException() {
		
		List<Map<String, String>> platformMappingList = new ArrayList<>();
		String codeSet = "comment";
		List<Map<String, String>> platformCodeData = new ArrayList<>();
		List<Map<String, Object>> dbObjectList = new ArrayList<>();
		Map<String, Object> platformDbObject = new HashMap<>();
		dbObjectList.add(platformDbObject);

		List<String> compositKeys = new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(compositKeys);
		Mockito.when(sqlQueryBuilder.buildQueryToGetMappedPlatformCodeAndUniversalCode(codeSet, platformCodeData))
				.thenReturn("Query");
		Mockito.when(jdbcTemplate.queryForList( Mockito.eq("Query"))).thenThrow(EmptyResultDataAccessException.class);
		List<Map<String, Map<String, Object>>> mappedDbDataWithCompositKeys=new ArrayList<>();
		List<Map<String, Map<String, Object>>> actualData=null;
		
		try {
			actualData = platformCodeSetSQLDaoImpl.getPlatFormCodeDataWithUniversalCodeDataSet(codeSet, platformMappingList);
		}catch(EmptyResultDataAccessException emptyResultDataAccessException){
			assertEquals(mappedDbDataWithCompositKeys,actualData);
		}
		
	}
	
	@Test
	public void getPlatformCodeDataByCode_shouldReturn_platformCodeData() throws DaoException {
		String codeSet = "comment";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "MDV2*536*5111");
		platformCodeData.put("platform_identifier", "MDIV"); 
		
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("universal_code", "PIL*RY4*HJ");
		dbObject.put("platform_code", "MDV2*536*5111");
		dbObject.put("platform_identifier", "MDIV");
		dbObject.put("last_updated", "2020-01-21 11:00:00.0");
		dbObject.put("creation_date", "2020-01-21 11:00:00.0");
		dbObject.put("mapping_status", "DISABLED");
		dbObject.put("universal_code_id", "15");
		dbObject.put("id", "1");
		
		Mockito.when(sqlQueryBuilder.buildPlatformDataRetrieveQuery(codeSet, platformCodeData)).thenReturn("Query");
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource();
		Mockito.when(sqlQueryBuilder.setPlatformDataRetrieveParameters(platformCodeData)).thenReturn(sqlParameterSource);
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.eq(sqlParameterSource))).thenReturn(dbObject);
		Map<String, Object> dbPlatformData=platformCodeSetSQLDaoImpl.getPlatformCodeDataByCode(codeSet, platformCodeData);
		assertNotNull(dbPlatformData);
		assertTrue(dbPlatformData.containsKey("id"));
		assertEquals("1",dbPlatformData.get("id"));
		assertEquals("PIL*RY4*HJ",dbPlatformData.get("universal_code"));
	}
	
	@Test
	public void getPlatformCodeDataByCode_shouldThrowException_IfNoDataFound()  { 
		String codeSet = "comment";
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "MDV2*536*5111");
		platformCodeData.put("platform_identifier", "MDIV"); 
		
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("universal_code", "PIL*RY4*HJ");
		dbObject.put("platform_code", "MDV2*536*5111");
		dbObject.put("platform_identifier", "MDIV");
		dbObject.put("last_updated", "2020-01-21 11:00:00.0");
		dbObject.put("creation_date", "2020-01-21 11:00:00.0");
		dbObject.put("mapping_status", "DISABLED");
		dbObject.put("universal_code_id", "15");
		dbObject.put("id", "1");
		
		Mockito.when(sqlQueryBuilder.buildPlatformDataRetrieveQuery(codeSet, platformCodeData)).thenReturn("Query");
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource();
		Mockito.when(sqlQueryBuilder.setPlatformDataRetrieveParameters(platformCodeData)).thenReturn(sqlParameterSource);
		Map<String, Object> dbPlatformData=null;
		String message="No Platform Codes found in database for the given Code Set.";
		Mockito.when(messageSourceUtil.getMessage("NO_PLATFORM_CODES_IN_DATABASE")).thenReturn(message); 
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.eq(sqlParameterSource))).thenThrow(EmptyResultDataAccessException.class);
		String exceptionMessage= "No Platform Codes found in database for the given Code Set.";
		DaoException daoException = new DaoException(exceptionMessage, CtsErrorCode.ENTITY_NOT_FOUND);;
		try {
			dbPlatformData=platformCodeSetSQLDaoImpl.getPlatformCodeDataByCode(codeSet, platformCodeData);
		}catch (DaoException e) {
			assertEquals(daoException.getMessage(),message);
			assertNull(dbPlatformData);
		}
		
	}
	 
}
