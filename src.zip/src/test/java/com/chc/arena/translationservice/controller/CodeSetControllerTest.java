/**
 * 
 */
package com.chc.arena.translationservice.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.chc.arena.translationservice.response.model.ApiResponse;

/**
 * @author narendra.dubey
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CodeSetControllerTest {
	
	@LocalServerPort
    int randomServerPort;
	
	@Autowired
	private TestRestTemplate restTemplate;

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.CodeSetController#getAll()}.
	 * @throws URISyntaxException 
	 */
	@Test
	public void testGetAll() throws URISyntaxException {
	     
	    final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets";
	    URI uri = new URI(baseUrl);
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(uri, ApiResponse.class);
	 
	    //Verify request succeed
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());
	    Assert.assertEquals("SUCCESS", serviceResult.getBody().getStatus().name());
	     
	    Assert.assertNotNull(serviceResult.getBody().getBody());
	    List<String> codeSets = (List<String>) serviceResult.getBody().getBody();
	    Assert.assertFalse(codeSets.isEmpty());
	}

}
