package com.chc.arena.translationservice.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.querybuilder.SolrQueryBuilder;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class CodeSetSolrDaoImplTest {

	@InjectMocks
	private CodeSetSolrDaoImpl codeSetSolrDaoImpl;
	
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Mock
	private SolrClient solrClient;
	
	@Mock
	private SolrQueryBuilder solrQueryBuilder;
	
	@Mock
	private MessageSourceUtil messageSourceUtil;
	
	private static String codeSet;
	
	private static final int SOLR_COMMIT_INTERVAL = 1;
	
	/**
	 * Setup.
	 */
	@BeforeClass
	public static void setup() {
		codeSet="Insurance";
		
	}
	
	@Test
	public void search_shouldReturnListOfCodeSets() throws DaoException, SolrServerException, IOException {
		SolrQuery solrQuery = new SolrQuery();
		solrQuery.setQuery("address_line1: 4th Street");
		SolrDocument solrDocument = new SolrDocument();
		solrDocument.setField("universal_code", "ABC*123");
		SolrDocumentList documentList = new SolrDocumentList();
		documentList.add(solrDocument);
		QueryResponse mockResponse = Mockito.mock(QueryResponse.class);
		
		Mockito.when(mockResponse.getResults()).thenReturn(documentList);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName("insurance")).thenReturn("insurance");
		Mockito.when(solrQueryBuilder.buildQueryForSearch(Mockito.anyString(), Mockito.anyMap(), Mockito.eq(null), Mockito.eq(null))).thenReturn(solrQuery);
		Mockito.when(solrClient.query(Mockito.anyString(), Mockito.any(SolrQuery.class))).thenReturn(mockResponse);
		
		List<Map<String, String>> listOfCodeSets = codeSetSolrDaoImpl.search("insurance", new HashMap<>(), null, null);
		
		assertEquals(1, listOfCodeSets.size());
		assertEquals("ABC*123", listOfCodeSets.get(0).get("universal_code"));
	}
	
	@Test
	public void search_shouldThrowDaoException_WhenSolrServerExceptionOccurs() throws DaoException, SolrServerException, IOException {
		SolrQuery solrQuery = new SolrQuery();
		solrQuery.setQuery("address_line1: 4th Street");
		String message= "Error in Search Service";
		Mockito.when(messageSourceUtil.getMessage("ERROR_IN_SEARCH_SERVICE")).thenReturn(message);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName("insurance")).thenReturn("insurance");
		Mockito.when(solrQueryBuilder.buildQueryForSearch(Mockito.anyString(), Mockito.anyMap(), Mockito.eq(null), Mockito.eq(null))).thenReturn(solrQuery);
		Mockito.when(solrClient.query(Mockito.anyString(), Mockito.any(SolrQuery.class))).thenThrow(new SolrServerException("Exception in Solr"));
		
		try {
			codeSetSolrDaoImpl.search("insurance", new HashMap<>(), null, null);
		} catch(DaoException daoException) {
			assertEquals(message, daoException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, daoException.getErrorCode());
		}
		
	}
	
	@Test
	public void search_shouldThrowDaoException_WhenIOExceptionOccurs() throws DaoException, SolrServerException, IOException {
		SolrQuery solrQuery = new SolrQuery();
		solrQuery.setQuery("address_line1: 4th Street");
		String message="Communication Error with Search Service";
		Mockito.when(messageSourceUtil.getMessage("COMMUNICATION_ERROR_WITH_SEARCH_SERVICE")).thenReturn(message);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName("insurance")).thenReturn("insurance");
		Mockito.when(solrQueryBuilder.buildQueryForSearch(Mockito.anyString(), Mockito.anyMap(), Mockito.eq(null), Mockito.eq(null))).thenReturn(solrQuery);
		Mockito.when(solrClient.query(Mockito.anyString(), Mockito.any(SolrQuery.class))).thenThrow(new IOException("Exception while Communicating"));
		
		try {
			codeSetSolrDaoImpl.search("insurance", new HashMap<>(), null, null);
		} catch(DaoException daoException) {
			assertEquals(message, daoException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, daoException.getErrorCode());
		}
		
	}
	
	@Test
	public void update_shouldUpdate() throws DaoException, SolrServerException, IOException {
		Map<String, Object> codeObject = new HashMap<String, Object>();
		codeObject.put("A", "B");
		codeObject.put("C", "D");
		ArgumentCaptor<SolrInputDocument> solrInputDocCaptor = ArgumentCaptor.forClass(SolrInputDocument.class);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet)).thenReturn("arena");
		Mockito.when(solrClient.add(Mockito.eq("arena"), Mockito.any(SolrInputDocument.class), Mockito.eq(SOLR_COMMIT_INTERVAL))).thenReturn(new UpdateResponse());
		codeSetSolrDaoImpl.update(codeSet, codeObject, new Date());
		
		Mockito.verify(solrClient).add(Mockito.eq("arena"), solrInputDocCaptor.capture(), Mockito.eq(SOLR_COMMIT_INTERVAL));
		SolrInputDocument solrInputDoc = solrInputDocCaptor.getValue();
		assertEquals("B", solrInputDoc.getFieldValue("A"));
		assertEquals("D", solrInputDoc.getFieldValue("C"));
		assertNotNull(solrInputDoc.getFieldValue(TranslationServiceStringConstant.LAST_UPDATED));
	}
	
	@Test
	public void update_shouldThrowDaoException_WhenSolrServerExceptionOccurs() throws DaoException, SolrServerException, IOException {
		Map<String, Object> codeObject = new HashMap<String, Object>();
		codeObject.put("A", "B");
		codeObject.put("C", "D");
		String message = "Error in Search Service";
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet)).thenReturn("arena");
		Mockito.when(messageSourceUtil.getMessage("ERROR_IN_SEARCH_SERVICE")).thenReturn(message);
		Mockito.when(solrClient.add(Mockito.eq("arena"), Mockito.any(SolrInputDocument.class), Mockito.eq(SOLR_COMMIT_INTERVAL))).thenThrow(new SolrServerException("Error on Solr"));
		try {
			codeSetSolrDaoImpl.update(codeSet, codeObject, new Date());
		} catch(DaoException daoException) {
			assertEquals(message, daoException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, daoException.getErrorCode());
		}
	}
	
	@Test
	public void update_shouldThrowDaoException_WhenIOExceptionOccurs() throws DaoException, SolrServerException, IOException {
		Map<String, Object> codeObject = new HashMap<String, Object>();
		codeObject.put("A", "B");
		codeObject.put("C", "D");
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet)).thenReturn("arena");
		String message= "Communication Error with Search Service";
		try {
			codeSetSolrDaoImpl.update(codeSet, codeObject, new Date());
		} catch(DaoException daoException) {
			assertEquals( message, daoException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, daoException.getErrorCode());
		}
	}
	
	@Test
	public void deleteCodeSetsDocument_shouldPerformDelete() throws DaoException {
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchCollectionName(codeSet)).thenReturn("arena");
		UpdateResponse response = codeSetSolrDaoImpl.deleteCodeSetsDocumentByUniversalCode(codeSet, "ABCD*1234");
		assertNotEquals(new UpdateResponse(), response);

	}

}
