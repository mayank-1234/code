package com.chc.arena.translationservice.dao.impl;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.querybuilder.SQLQueryBuilder;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Class UniversalCodeSetSQLDaoImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class UniversalCodeSetSQLDaoImplTest {

	/** The jdbc template. */
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Mock
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	/** The universal code set SQL dao impl. */
	@InjectMocks
	private UniversalCodeSetSQLDaoImpl universalCodeSetSQLDaoImpl;
	
	@Mock
	private SQLQueryBuilder sqlQueryBuilder;
	
	@Mock
	private MessageSourceUtil messageSourceUtil;
	
	
	/**
	 * Setup.
	 */
	@BeforeClass
	public static void setup() {
	}

	/**
	 * Setup this.
	 */
	@Before
	public void setupThis() {
	}

	/**
	 * Gets the all should return all universal codes with selected criteria.
	 *
	 * @return the all should return all universal codes with selected criteria
	 * @throws DaoException 
	 */
	@Test
	public void getAll_shouldReturnAllUniversalCodes_withSelectedCriteria() throws DaoException {
		String codeSet = "comment";
		Integer page = null;
		Integer count = null;
		StatusEnum filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String getAllUniversalQuery = "SELECT comment_universal.universal_code,comment_universal.description, comment_universal.creation_date, comment_universal.last_updated, comment_universal.status FROM comment_universal ";
		
		Mockito.when(sqlQueryBuilder
				.buildUniversalRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction)).thenReturn(getAllUniversalQuery);
		
		MapSqlParameterSource mapSqlParameters = new MapSqlParameterSource();
		
		Mockito.when(sqlQueryBuilder
				.setUniversalRetrieveAllParameters(filter)).thenReturn(mapSqlParameters );
		
		List<Map<String, Object>> repoUniversalCodes = new ArrayList<>();
		
		Map<String, Object> commentUniversalCode1 = new HashMap<>();
		commentUniversalCode1.put("universal-code", "ABC*123*HJ");
		commentUniversalCode1.put("description", "Comment code description");
		commentUniversalCode1.put("status", "ENABLED");
		commentUniversalCode1.put("creation_date", "2020-02-02 09:00:00");
		repoUniversalCodes.add(commentUniversalCode1);
		
		Mockito.when(namedParameterJdbcTemplate.queryForList(getAllUniversalQuery,
				mapSqlParameters)).thenReturn(repoUniversalCodes);
		
		List<Map<String,Object>> actualRepoUniversalCodes = universalCodeSetSQLDaoImpl.getAll(codeSet, page, count, filter, orderBy, direction);

		assertNotNull(actualRepoUniversalCodes);
		assertEquals(1, actualRepoUniversalCodes.size());
	}
	
	@Test
	public void getAll_shouldThrow_DaoException() {
		String codeSet = "comment";
		Integer page = null;
		Integer count = null;
		StatusEnum filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String invalidGetAllUniversalQuery = "SELECTTTT comment_universal.universal_code,comment_universal.description, comment_universal.creation_date, comment_universal.last_updated, comment_universal.status FROM comment_universal ";
		
		Mockito.when(sqlQueryBuilder
				.buildUniversalRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction)).thenReturn(invalidGetAllUniversalQuery);
		
		MapSqlParameterSource mapSqlParameters = new MapSqlParameterSource();
		
		Mockito.when(sqlQueryBuilder
				.setUniversalRetrieveAllParameters(filter)).thenReturn(mapSqlParameters );
		
		String message="Application failed to query database.";
		Mockito.when(messageSourceUtil.getMessage("INTERNAL_SERVER_ERROR")).thenReturn(message);
		
		
		DaoException daoException = new DaoException(message,
				CtsErrorCode.INTERNAL_SERVER_ERROR);
		
		DataAccessException dataAccessException = new DataAccessException("Something went wrong") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
		};
		
		Mockito.when(namedParameterJdbcTemplate.queryForList(invalidGetAllUniversalQuery,
				mapSqlParameters)).thenThrow(dataAccessException);
		
		try {
			universalCodeSetSQLDaoImpl.getAll(codeSet, page, count, filter, orderBy, direction);
		} catch (DaoException e) {
			assertEquals(daoException.getMessage(), e.getMessage());
		}
	}

	/**
	 * Gets the by id should return universal code based on id.
	 *
	 * @return the by id should return universal code based on id
	 */
	@Test
	public void getById_shouldReturnUniversalCode_basedOnId() {
		assertTrue(true);
	}

	/**
	 * Search should perform all seraches.
	 */
	@Test
	public void search_shouldPerformAllSeraches() {
		assertTrue(true);
	}

	/**
	 * Gets the mapped universal code should return universal by platform.
	 *
	 * @return the mapped universal code should return universal by platform
	 * @throws DaoException 
	 */
	@Test
	public void getMappedUniversalCode_shouldReturnUniversalByPlatform() throws DaoException {
		String codeSet = "transaction-code";
		Mockito.when(sqlQueryBuilder.buildUniversalMappedPlatformQuery(codeSet)).thenReturn("Query");		
		Map<String, String> platformCode = new HashMap<>();
		platformCode.put("platform-code", "ABCD*1234");
		platformCode.put("platform-identifier", "B");
		Mockito.when(sqlQueryBuilder.setUniversalAndPlatformMappingParameters(codeSet, platformCode)).thenReturn(new MapSqlParameterSource());
		
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("platform_code", "ABCD*1234");
		dbObject.put("platform_identifier", "B");
		dbObject.put("universal_identifier", "ABCD");
		
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenReturn(dbObject);
		
		Map<String, Object> actualObject = universalCodeSetSQLDaoImpl.getMappedUniversalCode(codeSet, platformCode);
		
		assertEquals("ABCD*1234", actualObject.get("platform_code"));
		assertEquals("B", actualObject.get("platform_identifier"));
		assertEquals("ABCD", actualObject.get("universal_identifier"));
	}
	
	@Test
	public void getMappedUniversalCode_shouldThrowDaoExceptionWhenPlatformObjectNotFound() throws DaoException {
		String codeSet = "transaction-code";
		Mockito.when(sqlQueryBuilder.buildUniversalMappedPlatformQuery(codeSet)).thenReturn("Query");		
		Map<String, String> platformCode = new HashMap<>();
		platformCode.put("platform-code", "ABCD*1234");
		platformCode.put("platform-identifier", "B");
		Mockito.when(sqlQueryBuilder.setUniversalAndPlatformMappingParameters(codeSet, platformCode)).thenReturn(new MapSqlParameterSource());
		
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenThrow(EmptyResultDataAccessException.class);
		String message= "Platform Code & Platform Identifier combination doesn't exists.";
		Mockito.when(messageSourceUtil.getMessage("PLATFORM_CODE_IDENTIFIER_NOT_FOUND")).thenReturn(message);
		try {
			universalCodeSetSQLDaoImpl.getMappedUniversalCode(codeSet, platformCode);
		} catch(DaoException daoException) {
			assertEquals(message, daoException.getMessage());
			assertEquals(CtsErrorCode.ENTITY_NOT_FOUND, daoException.getErrorCode());
		}
		
	}
	
	@Test
	public void getByUniversalCode_ShouldReturnUniversalCode() throws DaoException {
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("A", "B");
		
		Mockito.when(sqlQueryBuilder.buildUniversalRetrieveQuery("comment")).thenReturn("Query");
		Mockito.when(sqlQueryBuilder.setUniversalRetrieveParameters("ABCD*1234")).thenReturn(new MapSqlParameterSource());
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenReturn(dbObject);
		
		Map<String, Object> actualObject = universalCodeSetSQLDaoImpl.getByUniversalCode("comment", "ABCD*1234");
		assertEquals("B", actualObject.get("A"));
		Mockito.verify(namedParameterJdbcTemplate).queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class));
	}
	
	@Test
	public void getByUniversalCode_ShouldThrowDaoException_WhenUniversalCodeObjectNotFound() throws DaoException {
		Map<String, Object> dbObject = new HashMap<>();  
		dbObject.put("A", "B");
		
		Mockito.when(sqlQueryBuilder.buildUniversalRetrieveQuery("comment")).thenReturn("Query");
		Mockito.when(sqlQueryBuilder.setUniversalRetrieveParameters("ABCD*1234")).thenReturn(new MapSqlParameterSource());
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenThrow(EmptyResultDataAccessException.class);
		String message="Provided Universal Code does not exists.";
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_NOT_FOUND")).thenReturn(message);
		try {
			universalCodeSetSQLDaoImpl.getByUniversalCode("comment", "ABCD*1234");
		} catch(DaoException daoException) {
			assertEquals(message, daoException.getMessage());
			assertEquals(CtsErrorCode.ENTITY_NOT_FOUND, daoException.getErrorCode());
		}
	}

	/**
	 * Insert should verify addition of universal codes.
	 */
	@Test
	public void insert_shouldVerify_additionOfUniversalCodes() {
		assertTrue(true);
	}

	@Test
	public void update_ShouldVerifyUpdationOfUniversalCodes() {
		Map<String, String> universalCodeObject = new HashMap<>();
		universalCodeObject.put("A", "B");
		Mockito.when(sqlQueryBuilder.buildUniversalUpdateQuery(Mockito.eq("comment"), Mockito.anyMap())).thenReturn("Query");
		Mockito.when(sqlQueryBuilder.setUniversalUpdateParameters(Mockito.eq("comment"), Mockito.anyMap(), Mockito.eq("ABCD*1234"), Mockito.any(Date.class))).thenReturn(new MapSqlParameterSource());
		
		universalCodeSetSQLDaoImpl.update("comment", universalCodeObject, "ABCD*1234", new Date());
		
		Mockito.verify(namedParameterJdbcTemplate).update(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class));
	}
	
	@Test
	public void insert_ShouldVerifyInsertionOfUniversalCodes() throws DaoException {
		Map<String, String> universalCodeObject = new HashMap<>();
		String codeSet="insurance";
		Date date = new Date();
		Mockito.when(sqlQueryBuilder.buildUniversalInsertQuery(Mockito.eq(codeSet), Mockito.anyMap())).thenReturn("Query");
		Mockito.when(sqlQueryBuilder.setUniversalInsertParameters(Mockito.eq(universalCodeObject), Mockito.eq(date))).thenReturn(new MapSqlParameterSource());
		universalCodeSetSQLDaoImpl.insert(codeSet, universalCodeObject,date);
		Mockito.verify(namedParameterJdbcTemplate).update(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class));
	}
	
	/**
	 * Delete should verify deletion of universal codes.
	 */
	@Test
	public void delete_shouldVerify_deletionOfUniversalCodes() {
		assertTrue(true);
	}
	
	@Test
	public void getUniversalCodeRecordsToVerifyStatus_shoulReturnNullIfExceptionisThrown(){
		Map<String, String> platformData = new HashMap<>();
		Map<String, Object> dbObject=null;
		try {   
			Mockito.when(universalCodeSetSQLDaoImpl.getByUniversalCode("comment", "ABCD*1234")).thenThrow(EmptyResultDataAccessException.class);
			dbObject=universalCodeSetSQLDaoImpl.getUniversalCodeRecordsToVerifyStatus("comment", platformData);
		}catch(DaoException exception) {
			assertNull(dbObject);
		}
		
	}

	@Test
	public void getById_ShouldReturnUniversalCode() throws DaoException {
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("A", "B");
		Mockito.when(sqlQueryBuilder.buildUniversalRetrieveQueryById("comment")).thenReturn("Query");
		Mockito.when(sqlQueryBuilder.setUniversalRetrieveParametersById("12")).thenReturn(new MapSqlParameterSource());
		Mockito.when(namedParameterJdbcTemplate.queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class))).thenReturn(dbObject);
		Map<String, Object> actualObject = universalCodeSetSQLDaoImpl.getById("comment", "12");
		assertEquals("B", actualObject.get("A"));
		Mockito.verify(namedParameterJdbcTemplate).queryForMap(Mockito.eq("Query"), Mockito.any(MapSqlParameterSource.class));
	}
	
	
	
}
