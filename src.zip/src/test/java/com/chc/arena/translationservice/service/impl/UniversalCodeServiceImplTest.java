package com.chc.arena.translationservice.service.impl;


import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.dao.CodeSetSolrDao;
import com.chc.arena.translationservice.dao.impl.PlatformCodeSetSQLDaoImpl;
import com.chc.arena.translationservice.dao.impl.UniversalCodeSetSQLDaoImpl;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.DaoException;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.util.MessageSourceUtil;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

import ch.qos.logback.core.db.dialect.MsSQLDialect;

@RunWith(MockitoJUnitRunner.class)
public class UniversalCodeServiceImplTest {

	@InjectMocks
	private UniversalCodeServiceImpl universalCodeServiceImpl;
	
	@Mock
	private UniversalCodeSetSQLDaoImpl universalCodeSetSQLDao;
	
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	@Mock
	private PlatformCodeSetSQLDaoImpl platformCodeSetSQLDaoImpl;
	
	@Mock
	private CodeSetSolrDao codeSetSolrDao;
	
	@Mock
	private MessageSourceUtil messageSourceUtil;
	
	private String codeSet = "transaction-code";
	private String[] columns = {"description", "last_updated"};
	private String universalCode = "ABCD*1234";
	private Map<String, Object> dbObject = new HashMap<>();
	private List<String> advancedSearchEnabledCodeSets = new ArrayList<>();
	Date currentDateTimeStamp =null;
	@Before
	public void init() {
		dbObject.put("A", "B");
		advancedSearchEnabledCodeSets.add("comment");
		currentDateTimeStamp = new Date();
	}
	
	@Test
	public void getMappedUniversalCode_ShouldReturnUniversalCode() throws DaoException, ServiceException {
		Map<String, String> platformCodeObject = new HashMap<>();
		platformCodeObject.put("platform_code", "A");
		platformCodeObject.put("platform_identifier", "B");
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("mapping_status", "ENABLED");
		dbObject.put("universal_code_id", 2);
		dbObject.put("description", "Hello");
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(Arrays.asList(columns));
		Mockito.when(universalCodeSetSQLDao.getMappedUniversalCode(codeSet, platformCodeObject)).thenReturn(dbObject);
		String message= "Returning mapped Universal Code for the given Platform Code.";
		Mockito.when(messageSourceUtil.getMessage("MAPPED_UNIVERSAL_CODES_FOUND")).thenReturn(message);
		ServiceResponse<Map<String, String>> serviceResponse = universalCodeServiceImpl.getMappedUniversalCode(codeSet, platformCodeObject);
		
		assertEquals("Hello", serviceResponse.getBody().get("description"));
		assertEquals(2, serviceResponse.getBody().size());
		
		assertEquals(message, serviceResponse.getMessage());
	}
	
	@Test
	public void getMappedUniversalCode_ShouldReturnUniversalCode_WithNullColumns() throws DaoException, ServiceException {
		Map<String, String> platformCodeObject = new HashMap<>();
		platformCodeObject.put("platform_code", "A");
		platformCodeObject.put("platform_identifier", "B");
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("mapping_status", "ENABLED");
		dbObject.put("universal_code_id", 2);
		dbObject.put("description", "Hello");
		dbObject.put("last_updated", null);
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(Arrays.asList(columns));
		Mockito.when(universalCodeSetSQLDao.getMappedUniversalCode(codeSet, platformCodeObject)).thenReturn(dbObject);
		String message= "Returning mapped Universal Code for the given Platform Code.";
		Mockito.when(messageSourceUtil.getMessage("MAPPED_UNIVERSAL_CODES_FOUND")).thenReturn(message);
		
		ServiceResponse<Map<String, String>> serviceResponse = universalCodeServiceImpl.getMappedUniversalCode(codeSet, platformCodeObject);
		
		assertEquals("Hello", serviceResponse.getBody().get("description"));
		assertEquals(2, serviceResponse.getBody().size());
		
		assertEquals(message, serviceResponse.getMessage());
	}
	
	@Test
	public void getMappedUniversalCode_ShouldReturnNullBodyWithMessage_WhenPlatformCodeMappingIsDisabled() throws DaoException, ServiceException {
		Map<String, String> platformCodeObject = new HashMap<>();
		platformCodeObject.put("platform_code", "A");
		platformCodeObject.put("platform_identifier", "B");
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("mapping_status", "DISABLED");
		dbObject.put("universal_code_id", 2);
		dbObject.put("description", "Hello");
		Mockito.when(universalCodeSetSQLDao.getMappedUniversalCode(codeSet, platformCodeObject)).thenReturn(dbObject);
		String messsage="Platform Code & Platform Identifier combination exists but, mapping is disabled";
		Mockito.when(messageSourceUtil.getMessage("PLATFORM_CODE_DISABLED_MAPPING")).thenReturn(messsage);
		ServiceResponse<Map<String, String>> serviceResponse = universalCodeServiceImpl.getMappedUniversalCode(codeSet, platformCodeObject);
		assertEquals(messsage, serviceResponse.getMessage());
		assertNull(serviceResponse.getBody());
	}
	
	@Test
	public void getMappedUniversalCode_ShouldReturnNullBodyWithMessage_WhenPlatformCodeIsUnMapped() throws DaoException, ServiceException {
		Map<String, String> platformCodeObject = new HashMap<>();
		platformCodeObject.put("platform_code", "A");
		platformCodeObject.put("platform_identifier", "B"); 
		Map<String, Object> dbObject = new HashMap<>();
		dbObject.put("universal_code_id", null);
		dbObject.put("description", "Hello");
		Mockito.when(universalCodeSetSQLDao.getMappedUniversalCode(codeSet, platformCodeObject)).thenReturn(dbObject);
		String messsage="Platform Code & Platform Identifier combination exists, but is not mapped.";
		Mockito.when(messageSourceUtil.getMessage("PLATFORM_CODE_UNMAPPED")).thenReturn(messsage);
		ServiceResponse<Map<String, String>> serviceResponse = universalCodeServiceImpl.getMappedUniversalCode(codeSet, platformCodeObject);
		assertEquals(messsage, serviceResponse.getMessage());
		assertNull(serviceResponse.getBody());
	}
	
	@Test
	public void getMappedUniversalCode_ShouldThrowServiceException_WhenUniversalCodeDoesntExists() throws DaoException, ServiceException {
		Map<String, String> platformCodeObject = new HashMap<>();
		platformCodeObject.put("platform_code", "A");
		platformCodeObject.put("platform_identifier", "B");
		Mockito.when(universalCodeSetSQLDao.getMappedUniversalCode(codeSet, platformCodeObject)).thenThrow(new DaoException("ERR", CtsErrorCode.ENTITY_NOT_FOUND));
		
		try {
			universalCodeServiceImpl.getMappedUniversalCode(codeSet, platformCodeObject);
		} catch(ServiceException serviceException) {
			assertEquals("ERR", serviceException.getMessage());
			assertEquals(CtsErrorCode.ENTITY_NOT_FOUND, serviceException.getErrorCode());
			assertEquals("A", serviceException.getErrorDetails().getIssues().get("ERR").get("platform_code"));
			assertEquals("B", serviceException.getErrorDetails().getIssues().get("ERR").get("platform_identifier"));
		}
		
	}

	@Test
	public void update_shouldUpdateOnlyUniversalCode() throws DaoException, ServiceException {
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeData.put("A", "C");
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(dbObject);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets()).thenReturn(advancedSearchEnabledCodeSets);
		String updateMessage="Universal Code updated successfully";
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_UPDATED_SUCCESSFULLY")).thenReturn(updateMessage);
		
		String message = universalCodeServiceImpl.update(codeSet, universalCode, universalCodeData);
		
		assertEquals(updateMessage, message);
	}
	
	@Test
	public void update_shouldThrowServiceException_WhenUniversalCodeObjectNotFound() throws DaoException, ServiceException {
		dbObject.put("id", 1);
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeData.put("A", "C");
		universalCodeData.put("status", "DISABLED");
		String message="Provided Universal Code does not exists.";
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenThrow(new DaoException(message, CtsErrorCode.ENTITY_NOT_FOUND));
		
		try {
			universalCodeServiceImpl.update(codeSet, universalCode, universalCodeData);
		} catch(ServiceException serviceException) {
			assertEquals(message, serviceException.getMessage());
			assertEquals(CtsErrorCode.ENTITY_NOT_FOUND, serviceException.getErrorCode());
		}
		
	}
	
	@Test
	public void update_shouldUpdateOnlyUniversalCode_WhenStatusIsSameinDbAndRequest() throws DaoException, ServiceException {
		dbObject.put("status", "ENABLED");
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeData.put("A", "C");
		universalCodeData.put("status", "ENABLED");
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(dbObject);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets()).thenReturn(advancedSearchEnabledCodeSets);
		String updateMessage="Universal Code updated successfully";
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_UPDATED_SUCCESSFULLY")).thenReturn(updateMessage);
		String message = universalCodeServiceImpl.update(codeSet, universalCode, universalCodeData);
		
		assertEquals(updateMessage, message);
	}
	
	@Test
	public void update_shouldUpdateUniversalCodeAndAssociatedPlatformCodes_WhenStatusIsDifferentInDbAndRequest() throws DaoException, ServiceException {
		dbObject.put("status", "ENABLED");
		dbObject.put("id", 1);
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeData.put("A", "C");
		universalCodeData.put("status", "DISABLED");
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(dbObject);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets()).thenReturn(advancedSearchEnabledCodeSets);
		Mockito.when(platformCodeSetSQLDaoImpl.disableEnablePlatformCodesMappedToUniversalCode(Mockito.eq(codeSet), Mockito.eq(universalCodeData.get(TranslationServiceStringConstant.STATUS)), Mockito.eq((int) dbObject.get("id")), Mockito.any(Date.class))).thenReturn(5);
		
		String updateMessage= "Universal Code updated & %s successfully. %s mapping status for %d associated Platform Code(s).";
		
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_UPDATED_ALONG_WITH_PLATFORM_CODES")).thenReturn(updateMessage);
		String message = universalCodeServiceImpl.update(codeSet, universalCode, universalCodeData);
		
		assertEquals(String.format(updateMessage, universalCodeData.get(TranslationServiceStringConstant.STATUS), 
				universalCodeData.get(TranslationServiceStringConstant.STATUS), 5), message);
	}
	
	@Test
	public void update_shouldUpdateUniversalCodeAndSolrDoc_WhenCodeIsAdvancedSearchEnabled() throws DaoException, ServiceException {
		dbObject.put("status", "ENABLED");
		dbObject.put("id", 1);
		advancedSearchEnabledCodeSets.add(codeSet);
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeData.put("A", "C");
		universalCodeData.put("status", "DISABLED");
		
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(dbObject);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets()).thenReturn(advancedSearchEnabledCodeSets);
		String updateMessage="Universal Code updated successfully";
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_UPDATED_SUCCESSFULLY")).thenReturn(updateMessage);
		String message = universalCodeServiceImpl.update(codeSet, universalCode, universalCodeData);
		
		
		assertEquals(updateMessage, message);
		Mockito.verify(codeSetSolrDao).update(Mockito.eq(codeSet), Mockito.anyMap(), Mockito.any(Date.class));
	}
	
	@Test
	public void update_shouldThrowServiceException_WhenSolrThrowsDaoException() throws DaoException, ServiceException {
		dbObject.put("status", "ENABLED");
		dbObject.put("id", 1);
		advancedSearchEnabledCodeSets.add(codeSet);
		Map<String, String> universalCodeData = new HashMap<>();
		universalCodeData.put("A", "C");
		universalCodeData.put("status", "DISABLED");
		String message= "Error in Search Service";
		Mockito.when(codeSetSolrDao.update(Mockito.eq(codeSet), Mockito.anyMap(), Mockito.any(Date.class))).thenThrow(new DaoException(message, CtsErrorCode.INTERNAL_SERVER_ERROR));
		Mockito.when(universalCodeSetSQLDao.getByUniversalCode(codeSet, universalCode)).thenReturn(dbObject);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchEnabledCodeSets()).thenReturn(advancedSearchEnabledCodeSets);
		
		try {
			universalCodeServiceImpl.update(codeSet, universalCode, universalCodeData);
		} catch(ServiceException serviceException) {
			assertEquals(message, serviceException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, serviceException.getErrorCode());
		}
		
	}
	
	
	@Test
	public void insert_shouldInsertUniversalCode() throws DaoException, ServiceException {
		Map<String, String> universalCodeData = new HashMap<>();
		String message= "Universal Code inserted successfully";
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_INSERTED_SUCCESSFULLY")).thenReturn(message);
		String actualMessage= universalCodeServiceImpl.insert(codeSet, universalCodeData);
		assertEquals(message, actualMessage);
	}
	
	
	@Test
	public void insert_shouldThrowServiceException_WhenUniversalCodeObjectAlreadyExist() throws DaoException, ServiceException {
		Map<String, String> universalCodeData = new HashMap<>();
		String message=  "Universal Code already exist for the given code-set category ";;
		try {
			universalCodeServiceImpl.insert(codeSet, universalCodeData);
		} catch(ServiceException serviceException) {
			assertEquals(message, serviceException.getMessage());
			assertEquals(CtsErrorCode.UNIVERSAL_CODE_ALREADY_EXIST, serviceException.getErrorCode());
		}
	}
	
	@Test
	public void insert_shouldInsertUniversalCodeAndSolrDoc_WhenCodeSetIsAdvancedSearchEnabled() throws DaoException, ServiceException {
		codeSet="insurance";
		String message= "Universal Code inserted successfully";
		advancedSearchEnabledCodeSets.add(codeSet);
		Map<String, String> universalCodeData = new HashMap<>();
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODE_INSERTED_SUCCESSFULLY")).thenReturn(message);
		Mockito.when(universalCodeSetSQLDao.insert(Mockito.eq(codeSet), Mockito.eq(universalCodeData),Mockito.any(Date.class))).thenReturn(1);
		Mockito.when(codeSetMetaDataUtil.isAdvancedSearchEnabledCodeSet(codeSet)).thenReturn(true);
		String actualMessage=universalCodeServiceImpl.insert(codeSet, universalCodeData);
		assertEquals(message, actualMessage);
		Mockito.verify(codeSetSolrDao).insert(Mockito.eq(codeSet), Mockito.anyMap());
	}
	
	@Test
	public void insert_shouldThrowServiceException_WhenSolrThrowsDaoException() throws DaoException, ServiceException {
		codeSet="insurance";
		advancedSearchEnabledCodeSets.add(codeSet);
		Map<String, String> universalCodeData = new HashMap<>();
		String message= "Error in Search Service";
		try {
			universalCodeServiceImpl.insert(codeSet, universalCodeData);
		} catch(ServiceException serviceException) {
			assertEquals(message, serviceException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, serviceException.getErrorCode());
		}
	}
	
	@Test
	public void search_ShouldReturnServiceResponse_WhenMatchingRecordsAreFound() throws DaoException, ServiceException  {
		List<Map<String, String>> list = new ArrayList<>();
		Map<String, String> solrObject= new HashMap<>();
		list.add(solrObject);
		solrObject.put("universal_code", "123");
		Mockito.when(codeSetSolrDao.search(Mockito.eq(codeSet), Mockito.anyMap(), Mockito.eq(null), Mockito.eq(null))).thenReturn(list);
		Map<String, String> universalCodeData = new HashMap<>();
		String message= "Returing list of matching records with matching score, for requested criteria";
		Mockito.when(messageSourceUtil.getMessage("MATCHING_RECORDS_FOUND")).thenReturn(message);
		ServiceResponse<List<Map<String, String>>> serviceResponse = universalCodeServiceImpl.search(codeSet, universalCodeData, null, null);
		
		assertEquals( "123", serviceResponse.getBody().get(0).get("universal_code"));
		assertEquals(message, serviceResponse.getMessage());
	}
	
	@Test
	public void search_ShouldReturnServiceResponse_WhenMatchingRecordsAreNotFound() throws DaoException, ServiceException  {
		Mockito.when(codeSetSolrDao.search(Mockito.eq(codeSet), Mockito.anyMap(), Mockito.eq(null), Mockito.eq(null))).thenReturn(new ArrayList<>());
		Map<String, String> universalCodeData = new HashMap<>();
		String message= "No matching records found for requested criteria";
		Mockito.when(messageSourceUtil.getMessage("NO_MATCHING_RECORD_FOUND")).thenReturn(message);
		ServiceResponse<List<Map<String, String>>> serviceResponse = universalCodeServiceImpl.search(codeSet, universalCodeData, null, null);
		assertEquals(message, serviceResponse.getMessage());
	}
	
	@Test
	public void getAllUniversalCodes_Success() throws DaoException, ServiceException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		StatusEnum filter = StatusEnum.ENABLED;
		String orderBy = null;
		Direction direction = null;
		
		List<Map<String, Object>> repoUniversalCodes = new ArrayList<>();
		
		Map<String, Object> commentUniversalCode1 = new HashMap<>();
		commentUniversalCode1.put("universal-code", "ABC*123*HJ");
		commentUniversalCode1.put("description", "Comment code description");
		commentUniversalCode1.put("status", "ENABLED");
		commentUniversalCode1.put("creation_date", "2020-02-02 09:00:00");
		repoUniversalCodes.add(commentUniversalCode1);
		
		Mockito.when(messageSourceUtil.getMessage("UNIVERSAL_CODES_IN_DATABASE")).thenReturn("Returning Universal Codes");
		Mockito.when(universalCodeSetSQLDao.getAll(codeSet, page, count, filter, orderBy, direction)).thenReturn(repoUniversalCodes);
		
		ServiceResponse<List<Map<String,String>>> universalCodesServiceResponse = universalCodeServiceImpl.getAllUniversalCodes(codeSet, page, count, filter, orderBy, direction);
		
		List<Map<String, String>> responseBody = universalCodesServiceResponse.getBody();
		String responseMessage = universalCodesServiceResponse.getMessage();
		
		assertEquals("Returning Universal Codes", responseMessage);
		assertNotNull(responseBody);
		assertEquals(1, responseBody.size());		
	}
	
	@Test
	public void getAllUniversalCodes_Success_EmptyBody() throws DaoException, ServiceException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		StatusEnum filter = StatusEnum.ENABLED;
		String orderBy = null;
		Direction direction = null;
		
		List<Map<String, Object>> repoUniversalCodes = new ArrayList<>();
		
		Mockito.when(messageSourceUtil.getMessage("NO_UNIVERSAL_CODES_IN_DATABASE")).thenReturn("No Universal Codes");
		Mockito.when(universalCodeSetSQLDao.getAll(codeSet, page, count, filter, orderBy, direction)).thenReturn(repoUniversalCodes);
		
		ServiceResponse<List<Map<String,String>>> universalCodesServiceResponse = universalCodeServiceImpl.getAllUniversalCodes(codeSet, page, count, filter, orderBy, direction);
		
		List<Map<String, String>> responseBody = universalCodesServiceResponse.getBody();
		String responseMessage = universalCodesServiceResponse.getMessage();
		
		assertEquals("No Universal Codes", responseMessage);
		assertNotNull(responseBody);
		assertEquals(0, responseBody.size());		
	}
	
	@Test
	public void getAllUniversalCodes_Failure_DaoException() throws DaoException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		StatusEnum filter = StatusEnum.ENABLED;
		String orderBy = null;
		Direction direction = null;
		
		String message="Application failed to query database.";
		
		DaoException daoException = new DaoException(message,
				CtsErrorCode.INTERNAL_SERVER_ERROR);
		
		Mockito.when(universalCodeSetSQLDao.getAll(codeSet, page, count, filter, orderBy, direction)).thenThrow(daoException);
		
		try {
			universalCodeServiceImpl.getAllUniversalCodes(codeSet, page, count, filter, orderBy, direction);
		} catch (ServiceException serviceException) {
			assertEquals(message, serviceException.getMessage());
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, serviceException.getErrorCode());
		}		
	}
	
	@Test
	public void search_ShouldThrowServicException_WhenDaoExceptionIsThrown() throws DaoException, ServiceException  {
		Mockito.when(codeSetSolrDao.search(Mockito.eq(codeSet), Mockito.anyMap(), Mockito.eq(null), Mockito.eq(null))).thenThrow(new DaoException("Solr server unavailable", CtsErrorCode.INTERNAL_SERVER_ERROR));
		Map<String, String> universalCodeData = new HashMap<>();
		
		try {
			ServiceResponse<List<Map<String, String>>> serviceResponse = universalCodeServiceImpl.search(codeSet, universalCodeData, null, null);
		} catch(ServiceException serviceException) {
			assertEquals(CtsErrorCode.INTERNAL_SERVER_ERROR, serviceException.getErrorCode());
			assertEquals("Solr server unavailable", serviceException.getMessage());
		}
	}
}
