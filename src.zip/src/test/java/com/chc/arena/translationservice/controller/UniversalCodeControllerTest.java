/**
 * 
 */
package com.chc.arena.translationservice.controller;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.response.model.ApiError;
import com.chc.arena.translationservice.response.model.ApiResponse;
import com.chc.arena.translationservice.response.model.ApiStatus;
import com.chc.arena.translationservice.response.model.ServiceResponse;
import com.chc.arena.translationservice.response.model.SubError;
import com.chc.arena.translationservice.service.exception.CtsErrorCode;
import com.chc.arena.translationservice.service.exception.ServiceException;
import com.chc.arena.translationservice.service.impl.UniversalCodeServiceImpl;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;

/**
 * The Class UniversalCodeControllerTest.
 *
 * @author narendra.dubey
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class UniversalCodeControllerTest {
	
	@LocalServerPort
    int randomServerPort;
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	@MockBean
	private UniversalCodeServiceImpl universalCodeServiceImpl;

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.UniversalCodeController#getAll(java.lang.String, java.lang.Integer, java.lang.Integer, com.chc.arena.translationservice.validation.annotation.StatusEnum)}.
	 * @throws URISyntaxException 
	 * @throws ServiceException 
	 */
	@Test
	public void testGetAll_Sucess() throws URISyntaxException, ServiceException {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		StatusEnum filter = StatusEnum.ENABLED;
		String orderBy = "universal-code";
		Direction direction = Direction.ASC;
		Map<String, Object> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		urlVariables.put("page", String.valueOf(page));
		urlVariables.put("count", String.valueOf(count));
		urlVariables.put("status", filter.name());
		urlVariables.put("orderBy", orderBy);
		urlVariables.put("direction", direction);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes?page={page}&count={count}&status={status}&orderBy={orderBy}&direction={direction}";
		
		List<Map<String,String>> expectedUniversalCodes = new ArrayList<>();
		
		Map<String, String> commentUniversalCode1 = new HashMap<>();
		commentUniversalCode1.put("universal-code", "ABC*123*HJ");
		commentUniversalCode1.put("description", "Comment code description");
		commentUniversalCode1.put("status", "ENABLED");
		commentUniversalCode1.put("creation_date", "2020-02-02 09:00:00");
		expectedUniversalCodes.add(commentUniversalCode1);
		
		
		String message="Returning Universal Codes for the given Code Set.";
		 ServiceResponse<List<Map<String,String>>> mockedServiceResponse = new
		 ServiceResponse<List<Map<String,String>>>(message,expectedUniversalCodes);
		 
		
		Mockito.when(universalCodeServiceImpl.getAllUniversalCodes(codeSet, page, count, filter, orderBy, direction)).thenReturn(mockedServiceResponse);
		
		Mockito.when(universalCodeServiceImpl.getUniversalCodesRecordCount(codeSet, filter)).thenReturn(1);
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    HttpHeaders headers = serviceResult.getHeaders();
	    Set<String> keySet = headers.keySet();
	    Assert.assertEquals(true, keySet.contains("totalRecordsCount"));
	    Assert.assertEquals(true, keySet.contains("totalPages"));
	    Assert.assertEquals(true, keySet.contains("hasNextPage"));
	    Assert.assertEquals(true, keySet.contains("hasPreviousPage"));
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());
	    Assert.assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void testGetAll_ValidationError_InvalidPaging() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment";
		Integer page = -1;
		Integer count = -1;
		StatusEnum filter = StatusEnum.ENABLED;
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		urlVariables.put("page", String.valueOf(page));
		urlVariables.put("count", String.valueOf(count));
		urlVariables.put("filter", filter.name());
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes?page={page}&count={count}&filter={filter}";
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    ApiError apiError = responseBody.getApiError();
	    List<SubError> subErrors = apiError.getSubErrors();
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertNotNull(serviceResult.getBody().getApiError());
	    Assert.assertNotNull(subErrors);
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}
	
	@Test
	public void testGetAll_ValidationError_InvalidCodeSet() throws URISyntaxException, ServiceException {
		
		String codeSet = "comment1";
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", codeSet);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes";
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    ApiResponse responseBody = serviceResult.getBody();
	    ApiError apiError = responseBody.getApiError();
	    List<SubError> subErrors = apiError.getSubErrors();
	    SubError subError = subErrors.get(0);
	    Assert.assertTrue(subError.getRejectedValue().containsKey("code-set"));
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertNotNull(serviceResult.getBody().getApiError());
	    Assert.assertNotNull(subErrors);
	    Assert.assertEquals("Error occurred while processing the request. URI Path: /code-sets/comment1/universal-codes", responseBody.getMessage());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	}

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.UniversalCodeController#getByCode(java.lang.String, java.lang.String)}.
	 * @throws ServiceException 
	 */
	@Test
	public void testGetByCode() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		String codeSet="insurance";
		String universalCode="PIL*344*YT";
		urlVariables.put("code-set", codeSet);
		urlVariables.put("universal-code", universalCode);
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
	    
		Map<String, String> commentUniversalCode = new HashMap<>();
		commentUniversalCode.put("universal-code", "ABC*123*HJ");
		commentUniversalCode.put("description", "Comment code description");
		commentUniversalCode.put("status", "ENABLED");
		commentUniversalCode.put("creation_date", "2020-02-02 09:00:00");
		String message="Returning Universal Codes for the given Code Set.";

		ServiceResponse<Map<String,String>> mockedServiceResponse = new ServiceResponse<>(message, commentUniversalCode);
		Mockito.when(universalCodeServiceImpl.getByCode(codeSet, universalCode)).thenReturn(mockedServiceResponse);
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.getForEntity(baseUrl, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());
	    Assert.assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	}

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.UniversalCodeController#search(java.lang.String, java.util.Map)}.
	 */
	@Test
	public void testSearch_ShouldReturnBadRequest_WhenCodeSetIsInvalid() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance1");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/search";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform-code", "PLA*123*CD");
		platformCodeData.put("insurance-type", "GROUP INSURANCE");
		platformCodeData.put("incurance-name", "Great West");
		platformCodeData.put("addr1", "841 Nichols Ave.");
		platformCodeData.put("addr2", "Mechanic Rd.");
		platformCodeData.put("city", "Spring Valley");
		platformCodeData.put("state", "CA");
		platformCodeData.put("zipcode", "91977");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    String message="Invalid Code Set in Request URL";
	    Assert.assertEquals(message, serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("insurance1", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("code-set"));
	}
	
	@Test
	public void testSearch_ShouldReturnBadRequest_WhenCodeSetDoesntSupportAdvancedSearch() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/search";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform-code", "PLA*123*CD");
		platformCodeData.put("insurance-type", "GROUP INSURANCE");
		platformCodeData.put("incurance-name", "Great West");
		platformCodeData.put("addr1", "841 Nichols Ave.");
		platformCodeData.put("addr2", "Mechanic Rd.");
		platformCodeData.put("city", "Spring Valley");
		platformCodeData.put("state", "CA");
		platformCodeData.put("zipcode", "91977");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus()); 
	    String message="Code Set in Request URL does not support Advanced Search";
	    Assert.assertEquals(message, serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("comment", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("code-set"));
	}
	
	@Test
	public void testSearch_ShouldReturnBadRequest_WhenRequestContainsInvalidFields() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/search";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platformCode", "PLA*123*CD");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    Assert.assertEquals("Invalid field: platformCode, in request body", serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("PLA*123*CD", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("platformCode"));
	}
	
	@Test
	public void testSearch_ShouldReturnBadRequest_WhenRequiredFieldsAreMissingInRequest() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/search";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform-code", "PLA*123*CD");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    Assert.assertEquals("Required field: address_line1, missing in request body", serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertNull(serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("address_line1"));
	}
	
	@Test
	public void testSearch_ShouldReturnSuccessWithResponse_WhenRequestIsvalid() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/search";
		
		Map<String, String> platformCodeData = new HashMap<>();		
		platformCodeData.put("address_line1", "4th Street");
	    
		Mockito.when(universalCodeServiceImpl.search("insurance", platformCodeData, null, null)).thenReturn(new ServiceResponse<List<Map<String,String>>>("Records Found", new ArrayList<>()));
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertTrue(((List<Map<String, String>>)(serviceResult.getBody().getBody())).size() == 0);
	    Assert.assertEquals("Records Found", serviceResult.getBody().getMessage());

	}

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.UniversalCodeController#getMappedUniversalCode(java.lang.String, java.util.Map)}.
	 * @throws ServiceException 
	 */
	@Test
	public void testGetMappedUniversalCode_ShouldSuccessufullyReturnUniversalCodeObject() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		platformCodeData.put("platform_identifier", "A");
	    
		Map<String, String> universalCode = new HashMap<String, String>();
		universalCode.put("universal_code", "A");
		ServiceResponse serviceResponse = new ServiceResponse(null, universalCode);
		
		Mockito.when(universalCodeServiceImpl.getMappedUniversalCode("comment", platformCodeData)).thenReturn(serviceResponse);
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    assertEquals(200, serviceResult.getStatusCodeValue());
	    assertEquals(null, serviceResult.getBody().getApiError());
	    assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	    assertEquals("A", ((Map<String, String>)serviceResult.getBody().getBody()).get("universal_code"));
	}
	
	@Test
	public void testGetMappedUniversalCode_ShouldReturnNullWithMessageFromService() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		platformCodeData.put("platform_identifier", "A");
	    
		ServiceResponse serviceResponse = new ServiceResponse("Any String", null);
		
		Mockito.when(universalCodeServiceImpl.getMappedUniversalCode("comment", platformCodeData)).thenReturn(serviceResponse);
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    assertEquals(200, serviceResult.getStatusCodeValue());
	    assertEquals(null, serviceResult.getBody().getApiError());
	    assertEquals(ApiStatus.SUCCESS, serviceResult.getBody().getStatus());
	    assertNull(serviceResult.getBody().getBody());
	    assertEquals("Any String", serviceResult.getBody().getMessage());
	}
	
	@Test
	public void testGetMappedUniversalCode_ShouldReturnBadRequest_WhenCodeSetIsInvalid() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comments");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		platformCodeData.put("platform_identifier", "A");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    String message="Invalid Code Set in Request URL";
	    Assert.assertEquals(message, serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("comments", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("code-set"));
	}
	
	@Test
	public void testGetMappedUniversalCode_ShouldReturnBadRequest_WhenCodeSetDoesntMaintainMapping() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		platformCodeData.put("platform_identifier", "A");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    String message="Code Set in Request URL does not have associated Platform Code Mappings.";
	    Assert.assertEquals(message, serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("insurance", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("code-set"));
	}
	
	@Test
	public void testGetMappedUniversalCode_ShouldReturnBadRequest_WhenFieldsAreInvalid() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		platformCodeData.put("platform_identifier", "A");
		platformCodeData.put("platform_codes", "PLA*123*CD");		
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    Assert.assertEquals("Invalid field: platform_codes, in request body", serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("PLA*123*CD", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("platform_codes"));
	}
	
	@Test
	public void testGetMappedUniversalCode_ShouldReturnBadRequest_WhenRequiredFieldsAreMissing() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    Assert.assertEquals("Required field: platform_identifier, missing in request body", serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("platform_identifier"));
	}

	@Test
	public void testGetMappedUniversalCode_ShouldReturnBadRequest_WhenNonKeyFieldsAreSentInRequest() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*123*CD");
		platformCodeData.put("platform_identifier", "A");
		platformCodeData.put("mapping_status", "ENABLED");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    Assert.assertEquals("Field: mapping_status, is not a key/key-participant for platform-code.", serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("ENABLED", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("mapping_status"));
	}
	
	@Test
	public void testGetMappedUniversalCode_ShouldReturnBadRequest_WhenFieldValuesAreInvalid() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "comment");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/platform-codes/mapped-universal-code";
		
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "PLA*1");
		platformCodeData.put("platform_identifier", "A");
		
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, platformCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(400, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getBody().getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getBody().getStatus());
	    Assert.assertEquals("Invalid field value: PLA*1 must match pattern: ^[A-Z0-9*]{8,15}(?<!\\*)", serviceResult.getBody().getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("PLA*1", serviceResult.getBody().getApiError().getSubErrors().get(0).getRejectedValue().get("platform_code"));
	}

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.UniversalCodeController#insert(java.lang.String, java.util.Map)}.
	 */
	//@Test
	public void testInsert() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("universal-code", "UNI*123*CD");
		univCodeData.put("insurance-type", "GROUP INSURANCE");
		univCodeData.put("incurance-name", "Great West");
		univCodeData.put("addr1", "841 Nichols Ave.");
		univCodeData.put("addr2", "Mechanic Rd");
		univCodeData.put("city", "Spring Valley");
		univCodeData.put("state", "CA");
		univCodeData.put("zipcode", "91977");
	    
	    ResponseEntity<ApiResponse> serviceResult = this.restTemplate.postForEntity(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(200, serviceResult.getStatusCodeValue());
	    Assert.assertEquals(null, serviceResult.getBody().getApiError());
	    Assert.assertEquals("Success", serviceResult.getBody().getStatus());
	}

	@Test
	public void update_ShouldUpdateAndReturnWithAppropriateMessage_WhenRequestIsValid() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("status", "DISABLED");
		Mockito.when(universalCodeServiceImpl.update("insurance", "UNI*123*CD", univCodeData)).thenReturn("Universal Code Updated");
		
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(null, serviceResult.getApiError());
	    Assert.assertEquals(ApiStatus.SUCCESS, serviceResult.getStatus());
	    Assert.assertEquals("Universal Code Updated", serviceResult.getMessage());
	}
	
	@Test
	public void update_ShouldThrowBadRequest_WhenRequestedCodeSetIsInvalid() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance1");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("status", "DISABLED");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    String message="Invalid Code Set in Request URL";
	    Assert.assertEquals(message, serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("insurance1", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("code-set"));
	}
	
	@Test
	public void update_ShouldThrowBadRequest_WhenInvalidFieldsAreSentInRequest() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("bla", "bla1");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    Assert.assertEquals("Invalid field: bla, in request body", serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("bla1", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("bla"));
	}
	
	@Test
	public void update_ShouldThrowBadRequest_WhenCreatedDateIsSentInRequest() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("creation_date", "02/02/2020");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    Assert.assertEquals("Field: creation_date can't be updated.", serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("02/02/2020", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("creation_date"));
	}
	
	@Test
	public void update_ShouldThrowBadRequest_WhenUniversalCodeIsSentInRequest() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("universal_code", "UNI*123*CD");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    Assert.assertEquals("Field: universal_code can't be updated.", serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("UNI*123*CD", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("universal_code"));
	}
	
	@Test
	public void update_ShouldThrowBadRequest_WhenRequestedUniversalCodeValueIsInvalid() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*12");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("status", "DISABLED");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    Assert.assertEquals("Invalid field value: UNI*12 must match pattern: ^[A-Z0-9*]{8,15}(?<!\\*)", serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("UNI*12", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("universal_code"));
	}
	
	@Test
	public void update_ShouldThrowBadRequest_WhenRequestedPlatformCodeValueIsInvalid() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("zip", "841-1234-5678");
	    
	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.BAD_REQUEST, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    Assert.assertEquals("Invalid field value: 841-1234-5678 must match pattern: [0-9-]{0,10}", serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("841-1234-5678", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("zip"));
	}
	
	@Test
	public void update_ShouldReturnUniversalCodeNotFound_WhenUniversalCodeIsNotFound() throws ServiceException {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		Map<String, String> univCodeData = new HashMap<>();
		univCodeData.put("address_line1", "841 Nichols Ave.");
		univCodeData.put("address_line2", "Mechanic Rd.");
		univCodeData.put("status", "DISABLED");
		Map<String, String> rejectedUniversalCode = new HashMap<>();
		rejectedUniversalCode.put("Universal code in URL", "UNI*123*CD");
		Mockito.when(universalCodeServiceImpl.update("insurance", "UNI*123*CD", univCodeData)).thenThrow(new ServiceException("Univeral Code not found", rejectedUniversalCode, CtsErrorCode.ENTITY_NOT_FOUND));

	    ApiResponse serviceResult = this.restTemplate.patchForObject(baseUrl, univCodeData, ApiResponse.class, urlVariables);
	    
	    Assert.assertEquals(CtsErrorCode.ENTITY_NOT_FOUND, serviceResult.getApiError().getErrorCode());
	    Assert.assertEquals(ApiStatus.ERROR, serviceResult.getStatus());
	    Assert.assertEquals("Univeral Code not found", serviceResult.getApiError().getSubErrors().get(0).getMessage());
	    Assert.assertEquals("UNI*123*CD", serviceResult.getApiError().getSubErrors().get(0).getRejectedValue().get("Universal code in URL"));
	}

	/**
	 * Test method for {@link com.chc.arena.translationservice.controller.UniversalCodeController#delete(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testDelete() {
		Map<String, String> urlVariables = new HashMap<>();
		urlVariables.put("code-set", "insurance");
		urlVariables.put("universal-code", "UNI*123*CD");
		final String baseUrl = "http://localhost:" + randomServerPort + "/code-sets/{code-set}/universal-codes/{universal-code}";
		
		this.restTemplate.delete(baseUrl, urlVariables);
		
		Assert.assertTrue(true);
	}

}
