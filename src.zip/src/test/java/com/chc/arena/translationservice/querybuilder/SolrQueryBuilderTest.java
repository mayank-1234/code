package com.chc.arena.translationservice.querybuilder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;

@RunWith(MockitoJUnitRunner.class)
public class SolrQueryBuilderTest {

	@InjectMocks
	private SolrQueryBuilder solrQueryBuilder;
	
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;
	
	private String codeSet = "insurance";
	private Map<String, String> queryFields = new HashMap<String, String>();
	private Map<String, String> filterQueryFields = new HashMap<String, String>();
	private List<String> fieldList = Arrays.asList(new String[] {"universal_code", "insurance_name"});
	private Map<String, String> platformObject = new HashMap<String, String>();
	
	@Before
	public void init() {		
		queryFields.put("insurance_name", "insurance_name: <insurance_name>");
		filterQueryFields.put("city", "city: <city>");
		platformObject.put("insurance_name", "GREAT WEST");
	}
	
	@Test
	public void buildQueryForSearch_ShouldReturnQueryWhenQueryFieldsAreNotConfiguredForCodeSet() {
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet)).thenReturn(new HashMap<>());
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet)).thenReturn(new HashMap<>());
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(fieldList);
		
		SolrQuery solrQuery = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, null, null);
		
		assertEquals("universal_code,insurance_name,score", solrQuery.getFields());
		assertEquals("*", solrQuery.getQuery());
		assertNull(solrQuery.getStart());
	}
	
	@Test
	public void buildQueryForSearch_ShouldReturnQueryWhenQueryFieldsAreConfiguredForCodeSet() {
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet)).thenReturn(queryFields);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet)).thenReturn(new HashMap<>());
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(fieldList);
		
		SolrQuery solrQuery = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, null, null);
		
		assertEquals("universal_code,insurance_name,score", solrQuery.getFields());
		assertEquals("insurance_name: GREAT\\ WEST", solrQuery.getQuery());
		assertNull(solrQuery.getStart());
	}
	
	@Test
	public void buildQueryForSearch_ShouldReturnQueryWhenMoreQueryFieldsAreConfiguredForCodeSet() {
		queryFields.put("address_line1", "address_line1: <address_line1>");
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet)).thenReturn(queryFields);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet)).thenReturn(new HashMap<>());
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(fieldList);
		
		SolrQuery solrQuery = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, null, null);
		
		assertEquals("universal_code,insurance_name,score", solrQuery.getFields());
		assertEquals("insurance_name: GREAT\\ WEST", solrQuery.getQuery());
		assertNull(solrQuery.getStart());
	}
	
	@Test
	public void buildQueryForSearch_ShouldReturnQueryWhenFilterQueryFieldsAreConfiguredForCodeSet() {
		queryFields.put("address_line1", "address_line1: <address_line1>");
		platformObject.put("city", "DETROIT");
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet)).thenReturn(queryFields);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet)).thenReturn(filterQueryFields);
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(fieldList);
		
		SolrQuery solrQuery = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, null, null);
		
		assertEquals("universal_code,insurance_name,score", solrQuery.getFields());
		assertEquals("insurance_name: GREAT\\ WEST", solrQuery.getQuery());
		assertEquals("city: DETROIT", solrQuery.getFilterQueries()[0]);
		assertNull(solrQuery.getStart());
	}
	
	@Test
	public void buildQueryForSearch_ShouldReturnQueryWhenMoreFilterQueryFieldsAreConfiguredForCodeSet() {
		filterQueryFields.put("state", "state: <state>");
		platformObject.put("city", "DETROIT");
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet)).thenReturn(queryFields);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchDefaultResultCount()).thenReturn(10);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet)).thenReturn(filterQueryFields);
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(fieldList);
		
		SolrQuery solrQuery = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, null, null);
		
		assertEquals("universal_code,insurance_name,score", solrQuery.getFields());
		assertEquals("insurance_name: GREAT\\ WEST", solrQuery.getQuery());
		assertEquals("city: DETROIT", solrQuery.getFilterQueries()[0]);
		assertEquals(10, solrQuery.getRows());
		assertNull(solrQuery.getStart());
	}
	
	@Test
	public void buildQueryForSearch_ShouldReturnQueryWhenCountIsSentInRequest() {
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchQueryFields(codeSet)).thenReturn(queryFields);
		Mockito.when(codeSetMetaDataUtil.getAdvancedSearchFilterQueryFields(codeSet)).thenReturn(filterQueryFields);
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(fieldList);
		
		SolrQuery solrQuery = solrQueryBuilder.buildQueryForSearch(codeSet, platformObject, 0, 1);
		
		assertEquals("universal_code,insurance_name,score", solrQuery.getFields());
		assertEquals("insurance_name: GREAT\\ WEST", solrQuery.getQuery());
		assertEquals(0, solrQuery.getStart());
		assertEquals(1, solrQuery.getRows());
	}
}
