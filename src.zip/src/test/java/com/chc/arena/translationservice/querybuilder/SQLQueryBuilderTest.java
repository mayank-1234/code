package com.chc.arena.translationservice.querybuilder;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import com.chc.arena.translationservice.contants.TranslationServiceStringConstant;
import com.chc.arena.translationservice.model.Direction;
import com.chc.arena.translationservice.util.CodeSetMetaDataUtil;
import com.chc.arena.translationservice.validation.annotation.StatusEnum;
import com.chc.arena.translationservice.validation.annotation.PlatformCodesMappingStatus;

/**
 * The Class SQLQueryBuilderTest.
 */
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class SQLQueryBuilderTest {

	/** The sql query builder. */
	@InjectMocks
	private SQLQueryBuilder sqlQueryBuilder;

	/** The code set meta data util. */
	@Mock
	private CodeSetMetaDataUtil codeSetMetaDataUtil;

	/** The code set. */
	private static String codeSet;

	/**
	 * Setup.
	 */
	@BeforeClass
	public static void setup() {
		codeSet = "insurance";
	}

	/**
	 * Setup this.
	 */
	@Before
	public void setupThis() {
	}

	
	/**
	 * Builds the universal insert query should return insert query for universal code set with paging filter.
	 */
	@Test
	public void buildUniversalRetrieveAllQuery_Success_With_QueryParams() {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		StatusEnum filter = StatusEnum.ENABLED;
		String orderBy = "creation_date";
		Direction direction = Direction.ASC;
		
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		
		List<String> universalCodeFields = new ArrayList<>();
		universalCodeFields.add("universal_code");
		universalCodeFields.add("description");
		universalCodeFields.add("creation_date");
		universalCodeFields.add("last_updated");
		universalCodeFields.add("status");
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(universalCodeFields );
		
		String expectedQuery = "SELECT comment_universal.universal_code, comment_universal.description, comment_universal.creation_date, comment_universal.last_updated, comment_universal.status FROM comment_universal WHERE comment_universal.status=:status  ORDER BY creation_date ASC LIMIT 0,1";
		
		String actualUniversalRetrieveAllQuery = sqlQueryBuilder.buildUniversalRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction);
		
		assertEquals(expectedQuery, actualUniversalRetrieveAllQuery);
	}
	
	@Test
	public void buildUniversalRetrieveAllQuery_Success_NoQueryParam() {
		String codeSet = "comment";
		Integer page = null;
		Integer count = null;
		StatusEnum filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		
		List<String> universalCodeFields = new ArrayList<>();
		universalCodeFields.add("universal_code");
		universalCodeFields.add("description");
		universalCodeFields.add("creation_date");
		universalCodeFields.add("last_updated");
		universalCodeFields.add("status");
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeFields(codeSet)).thenReturn(universalCodeFields );
		
		String expectedQuery = "SELECT comment_universal.universal_code, comment_universal.description, comment_universal.creation_date, comment_universal.last_updated, comment_universal.status FROM comment_universal";
		
		String actualUniversalRetrieveAllQuery = sqlQueryBuilder.buildUniversalRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction);
		
		assertEquals(expectedQuery, actualUniversalRetrieveAllQuery);
	}

	/**
	 * Builds the universal delete query should return delete query for universal code set.
	 */
	@Test
	public void buildUniversalDeleteQuery_shouldReturnDeleteQueryForUniversalCodeSet() {
		/*Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn("insurance_universal");
		Mockito.when(codeSetMetaDataUtil.getColumnNameFromUniversalFieldColumnMapping(Mockito.any(), Mockito.any()))
				.thenReturn(removeSpaces("universal_code"));
		String expectedSql = "DELETE FROM insurance_universal WHERE universal_code =: universal_code";
		assertEquals(removeSpaces(expectedSql), removeSpaces(sqlQueryBuilder.buildUniversalDeleteQuery(codeSet)));*/
		assertTrue(true);
	}

	/**
	 * Builds the universal update query should return update query for universal code set.
	 */
	@Test
	public void buildUniversalUpdateQuery_shouldReturnUpdateQueryForUniversalCodeSet() {
		/*Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn("insurance_universal");
		Map<String, String> mapping = new HashMap<String, String>();
		mapping.put("universal-code", "universal_code");
		mapping.put("insurance-name", "insurance_name");
		mapping.put("insurance-type", "insurance_type");
		Mockito.when(codeSetMetaDataUtil.getUniversalFieldColumnMapping(codeSet)).thenReturn(mapping);
		Mockito.when(codeSetMetaDataUtil.getColumnNameFromUniversalFieldColumnMapping(Mockito.any(), Mockito.any()))
				.thenReturn(removeSpaces("universal_code"));
		String expectedSql = "UPDATE insurance_universal SET insurance_type:insurance_type ,insurance_name:insurance_name  "
				+ "WHERE universal_code:universal_code";
		Map<String, String> codeObject = new HashMap<String, String>();
		codeObject.put("universal-code", "ABCD*1234*AJKLJ");
		codeObject.put("insurance-name", "FEDERAL MEDICARE CARRIER");
		codeObject.put("insurance-type", "Group Insurance");
		assertEquals(removeSpaces(expectedSql),
				removeSpaces(sqlQueryBuilder.buildUniversalUpdateQuery(codeSet, codeObject)));*/
		assertTrue(true);
	}

	/**
	 * Builds the universal retrieve all query should return universal code query for all for given params.
	 */
	@Test
	public void buildUniversalRetrieveAllQuery_shouldReturnUniversalCodeQueryForAll_forGivenParams() {
		/*Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn("insurance_universal");
		Mockito.when(codeSetMetaDataUtil.getColumnNameFromUniversalFieldColumnMapping(Mockito.any(), Mockito.any()))
				.thenReturn(removeSpaces("universal_code"));
		String expectedSql = "SELECT * FROM insurance_universal WHERE universal_code : universal_code";
		assertEquals(removeSpaces(expectedSql), removeSpaces(sqlQueryBuilder.buildUniversalRetrieveQuery(codeSet)));*/
		assertTrue(true);
	}
	
	/**
	 * Builds the universal retrieve query should return universal code query for given code.
	 */
	@Test
	public void buildUniversalRetrieveQuery_shouldReturnUniversalCodeQuery_forGivenCode() {
		String codeSet = "comment";
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName);
		String buildUniversalRetrieveQuery = sqlQueryBuilder.buildUniversalRetrieveQuery(codeSet);
		assertEquals("SELECT  *  FROM comment_universal WHERE universal_code=:universal_code ", buildUniversalRetrieveQuery);
	}
	
	@Test
	public void setUniversalRetrieveParametersTest() {
		String universalCode = "PIL*JH4*TY";
		MapSqlParameterSource universalRetrieveParameters = sqlQueryBuilder.setUniversalRetrieveParameters(universalCode);
		String actualValue= (String)universalRetrieveParameters.getValue("universal_code");
		assertEquals(universalCode, actualValue);
	}
	
	@Test
	public void buildUniversalMappedPlatformQuery_shouldReturnMappedUniversalCodes_forPlatform() {
		String[] columns = {"universal_code", "type"};
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn("transaction_code_universal");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn("transaction_code_platform");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(Arrays.asList(columns));
		
		String expectedSql = "SELECT PLATFORM.universal_code_id, PLATFORM.mapping_status, UNIVERSAL.* FROM transaction_code_platform PLATFORM  LEFT JOIN "
				+ "transaction_code_universal UNIVERSAL  ON PLATFORM.universal_code_id = UNIVERSAL.id WHERE universal_code = :universal_code AND type = :type";
		assertEquals(expectedSql, sqlQueryBuilder.buildUniversalMappedPlatformQuery(codeSet));		
	}
	
	@Test
	public void setUniversalAndPlatformMappingParameters_shouldReturnMapSqlParameterSource() {
		String[] columns = {"universal_code", "type"};
		Map<String, String> platformCodeObject = new HashMap<>();
		platformCodeObject.put("universal_code", "A");
		platformCodeObject.put("type", "B");
		platformCodeObject.put("description", "C");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(codeSet)).thenReturn(Arrays.asList(columns));
		MapSqlParameterSource parameterSource = sqlQueryBuilder.setUniversalAndPlatformMappingParameters(codeSet, platformCodeObject);
		assertEquals("A", parameterSource.getValues().get("universal_code"));
		assertEquals("B", parameterSource.getValues().get("type"));
		assertEquals(2, parameterSource.getValues().keySet().size());
	}

	/**
	 * Builds the platform insert query should return insert query.
	 */
	@Test
	public void buildPlatformInsertQuery_shouldReturn_InsertQuery() {
		/*Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName("transaction-code"))
				.thenReturn("transaction_code_platform");
		String[] columns = { "universal_code", "type", "code" };
		Mockito.when(codeSetMetaDataUtil.getPlatFormCodeSetColumNames("transaction-code"))
				.thenReturn(Arrays.asList(columns));
		String expectedSql = "INSERT  INTO  transaction_code_platform  ( universal_code, type, code )  VALUES ( :universal_code, :type, :code ) ";
		assertEquals(removeSpaces(expectedSql),
				removeSpaces(sqlQueryBuilder.buildPlatformInsertQuery("transaction-code")));*/
		assertTrue(true);
	}

	/**
	 * Builds the platform retrieve all query should return retrieve all.
	 */
	@Test
	public void buildPlatformRetrieveAllQuery_shouldReturnRetrieveAll() {

		/*Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName("transaction-code"))
				.thenReturn("transaction_code_platform");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFieldColumnMapping("transaction-code","universal-code"))
				.thenReturn("universal_code");
		Mockito.when(codeSetMetaDataUtil.getColumnNameFromUniversalFieldColumnMapping("transaction-code", "enabled"))
				.thenReturn("enabled");
		String expectedSql = "SELECT TOP 100 * FROM transaction_code_platform WHERE universal_code > 10  AND enabled= Y";
		assertEquals(removeSpaces(expectedSql),
				removeSpaces(sqlQueryBuilder.buildPlatformRetrieveAllQuery("transaction-code", 10, 100, "Y")));*/
		assertTrue(true);
	}

	/**
	 * Builds the platform update query should return update query for platforms.
	 */
	@Test
	public void buildPlatformUpdateQuery_shouldReturnUpdateQueryForPlatforms() {
		/*Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName("transaction-code"))
				.thenReturn("transaction_code_platform");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFieldColumnMapping("transaction-code","universal-code"))
				.thenReturn("universal_code");
		Mockito.when(codeSetMetaDataUtil.getColumnNameFromUniversalFieldColumnMapping(Mockito.any(), Mockito.any()))
				.thenReturn(removeSpaces("universal_code"));
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName("transaction-code"))
				.thenReturn("transaction_code_universal");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFieldColumnMapping("transaction-code","platform-code")).thenReturn("platform_code");
		codeSetMetaDataUtil.getPlatformCodeFieldColumnMapping("transaction-code","platform-identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFieldColumnMapping("transaction-code","platform-identifier"))
				.thenReturn("platform_identifier");
		String expectedSql = "UPDATE transaction_code_platform SET universal_code= ( SELECT universal_code FROM transaction_code_universal "
				+ "WHERE universal_code : universal_code ) WHERE platform_code : platform_code AND platform_identifier : platform_identifier ";
		assertEquals(removeSpaces(expectedSql),
				removeSpaces(sqlQueryBuilder.buildPlatformUpdateQuery("transaction-code")));*/
		assertTrue(true);
	}
	
	@Test
	public void buildPlatformRetrieveByUniversalCodeIdQueryTest_NoQueryParam() {
		String codeSet = "comment";
		Integer page= null;
		Integer count= null;
		StatusEnum filter=null;
		String orderBy=null;
		Direction direction=null;
		
		String platformTableName = "comment_platform";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn(platformTableName);
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		List<String> platformCodeFields = new ArrayList<>();
		platformCodeFields.add("universal_code");
		platformCodeFields.add("platform_code");
		platformCodeFields.add("platform_identifier");
		platformCodeFields.add("creation_date");
		platformCodeFields.add("last_updated");
		platformCodeFields.add("mapping_status");
		
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFields(codeSet)).thenReturn(platformCodeFields);
		
		String expectedQuery = "SELECT comment_universal.universal_code,comment_platform.platform_code, comment_platform.platform_identifier, comment_platform.creation_date, comment_platform.last_updated, comment_platform.mapping_status FROM comment_platform LEFT JOIN comment_universal ON comment_universal.id = comment_platform.universal_code_id  WHERE comment_universal.universal_code =:universal_code ";
		
		String actualQuery = sqlQueryBuilder.buildPlatformRetrieveByUniversalCodeIdQuery(codeSet, page, count, filter, orderBy, direction);
		
		assertNotNull(actualQuery);
		assertEquals(expectedQuery, actualQuery);
	}
	
	@Test
	public void buildPlatformRetrieveByUniversalCodeIdQueryTest_WithQueryParam() {
		String codeSet = "comment";
		Integer page= 1;
		Integer count= 10;
		StatusEnum filter=StatusEnum.ENABLED;
		String orderBy="platform_identifier";
		Direction direction=Direction.ASC;
		
		String platformTableName = "comment_platform";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn(platformTableName);
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		List<String> platformCodeFields = new ArrayList<>();
		platformCodeFields.add("universal_code");
		platformCodeFields.add("platform_code");
		platformCodeFields.add("platform_identifier");
		platformCodeFields.add("creation_date");
		platformCodeFields.add("last_updated");
		platformCodeFields.add("mapping_status");
		
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFields(codeSet)).thenReturn(platformCodeFields);
		
		String expectedQuery = "SELECT comment_universal.universal_code,comment_platform.platform_code, comment_platform.platform_identifier, comment_platform.creation_date, comment_platform.last_updated, comment_platform.mapping_status FROM comment_platform LEFT JOIN comment_universal ON comment_universal.id = comment_platform.universal_code_id  WHERE comment_universal.universal_code =:universal_code  AND comment_platform.mapping_status=:mapping_status  ORDER BY platform_identifier ASC LIMIT 0,10";
		
		String actualQuery = sqlQueryBuilder.buildPlatformRetrieveByUniversalCodeIdQuery(codeSet, page, count, filter, orderBy, direction);
		
		assertNotNull(actualQuery);
		assertEquals(expectedQuery, actualQuery);
	}
	
	@Test
	public void setPlatformRetrieveByUniversalCodeIdParametersTest() {
		String universalCode= "PIL*123GH";
		Integer page= 1;
		Integer count= 10;
		StatusEnum filter=StatusEnum.ENABLED;
		Direction direction=Direction.ASC;
		
		MapSqlParameterSource actualPlatformRetrieveByUniversalCodeIdParameters = sqlQueryBuilder.setPlatformRetrieveByUniversalCodeIdParameters(universalCode, filter);
		assertNotNull(actualPlatformRetrieveByUniversalCodeIdParameters);
		assertEquals(universalCode, actualPlatformRetrieveByUniversalCodeIdParameters.getValue("universal_code"));
		assertEquals(filter.name(), actualPlatformRetrieveByUniversalCodeIdParameters.getValue("mapping_status"));
	}

	@Test
	public void buildPlatformEnableDisableByUniversalCodeQuery_ShouldReturnQuery() {
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName("comment")).thenReturn("COMMENT_PLATFORM");
		String query = sqlQueryBuilder.buildPlatformEnableDisableByUniversalCodeQuery("comment");
		assertEquals("UPDATE COMMENT_PLATFORM SET mapping_status=:mapping_status, last_updated=:last_updated WHERE universal_code_id=:universal_code_id", query);
	}
	
	@Test
	public void setPlatformEnableDisableByUniversalCodeParameters_ShouldSetParameters() {
		MapSqlParameterSource params = sqlQueryBuilder.setPlatformEnableDisableByUniversalCodeParameters("ENABLED", 1, new Date());
		assertEquals("ENABLED", params.getValue("mapping_status"));
		assertEquals(1, params.getValue("universal_code_id"));
		assertNotNull(params.getValue(TranslationServiceStringConstant.LAST_UPDATED));
	}
	
	@Test
	public void buildUniversalRetrieveByUniversalCodeQuery_ShouldReturnQuery() {
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName("comment")).thenReturn("COMMENT_UNIVERSAL");
		String query = sqlQueryBuilder.buildUniversalRetrieveQuery("comment");
		assertEquals("SELECT  *  FROM COMMENT_UNIVERSAL WHERE universal_code=:universal_code ", query);
	}
	
	@Test
	public void setUniversalRetrieveByUniversalCodeParameters_ShouldSetParameters() {
		MapSqlParameterSource params = sqlQueryBuilder.setUniversalRetrieveParameters("ABCD*1234");
		assertEquals("ABCD*1234", params.getValue("universal_code"));
	}
	
	@Test
	public void buildUniversalRecordCountQueryTest() {
		String codeSet = "comment";
		StatusEnum filter = StatusEnum.ENABLED;
		
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn("comment_universal");
		
		String expectedQuery = "SELECT  COUNT(*)  FROM comment_universal WHERE comment_universal.status=:status ";
		
		String actualUniversalRecordCountQuery = sqlQueryBuilder.buildUniversalRecordCountQuery(codeSet, filter);
		
		assertEquals(expectedQuery, actualUniversalRecordCountQuery);
	}
	
	@Test
	public void buildUniversalRecordCountQueryTest_NoFilter() {
		String codeSet = "comment";
		StatusEnum filter = null;
		
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn("comment_universal");
		
		String expectedQuery = "SELECT  COUNT(*)  FROM comment_universal";
		
		String actualUniversalRecordCountQuery = sqlQueryBuilder.buildUniversalRecordCountQuery(codeSet, filter);
		
		assertEquals(expectedQuery, actualUniversalRecordCountQuery);
	}
	
	@Test
	public void buildPlatformRecordCountQueryTest() {
		String codeSet = "comment";
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn("comment_platform");
		
		String expectedQuery = "SELECT  COUNT(*)  FROM comment_platform WHERE comment_platform.mapping_status=:mapping_status ";
		
		String actualPlatformRecordCountQuery = sqlQueryBuilder.buildPlatformRecordCountQuery(codeSet, filter,null);
		
		assertEquals(expectedQuery, actualPlatformRecordCountQuery);
	}
	
	@Test
	public void buildPlatformRecordCountQueryTest_NoFilter() {
		String codeSet = "comment";
		PlatformCodesMappingStatus filter = null;
		
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn("comment_platform");
		
		String expectedQuery = "SELECT  COUNT(*)  FROM comment_platform ";
		
		String actualPlatformRecordCountQuery = sqlQueryBuilder.buildPlatformRecordCountQuery(codeSet, filter,null);
		
		assertEquals(expectedQuery, actualPlatformRecordCountQuery);
	}
	
	@Test
	public void buildPlatformRetrieveAllQueryTest_WithQueryParams() {
		String codeSet = "comment";
		Integer page = 1;
		Integer count = 1;
		PlatformCodesMappingStatus filter = PlatformCodesMappingStatus.ENABLED;
		String orderBy = "platform_identifier";
		Direction direction = Direction.ASC;
		
		String platformTableName = "platform_universal";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn(platformTableName );
		
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		
		List<String> platformCodeFields = new ArrayList<>();
		platformCodeFields.add("universal_code_id");
		platformCodeFields.add("platform_code");
		platformCodeFields.add("platform_identifier");
		platformCodeFields.add("creation_date");
		platformCodeFields.add("last_updated");
		platformCodeFields.add("mapping_status");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFields(codeSet)).thenReturn(platformCodeFields );
		
		String expectedQuery = "SELECT comment_universal.universal_code,platform_universal.universal_code_id, platform_universal.platform_code, platform_universal.platform_identifier, platform_universal.creation_date, platform_universal.last_updated, platform_universal.mapping_status FROM platform_universal LEFT JOIN comment_universal ON comment_universal.id = platform_universal.universal_code_id WHERE platform_universal.mapping_status=:mapping_status  ORDER BY platform_identifier ASC LIMIT 0,1";
		
		String actualPlatformRetrieveAllQuery = sqlQueryBuilder.buildPlatformRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction,null);
		
		assertEquals(expectedQuery, actualPlatformRetrieveAllQuery);
	}
	
	@Test
	public void buildPlatformRetrieveAllQueryTest_WithNoQueryParams() {
		String codeSet = "comment";
		Integer page = null;
		Integer count = null;
		PlatformCodesMappingStatus filter = null;
		String orderBy = null;
		Direction direction = null;
		
		String platformTableName = "platform_universal";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn(platformTableName );
		
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		
		List<String> platformCodeFields = new ArrayList<>();
		platformCodeFields.add("universal_code_id");
		platformCodeFields.add("platform_code");
		platformCodeFields.add("platform_identifier");
		platformCodeFields.add("creation_date");
		platformCodeFields.add("last_updated");
		platformCodeFields.add("mapping_status");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeFields(codeSet)).thenReturn(platformCodeFields );
		
		String expectedQuery = "SELECT comment_universal.universal_code,platform_universal.universal_code_id, platform_universal.platform_code, platform_universal.platform_identifier, platform_universal.creation_date, platform_universal.last_updated, platform_universal.mapping_status FROM platform_universal LEFT JOIN comment_universal ON comment_universal.id = platform_universal.universal_code_id ";
		
		String actualPlatformRetrieveAllQuery = sqlQueryBuilder.buildPlatformRetrieveAllQuery(codeSet, page, count, filter, orderBy, direction,null);
		
		assertEquals(expectedQuery, actualPlatformRetrieveAllQuery);
	}
	
	@Test
	public void buildPlatformCodeRecordCountByCodeSetAndUniversalCodeQueryTest() {
		String codeSet = "comment";
		String universalCode = "ABC*1234";
		StatusEnum filter = StatusEnum.ENABLED;
		
		String platformTableName = "comment_platform";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn(platformTableName);

		String universalCodeSetTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalCodeSetTableName);
		
		String expectedQuery = "SELECT  COUNT(*)  FROM comment_platform LEFT JOIN comment_universal ON comment_universal.id = comment_platform.universal_code_id  WHERE comment_universal.universal_code =:universal_code  AND comment_platform.mapping_status=:mapping_status ";
		
		String actualPlatformCodeRecordCountByCodeSetAndUniversalCodeQuery = sqlQueryBuilder.buildPlatformCodeRecordCountByCodeSetAndUniversalCodeQuery(codeSet, universalCode, filter);
		
		assertEquals(expectedQuery, actualPlatformCodeRecordCountByCodeSetAndUniversalCodeQuery);
	}
	
	@Test
	public void buildUpdateQuery_ShouldReturnUpdateMappingQuery() {
		String codeSet = "comment";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName("comment")).thenReturn("comment_platform");
		
		List<String> compositKeys=new ArrayList<>();
		compositKeys.add("platform_code");
		compositKeys.add("platform_identifier");
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeCompositeKeyFields(Mockito.eq(codeSet))).thenReturn(compositKeys);
		String queryActual = sqlQueryBuilder.buildPlatformUpdateQuery("comment");
		String queryExpected = "UPDATE comment_platform  SET mapping_status=:mapping_status, last_updated=:last_updated, universal_code_id=:universal_code_id  WHERE platform_code=:platform_code  AND platform_identifier=:platform_identifier  ";
		assertEquals(queryExpected, queryActual);
	}  


	@Test
	public void buildPlatformDataRetrieveQuery_shouldReturnRetrieveQuery() {
		String codeSet = "comment";
		
		String platformTableName = "comment_platform";
		Mockito.when(codeSetMetaDataUtil.getPlatformCodeSetTableName(codeSet)).thenReturn(platformTableName );
		
		String universalTableName = "comment_universal";
		Mockito.when(codeSetMetaDataUtil.getUniversalCodeSetTableName(codeSet)).thenReturn(universalTableName );
		Map<String, String> platformCodeData = new HashMap<>();
		platformCodeData.put("platform_code", "MDV2*536*5111");
		platformCodeData.put("platform_identifier", "MDIV"); 
		String queryActual = sqlQueryBuilder.buildPlatformDataRetrieveQuery(codeSet, platformCodeData);
		String expectedQuery="SELECT PLATFORM.* ,UNIVERSAL.universal_code  FROM comment_platform PLATFORM LEFT JOIN comment_universal UNIVERSAL  ON  PLATFORM.universal_code_id = UNIVERSAL.id  WHERE platform_identifier=:platform_identifier  AND platform_code=:platform_code  ";
		assertEquals(expectedQuery, queryActual);
		
	}
	
}
 